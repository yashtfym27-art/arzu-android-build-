# Arzu İçerik ve Medya Üretim Motoru

Arzu’nun medya motoru, doğal Türkçe komutları üretim planına dönüştürür. Örneğin “30 saniyelik reklam videosu hazırla” komutu; hedef platform, oran, süre, kanca, sahneler, görsel promptları, seslendirme metni, ekran yazıları, altyazı ve CTA alanlarına ayrılır.

## Gerçek çalışan katmanlar

| Katman | Durum | Açıklama |
|---|---|---|
| Senaryo ve sahne planlama | Çalışır | Sunucu tarafında yerleşik LLM ile JSON plan üretilir ve şema ile doğrulanır. |
| Platform formatlama | Çalışır | YouTube 16:9; Reels, TikTok ve Shorts 9:16 formatları planlanır. |
| Görsel üretimi | Forge yapılandırılırsa çalışır | `BUILT_IN_FORGE_API_URL` ve `BUILT_IN_FORGE_API_KEY` sunucu ortamında bulunmalıdır. |
| Türkçe seslendirme | Harici servis gerekir | `ELEVENLABS_API_KEY` ve `ELEVENLABS_VOICE_ID` yalnızca sunucu ortamında tutulmalıdır. Cihaz TTS’si video asset’i olarak kullanılmaz. |
| SRT altyazı | Çalışır | Sahne sürelerinden deterministik SRT oluşturulur. |
| MP4 montaj | Harici servis gerekir | `SHOTSTACK_API_KEY` ile gerçek render kuyruğu açılır; MP4 tamamlanmadan tamamlandı gösterilmez. |
| Otomatik yayınlama | Bilinçli olarak kapalı | YouTube, Instagram ve TikTok OAuth, hesap yetkisi ve kullanıcı onayı gerektirir. |

API anahtarları mobil bundle’a veya AsyncStorage’a konulmaz. Uygulama yalnızca tRPC sunucu rotalarını çağırır; sağlayıcı anahtarları Node sunucusunun ortam değişkenlerinden okunur. Eksik anahtar durumunda motor “sahte video” üretmez, `needs_configuration` sonucu ve eksik yapılandırma bilgisini döndürür.

## Üretim akışı

`mediaCreate` önce planı oluşturur. Gerekli sağlayıcılar hazırsa görselleri üretir, ElevenLabs ile seslendirme oluşturur, SRT’yi depolar ve Shotstack render işini kuyruğa alır. Shotstack render kimliği `mediaRenderStatus` ile sorgulanır. Sadece sağlayıcı `done` ve geçerli MP4 URL’si döndürdüğünde çıktı tamamlanmış kabul edilir.

Render işlemleri cihazda yapılmaz; görsel, ses ve MP4 işlemleri sunucu/harici render sağlayıcılarına bırakılır. Mobil uygulama yalnızca komut, plan ve durum ekranını yönetir. Otomatik platform yayınlaması bu sürümde yoktur.
