/** @type {const} */
const themeColors = {
  primary: { light: '#6E5CE6', dark: '#B7AAFF' },
  background: { light: '#14121D', dark: '#14121D' },
  surface: { light: '#201C2E', dark: '#201C2E' },
  foreground: { light: '#F5F3FE', dark: '#F5F3FE' },
  muted: { light: '#9F99B5', dark: '#9F99B5' },
  border: { light: '#332D45', dark: '#332D45' },
  success: { light: '#7CDBBE', dark: '#7CDBBE' },
  warning: { light: '#E9C47E', dark: '#E9C47E' },
  error: { light: '#F68AA5', dark: '#F68AA5' },
};

module.exports = { themeColors };
