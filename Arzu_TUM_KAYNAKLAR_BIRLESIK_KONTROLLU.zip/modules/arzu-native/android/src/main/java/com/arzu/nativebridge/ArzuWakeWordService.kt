package com.arzu.nativebridge

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.media.AudioAttributes
import androidx.core.app.NotificationCompat
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

class ArzuWakeWordService : Service(), RecognitionListener, TextToSpeech.OnInitListener {
  companion object {
    const val ACTION_START = "com.arzu.native.START_WAKE_WORD"
    const val ACTION_STOP = "com.arzu.native.STOP_WAKE_WORD"
    const val ACTION_SPEAK = "com.arzu.native.SPEAK_PROACTIVE"
    const val ACTION_DICTATE = "com.arzu.native.DICTATE_OFFLINE"
    const val ACTION_WAKE = "com.arzu.native.WAKE_WORD_DETECTED"
    const val ACTION_DICTATION_RESULT = "com.arzu.native.DICTATION_RESULT"
    const val EXTRA_WAKE_WORD = "wakeWord"
    const val EXTRA_TEXT = "text"
    const val EXTRA_PRIORITY = "priority"
    private const val CHANNEL_ID = "arzu-wake-word"
    private const val NOTIFICATION_ID = 4107
    @Volatile var running = false
  }

  private var recognizer: SpeechRecognizer? = null
  private var tts: TextToSpeech? = null
  private var ttsReady = false
  private val pendingSpeech = ArrayDeque<Pair<String, String>>()
  private var wakeWord = "arzu"
  private val stopping = AtomicBoolean(false)
  private var restartAttempt = 0
  private var dictationMode = false
  private var wakeModeEnabled = false
  private var resumeWakeAfterDictation = false
  private var suppressRestartOnce = false
  private var preferOffline = true
  private var restartPending = false
  private var lastWakeAt = 0L
  @Volatile private var ttsActive = false
  private var wifiLock: android.net.wifi.WifiManager.WifiLock? = null

  override fun onCreate() {
    super.onCreate()
    createChannel()
    tts = TextToSpeech(this, this).also { engine ->
      engine.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
      engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) = Unit
        override fun onDone(utteranceId: String?) { finishedSpeaking() }
        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) { finishedSpeaking() }
      })
    }
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    val action = intent?.action
    when (action) {
      ACTION_START -> {
        wakeWord = intent.getStringExtra(EXTRA_WAKE_WORD)?.trim()?.lowercase(Locale.ROOT).orEmpty().ifBlank { "arzu" }
        getSharedPreferences("arzu-background", MODE_PRIVATE).edit().putBoolean("wakeEnabled", true).putString("wakeWord", wakeWord).apply()
        stopping.set(false); wakeModeEnabled = true; holdWifi(); startForegroundSafely(buildNotification("Arzu beklemede — sadece Arzu kelimesini dinliyor")); running = true; startListening()
      }
      ACTION_STOP -> stopServiceWork()
      ACTION_SPEAK -> {
        if (!running) { startForegroundSafely(buildNotification("Arzu önemli bir sonucu seslendiriyor")); running = true }
        speak(intent.getStringExtra(EXTRA_TEXT).orEmpty(), intent.getStringExtra(EXTRA_PRIORITY).orEmpty())
      }
      ACTION_DICTATE -> {
        stopping.set(false); resumeWakeAfterDictation = wakeModeEnabled; startForegroundSafely(buildNotification("Arzu çevrimdışı dinliyor")); running = true; startListening(true)
      }
      null -> {
        val prefs = getSharedPreferences("arzu-background", MODE_PRIVATE)
        if (prefs.getBoolean("wakeEnabled", false)) {
          wakeWord = prefs.getString("wakeWord", "arzu").orEmpty().ifBlank { "arzu" }
          stopping.set(false); wakeModeEnabled = true; holdWifi(); startForegroundSafely(buildNotification("Arzu beklemede — sadece Arzu kelimesini dinliyor")); running = true; startListening()
        }
      }
    }
    return START_STICKY
  }

  private fun startListening(dictation: Boolean = false) {
    if (stopping.get() || !SpeechRecognizer.isRecognitionAvailable(this)) return
    // Arzu konuşurken kendi sesini "Arzu" diye duymasın.
    if (ttsActive && !dictation) return
    dictationMode = dictation
    recognizer?.destroy()
    recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(this) }
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
      putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
      putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
      putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, !dictation)
      putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
      // Wake-word düşük gecikme için çevrimdışı kalabilir; fakat kullanıcı diktesinde
      // Android cihazda Türkçe offline paket yoksa boş sonuç dönmemesi için ağ tanımaya izin ver.
      putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, preferOffline && !dictation)
      putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
      putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 500L)
    }
    try { recognizer?.startListening(intent) } catch (_: Throwable) { scheduleRestart() }
  }

  private fun scheduleRestart() {
    if (stopping.get() || restartPending) return
    restartPending = true
    val delay = (400L * (restartAttempt.coerceAtMost(5) + 1)).coerceAtMost(4000L)
    restartAttempt += 1
    android.os.Handler(mainLooper).postDelayed({ restartPending = false; startListening() }, delay)
  }

  private fun detect(text: String) {
    val normalized = text.lowercase(Locale("tr", "TR")).replace(Regex("[^a-zçğıöşü0-9 ]"), " ").trim()
    if (normalized == wakeWord || normalized.startsWith("$wakeWord ") || normalized.endsWith(" $wakeWord") || normalized.contains(" $wakeWord ")) {
      val now = System.currentTimeMillis()
      if (now - lastWakeAt < 2500L) return
      lastWakeAt = now
      getSharedPreferences("arzu-background", MODE_PRIVATE).edit().putString("pendingWake", text).apply()
      sendBroadcast(Intent(ACTION_WAKE).setPackage(packageName).putExtra(EXTRA_TEXT, text))
      recognizer?.cancel()
      // Uygulama uyandırmayı işlerken (ör. diktayı başlatırken) dinleme kısa süre durur, sonra devam eder.
      android.os.Handler(mainLooper).postDelayed({
        if (!stopping.get() && wakeModeEnabled && !dictationMode && !ttsActive) startListening()
      }, 1400L)
    }
  }

  private fun sendDictation(text: String) {
    sendBroadcast(Intent(ACTION_DICTATION_RESULT).setPackage(packageName).putExtra(EXTRA_TEXT, text)); dictationMode = false
    if (resumeWakeAfterDictation && !stopping.get()) { resumeWakeAfterDictation = false; startListening(false) } else { stopServiceWork() }
  }

  private fun speak(text: String, priority: String) {
    if (text.isBlank()) return
    if (!ttsReady) {
      pendingSpeech.addLast(text to priority)
      return
    }
    tts?.let { engine -> speakReady(engine, text, priority) }
  }

  private fun speakReady(engine: TextToSpeech, text: String, priority: String) {
    engine.language = Locale("tr", "TR")
    engine.setSpeechRate(0.94f)
    val queueMode = if (priority == "critical") TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
    if (!dictationMode) { ttsActive = true; try { recognizer?.cancel() } catch (_: Throwable) {} }
    engine.speak(text, queueMode, Bundle(), "arzu-${System.currentTimeMillis()}")
  }

  /** Kullanıcı kapattığında kalıcı bayrak da kapanır; sistem servisi öldürürse bayrak açık kalır ve yeniden başlatılabilir. */
  private fun stopServiceWork() {
    getSharedPreferences("arzu-background", MODE_PRIVATE).edit().putBoolean("wakeEnabled", false).apply()
    releaseResources()
    try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Throwable) {}
    stopSelf()
  }

  private fun releaseResources() {
    stopping.set(true); wakeModeEnabled = false; resumeWakeAfterDictation = false; running = false; ttsActive = false
    try { recognizer?.cancel(); recognizer?.destroy() } catch (_: Throwable) {}
    recognizer = null
    try { tts?.stop() } catch (_: Throwable) {}
    releaseWifi()
  }

  private fun finishedSpeaking() {
    if (tts?.isSpeaking == true) return
    ttsActive = false
    android.os.Handler(mainLooper).postDelayed({
      if (!stopping.get() && wakeModeEnabled && !dictationMode) startListening()
    }, 500L)
  }

  /** Android 12+ arka plandan mikrofon tipli servis başlatmayı engelleyebilir; çökme yerine sessizce vazgeçilir. */
  private fun startForegroundSafely(notification: Notification) {
    try { startForeground(NOTIFICATION_ID, notification) } catch (_: Throwable) {}
  }

  /** Ekran kapalıyken Wi‑Fi uyku moduna girip sunucu bağlantısını koparmasın. */
  private fun holdWifi() {
    try {
      if (wifiLock == null) {
        val manager = applicationContext.getSystemService(android.content.Context.WIFI_SERVICE) as android.net.wifi.WifiManager
        val mode = if (Build.VERSION.SDK_INT >= 29) android.net.wifi.WifiManager.WIFI_MODE_FULL_LOW_LATENCY else android.net.wifi.WifiManager.WIFI_MODE_FULL_HIGH_PERF
        wifiLock = manager.createWifiLock(mode, "arzu:wifi").also { it.setReferenceCounted(false) }
      }
      if (wifiLock?.isHeld != true) wifiLock?.acquire()
    } catch (_: Throwable) {}
  }

  private fun releaseWifi() {
    try { if (wifiLock?.isHeld == true) wifiLock?.release() } catch (_: Throwable) {}
  }

  private fun createChannel() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val channel = NotificationChannel(CHANNEL_ID, "Arzu ses servisi", NotificationManager.IMPORTANCE_LOW).apply { description = "Arzu'nun düşük güçte wake-word ve ses servisleri"; setShowBadge(false) }
      getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }
  }

  private fun buildNotification(text: String): Notification = NotificationCompat.Builder(this, CHANNEL_ID).setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("Arzu").setContentText(text).setOngoing(true).setCategory(NotificationCompat.CATEGORY_SERVICE).setPriority(NotificationCompat.PRIORITY_LOW).build()

  override fun onPartialResults(results: Bundle?) { if (!dictationMode) results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(::detect) }
  override fun onResults(results: Bundle?) { val texts = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty(); if (dictationMode) { sendDictation(texts.firstOrNull().orEmpty()) } else { texts.forEach(::detect); if (!ttsActive) scheduleRestart() } }
  override fun onError(error: Int) {
    if (dictationMode) { sendDictation(""); return }
    // 12/13: Türkçe çevrimdışı tanıma paketi yok -> ağ tanımaya geç, sonsuz hata döngüsüne girme.
    if (error == SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED || error == SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE) preferOffline = false
    if (!ttsActive) scheduleRestart()
  }
  override fun onReadyForSpeech(params: Bundle?) { restartAttempt = 0 }
  override fun onBeginningOfSpeech() = Unit
  override fun onRmsChanged(rmsdB: Float) = Unit
  override fun onBufferReceived(buffer: ByteArray?) = Unit
  override fun onEndOfSpeech() = Unit
  override fun onEvent(eventType: Int, params: Bundle?) = Unit
  override fun onInit(status: Int) {
    if (status != TextToSpeech.SUCCESS) return
    ttsReady = true
    tts?.language = Locale("tr", "TR")
    tts?.setSpeechRate(0.94f)
    while (pendingSpeech.isNotEmpty()) {
      val (text, priority) = pendingSpeech.removeFirst()
      tts?.let { speakReady(it, text, priority) }
    }
  }
  override fun onBind(intent: Intent?): IBinder? = null
  override fun onDestroy() { releaseResources(); pendingSpeech.clear(); ttsReady = false; try { tts?.shutdown() } catch (_: Throwable) {}; super.onDestroy() }
}
