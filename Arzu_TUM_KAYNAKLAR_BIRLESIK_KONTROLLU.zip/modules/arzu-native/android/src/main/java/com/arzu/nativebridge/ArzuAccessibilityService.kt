package com.arzu.nativebridge

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Kullanıcı Android Ayarları > Erişilebilirlik bölümünden açtığında çalışır.
 * Arzu'nun başka uygulamalarda ekranı okumasını, düğmeye basmasını, yazı yazmasını
 * ve kaydırmasını sağlar. Şifre alanlarının içeriği hiçbir zaman okunmaz veya yazılmaz.
 */
class ArzuAccessibilityService : AccessibilityService() {
  companion object {
    @Volatile var instance: ArzuAccessibilityService? = null
  }

  override fun onServiceConnected() {
    super.onServiceConnected()
    instance = this
  }

  override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

  override fun onInterrupt() {}

  override fun onUnbind(intent: Intent?): Boolean {
    instance = null
    return super.onUnbind(intent)
  }

  override fun onDestroy() {
    instance = null
    super.onDestroy()
  }

  private fun norm(value: String): String =
    value.replace('İ', 'i').replace('I', 'i').replace('ı', 'i').lowercase().trim()

  private fun labelOf(node: AccessibilityNodeInfo): String {
    val text = node.text?.toString().orEmpty()
    if (text.isNotBlank()) return text
    return node.contentDescription?.toString().orEmpty()
  }

  fun currentPackage(): String = rootInActiveWindow?.packageName?.toString().orEmpty()

  fun dumpScreen(): String {
    val root = rootInActiveWindow ?: return ""
    val queue = ArrayList<AccessibilityNodeInfo>()
    queue.add(root)
    val lines = ArrayList<String>()
    var index = 0
    while (index < queue.size && lines.size < 220) {
      val node = queue[index]
      index += 1
      if (node.isVisibleToUser) {
        val flags = ArrayList<String>()
        if (node.isClickable) flags.add("tıklanabilir")
        if (node.isEditable) flags.add("yazı alanı")
        if (node.isScrollable) flags.add("kaydırılabilir")
        if (node.isChecked) flags.add("seçili")
        val label = if (node.isPassword) "(şifre alanı)" else labelOf(node).replace('\n', ' ').take(120)
        if (label.isNotBlank() || node.isEditable || node.isClickable) {
          val hint = if (label.isBlank() && node.isEditable && android.os.Build.VERSION.SDK_INT >= 26) (node.hintText?.toString().orEmpty().take(60)) else ""
          lines.add("- " + (if (label.isNotBlank()) label else hint.ifBlank { "(adsız)" }) + (if (flags.isEmpty()) "" else " [" + flags.joinToString(", ") + "]"))
        }
      }
      for (i in 0 until node.childCount) {
        val child = node.getChild(i)
        if (child != null) queue.add(child)
      }
    }
    return lines.joinToString("\n").take(12000)
  }

  private fun findNode(query: String, accept: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
    val root = rootInActiveWindow ?: return null
    val q = norm(query)
    if (q.isEmpty()) return null
    val queue = ArrayList<AccessibilityNodeInfo>()
    queue.add(root)
    var partial: AccessibilityNodeInfo? = null
    var index = 0
    while (index < queue.size) {
      val node = queue[index]
      index += 1
      if (node.isVisibleToUser && accept(node) && !node.isPassword) {
        val label = norm(labelOf(node))
        if (label.isNotEmpty()) {
          if (label == q) return node
          if (partial == null && label.contains(q)) partial = node
        }
      }
      for (i in 0 until node.childCount) {
        val child = node.getChild(i)
        if (child != null) queue.add(child)
      }
    }
    return partial
  }

  private fun centerOf(node: AccessibilityNodeInfo): Pair<Float, Float>? {
    val rect = android.graphics.Rect()
    node.getBoundsInScreen(rect)
    if (rect.isEmpty) return null
    return Pair(rect.exactCenterX(), rect.exactCenterY())
  }

  /** Düğme/tıklama erişilebilirlik eylemine yanıt vermiyorsa ekrana gerçek dokunuş gönderir. */
  fun tapAt(x: Float, y: Float, durationMs: Long = 60L): Boolean {
    val path = android.graphics.Path()
    path.moveTo(x, y)
    val stroke = android.accessibilityservice.GestureDescription.StrokeDescription(path, 0L, durationMs)
    val gesture = android.accessibilityservice.GestureDescription.Builder().addStroke(stroke).build()
    return dispatchGesture(gesture, null, null)
  }

  private fun swipeVertical(forward: Boolean): Boolean {
    val metrics = resources.displayMetrics
    val x = metrics.widthPixels / 2f
    val from = metrics.heightPixels * (if (forward) 0.72f else 0.28f)
    val to = metrics.heightPixels * (if (forward) 0.28f else 0.72f)
    val path = android.graphics.Path()
    path.moveTo(x, from)
    path.lineTo(x, to)
    val stroke = android.accessibilityservice.GestureDescription.StrokeDescription(path, 0L, 350L)
    return dispatchGesture(android.accessibilityservice.GestureDescription.Builder().addStroke(stroke).build(), null, null)
  }

  fun clickText(target: String): Boolean {
    val found = findNode(target) { true } ?: return false
    var current: AccessibilityNodeInfo? = found
    var depth = 0
    while (current != null && depth < 7) {
      if (current.isClickable && current.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
      current = current.parent
      depth += 1
    }
    val center = centerOf(found) ?: return false
    return tapAt(center.first, center.second)
  }

  fun longClickText(target: String): Boolean {
    val found = findNode(target) { true } ?: return false
    var current: AccessibilityNodeInfo? = found
    var depth = 0
    while (current != null && depth < 7) {
      if (current.isLongClickable && current.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)) return true
      current = current.parent
      depth += 1
    }
    val center = centerOf(found) ?: return false
    return tapAt(center.first, center.second, 800L)
  }

  fun typeText(text: String, target: String): Boolean {
    val root = rootInActiveWindow ?: return false
    var field: AccessibilityNodeInfo? = null
    if (target.isNotBlank()) field = findNode(target) { it.isEditable }
    if (field == null) field = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
    if (field == null || !field.isEditable) {
      val queue = ArrayList<AccessibilityNodeInfo>()
      queue.add(root)
      var index = 0
      field = null
      while (index < queue.size && field == null) {
        val node = queue[index]
        index += 1
        if (node.isEditable && node.isVisibleToUser && !node.isPassword) field = node
        for (i in 0 until node.childCount) {
          val child = node.getChild(i)
          if (child != null) queue.add(child)
        }
      }
    }
    if (field == null || field.isPassword) return false
    field.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
    val args = Bundle()
    args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
    return field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
  }

  fun scroll(forward: Boolean): Boolean {
    val root = rootInActiveWindow ?: return false
    val queue = ArrayList<AccessibilityNodeInfo>()
    queue.add(root)
    var index = 0
    while (index < queue.size) {
      val node = queue[index]
      index += 1
      if (node.isScrollable && node.isVisibleToUser) {
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        if (node.performAction(action)) return true
      }
      for (i in 0 until node.childCount) {
        val child = node.getChild(i)
        if (child != null) queue.add(child)
      }
    }
    // Kaydırılabilir bileşen bulunamazsa (ör. özel çizimli ekranlar) parmakla kaydırma jesti gönderilir.
    return swipeVertical(forward)
  }

  fun global(name: String): Boolean {
    val action = when (name) {
      "back" -> GLOBAL_ACTION_BACK
      "home" -> GLOBAL_ACTION_HOME
      "recents" -> GLOBAL_ACTION_RECENTS
      "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
      "quicksettings" -> GLOBAL_ACTION_QUICK_SETTINGS
      else -> return false
    }
    return performGlobalAction(action)
  }
}
