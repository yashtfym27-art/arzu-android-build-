package com.arzu.nativebridge

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface
import androidx.core.content.ContextCompat
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

class ArzuNativeModule : Module() {
  private var receiver: BroadcastReceiver? = null

  override fun definition() = ModuleDefinition {
    Name("ArzuNative")
    Events("wakeWordDetected", "offlineDictation")

    OnCreate {
      receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
          if (intent?.action == ArzuWakeWordService.ACTION_WAKE) {
            sendEvent("wakeWordDetected", mapOf("text" to (intent.getStringExtra(ArzuWakeWordService.EXTRA_TEXT) ?: "Arzu")))
          }
          if (intent?.action == ArzuWakeWordService.ACTION_DICTATION_RESULT) {
            sendEvent("offlineDictation", mapOf("text" to (intent.getStringExtra(ArzuWakeWordService.EXTRA_TEXT) ?: "")))
          }
        }
      }
      // Wake-word ve tek seferlik dikte sonuçları aynı receiver üzerinden gelir.
      // Önceden yalnızca ACTION_WAKE dinlendiği için kullanıcı konuşması native
      // serviste tanınsa bile JS tarafına hiç ulaşmıyordu.
      val filter = IntentFilter(ArzuWakeWordService.ACTION_WAKE).apply {
        addAction(ArzuWakeWordService.ACTION_DICTATION_RESULT)
      }
      if (android.os.Build.VERSION.SDK_INT >= 33) {
        appContext.reactContext?.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
      } else {
        @Suppress("DEPRECATION")
        appContext.reactContext?.registerReceiver(receiver, filter)
      }
    }

    OnDestroy {
      receiver?.let { appContext.reactContext?.unregisterReceiver(it) }
      receiver = null
    }

    AsyncFunction("startWakeWordService") { wakeWord: String ->
      val context = appContext.reactContext ?: return@AsyncFunction false
      if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return@AsyncFunction false
      val intent = Intent(context, ArzuWakeWordService::class.java).apply {
        action = ArzuWakeWordService.ACTION_START
        putExtra(ArzuWakeWordService.EXTRA_WAKE_WORD, wakeWord.ifBlank { "arzu" })
      }
      try { ContextCompat.startForegroundService(context, intent); true } catch (_: Throwable) { false }
    }

    AsyncFunction("stopWakeWordService") {
      val context = appContext.reactContext ?: return@AsyncFunction false
      context.startService(Intent(context, ArzuWakeWordService::class.java).setAction(ArzuWakeWordService.ACTION_STOP))
      true
    }

    AsyncFunction("speakInBackground") { text: String, priority: String ->
      val context = appContext.reactContext ?: return@AsyncFunction false
      val intent = Intent(context, ArzuWakeWordService::class.java).apply {
        action = ArzuWakeWordService.ACTION_SPEAK
        putExtra(ArzuWakeWordService.EXTRA_TEXT, text)
        putExtra(ArzuWakeWordService.EXTRA_PRIORITY, priority)
      }
      // Servis zaten foreground çalışıyorsa normal startService yeterli; arka plan kısıtına takılmaz.
      try {
        if (ArzuWakeWordService.running) context.startService(intent) else ContextCompat.startForegroundService(context, intent)
        true
      } catch (_: Throwable) { false }
    }

    AsyncFunction("isWakeWordServiceRunning") { ArzuWakeWordService.running }

    AsyncFunction("consumePendingWake") {
      val context = appContext.reactContext ?: return@AsyncFunction ""
      val prefs = context.getSharedPreferences("arzu-background", Context.MODE_PRIVATE)
      val value = prefs.getString("pendingWake", "").orEmpty()
      if (value.isNotBlank()) prefs.edit().remove("pendingWake").apply()
      value
    }

    AsyncFunction("startOfflineDictation") {
      val context = appContext.reactContext ?: return@AsyncFunction false
      if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return@AsyncFunction false
      try { ContextCompat.startForegroundService(context, Intent(context, ArzuWakeWordService::class.java).setAction(ArzuWakeWordService.ACTION_DICTATE)); true } catch (_: Throwable) { false }
    }

    AsyncFunction("getLocalIpv4") {
      // Hem Wi‑Fi hem mobil veri açıkken mobil arayüz (rmnet) değil, Wi‑Fi/hotspot arayüzü seçilir.
      val preferred = listOf("wlan", "swlan", "ap", "softap", "eth")
      val skipped = listOf("rmnet", "ccmni", "tun", "dummy", "p2p", "ppp", "v4-", "clat", "lo")
      val interfaces = (NetworkInterface.getNetworkInterfaces()?.toList() ?: emptyList())
        .filter { iface -> iface.isUp && !iface.isLoopback && !iface.isVirtual && skipped.none { prefix -> iface.name.startsWith(prefix) } }
        .sortedBy { iface ->
          val index = preferred.indexOfFirst { prefix -> iface.name.startsWith(prefix) }
          if (index < 0) 99 else index
        }
      val address = interfaces
        .flatMap { iface -> iface.inetAddresses.toList() }
        .firstOrNull { candidate -> candidate is Inet4Address && !candidate.isLoopbackAddress }
      address?.hostAddress ?: ""
    }

    // Wi‑Fi'de internet yoksa Android trafiği mobil veriye yönlendirip yerel ağ sunucusuna ulaşamaz.
    // Yerel sunucu kullanılırken uygulama süreci Wi‑Fi ağına bağlanır.
    AsyncFunction("bindToWifi") { enable: Boolean ->
      val context = appContext.reactContext ?: return@AsyncFunction false
      val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? android.net.ConnectivityManager ?: return@AsyncFunction false
      if (!enable) {
        manager.bindProcessToNetwork(null)
        return@AsyncFunction true
      }
      @Suppress("DEPRECATION")
      val wifi = manager.allNetworks.firstOrNull { network ->
        val capabilities = manager.getNetworkCapabilities(network)
        capabilities != null && capabilities.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI)
      } ?: return@AsyncFunction false
      manager.bindProcessToNetwork(wifi)
    }

    AsyncFunction("canDrawOverlays") {
      val context = appContext.reactContext ?: return@AsyncFunction false
      android.provider.Settings.canDrawOverlays(context)
    }

    AsyncFunction("openOverlaySettings") {
      val context = appContext.reactContext ?: return@AsyncFunction false
      val intent = Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + context.packageName))
      intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      context.startActivity(intent)
      true
    }

    AsyncFunction("listLaunchableApps") {
      val context = appContext.reactContext ?: return@AsyncFunction emptyList<Map<String, String>>()
      val apps = context.packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
        .filter { info -> context.packageManager.getLaunchIntentForPackage(info.packageName) != null }
        .map { info -> mapOf("packageName" to info.packageName, "label" to info.loadLabel(context.packageManager).toString()) }
        .distinctBy { it["packageName"] }
        .sortedBy { it["label"]?.lowercase() }
      apps
    }

    AsyncFunction("launchApp") { packageName: String ->
      val context = appContext.reactContext ?: return@AsyncFunction false
      val allowed = packageName.isNotBlank()
      val intent = if (allowed) context.packageManager.getLaunchIntentForPackage(packageName) else null
      if (intent == null) return@AsyncFunction false
      intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      context.startActivity(intent)
      true
    }

    AsyncFunction("isAccessibilityEnabled") { ArzuAccessibilityService.instance != null }

    AsyncFunction("openAccessibilitySettings") {
      val context = appContext.reactContext ?: return@AsyncFunction false
      val intent = Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)
      intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      context.startActivity(intent)
      true
    }

    AsyncFunction("readScreen") { ArzuAccessibilityService.instance?.dumpScreen() ?: "" }

    AsyncFunction("foregroundPackage") { ArzuAccessibilityService.instance?.currentPackage() ?: "" }

    AsyncFunction("clickText") { target: String -> ArzuAccessibilityService.instance?.clickText(target) ?: false }

    AsyncFunction("longClickText") { target: String -> ArzuAccessibilityService.instance?.longClickText(target) ?: false }

    AsyncFunction("typeText") { text: String, target: String -> ArzuAccessibilityService.instance?.typeText(text, target) ?: false }

    AsyncFunction("scrollScreen") { forward: Boolean -> ArzuAccessibilityService.instance?.scroll(forward) ?: false }

    AsyncFunction("globalAction") { name: String -> ArzuAccessibilityService.instance?.global(name) ?: false }

    AsyncFunction("getSharedContent") {
      val activity = appContext.currentActivity ?: return@AsyncFunction emptyMap<String, String>()
      val intent = activity.intent ?: return@AsyncFunction emptyMap<String, String>()
      val result = mutableMapOf<String, String>()
      intent.getStringExtra(Intent.EXTRA_TEXT)?.takeIf { it.isNotBlank() }?.let { result["text"] = it }
      result["mimeType"] = intent.type.orEmpty()
      var uri: Uri? = if (android.os.Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java) else @Suppress("DEPRECATION") intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
      if (uri == null && intent.action == Intent.ACTION_SEND_MULTIPLE) {
        // Çoklu paylaşımda ilk dosya alınır.
        val list = if (android.os.Build.VERSION.SDK_INT >= 33) intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java) else @Suppress("DEPRECATION") intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
        uri = list?.firstOrNull()
      }
      if (uri != null) {
        val resolver = activity.contentResolver
        val realType = resolver.getType(uri) ?: intent.type.orEmpty()
        var displayName: String? = null
        try {
          resolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) displayName = cursor.getString(0)
          }
        } catch (_: Exception) {}
        val extension = android.webkit.MimeTypeMap.getSingleton().getExtensionFromMimeType(realType)
          ?: displayName?.substringAfterLast('.', "")?.takeIf { it.isNotBlank() }
          ?: "bin"
        val target = File(cacheDir(), "arzu-shared-${System.currentTimeMillis()}.$extension")
        resolver.openInputStream(uri)?.use { input -> target.outputStream().use { output -> input.copyTo(output) } }
        result["uri"] = Uri.fromFile(target).toString()
        result["name"] = displayName ?: uri.lastPathSegment.orEmpty()
        if (realType.isNotBlank()) result["mimeType"] = realType
      }
      result["mimeType"]?.let { if (it.startsWith("text/") && result["text"] != null) Unit }
      intent.setData(null)
      intent.removeExtra(Intent.EXTRA_TEXT)
      intent.removeExtra(Intent.EXTRA_STREAM)
      result
    }
  }

  private fun cacheDir(): File = appContext.reactContext?.cacheDir ?: File("/data/local/tmp")
}
