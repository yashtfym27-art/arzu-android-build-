import { requireNativeModule } from "expo-modules-core";

export type ArzuNativeModule = {
  startWakeWordService(wakeWord?: string): Promise<boolean>;
  stopWakeWordService(): Promise<boolean>;
  speakInBackground(text: string, priority: string): Promise<boolean>;
  isWakeWordServiceRunning(): Promise<boolean>;
  launchApp(packageName: string): Promise<boolean>;
  getSharedContent(): Promise<{ text?: string; uri?: string; name?: string; mimeType?: string }>;
  isAccessibilityEnabled(): Promise<boolean>;
  openAccessibilitySettings(): Promise<boolean>;
  readScreen(): Promise<string>;
  foregroundPackage(): Promise<string>;
  clickText(target: string): Promise<boolean>;
  typeText(text: string, target: string): Promise<boolean>;
  scrollScreen(forward: boolean): Promise<boolean>;
  globalAction(name: string): Promise<boolean>;
};

export default requireNativeModule<ArzuNativeModule>("ArzuNative");
