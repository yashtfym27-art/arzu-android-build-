# Arzu Wake Word + Proaktif Konuşma Planı

- [x] Wake-word ile aktif konuşma ve proaktif konuşmayı iki ayrı mekanizma olarak ayır
- [x] Olay önceliklendirme ve tek konuşma kuyruğu oluştur
- [x] Kritik/önemli olaylarda TTS, normal/önemsiz olaylarda sessiz çalışma
- [x] Android foreground microphone servisi ve gerçek Android TTS katmanı ekle
- [x] Wake word'ü yalnızca `Arzu` olarak tanımla; `Arzu, uyan` zorunluluğunu kaldır
- [x] Araştırma tamamlanma olayını proaktif konuşma sistemine bağla
- [x] Uygulama içi tip, linter ve birim testlerini çalıştır
- [ ] Android native prebuild/Gradle derlemesini Android SDK bulunan CI veya cihaz ortamında çalıştır
- [ ] Gerçek cihaz matrisi: ekran açık, arka plan, kilitli ekran ve iki eşzamanlı olay
- [ ] Üretim wake-word motoru için cihaz üreticisine göre offline hotword modeli değerlendirmesi
