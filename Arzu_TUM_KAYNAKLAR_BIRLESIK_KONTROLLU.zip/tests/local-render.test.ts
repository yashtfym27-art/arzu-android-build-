import { describe, expect, it } from "vitest";

import { wrapText } from "../server/local-render";
import { localFilePath } from "../server/storage";

describe("yerel render yardımcıları", () => {
  it("uzun metni satırlara böler ve kelimeyi ortadan kesmez", () => {
    const wrapped = wrapText("Fikirden sonuca daha hızlı ve daha kişisel", 14);
    for (const line of wrapped.split("\n")) expect(line.length).toBeLessThanOrEqual(14);
    expect(wrapped.replace(/\n/g, " ")).toBe("Fikirden sonuca daha hızlı ve daha kişisel");
  });

  it("satır sayısını sınırlar", () => {
    const wrapped = wrapText("a ".repeat(200), 6, 3);
    expect(wrapped.split("\n").length).toBeLessThanOrEqual(3);
  });

  it("yerel depolama klasörünün dışına çıkmaya izin vermez", () => {
    expect(localFilePath("../../etc/passwd")).toContain("etc");
    expect(localFilePath("../../etc/passwd").includes("..")).toBe(false);
  });
});
