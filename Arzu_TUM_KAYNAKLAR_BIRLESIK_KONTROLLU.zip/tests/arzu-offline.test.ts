import { describe, expect, it } from "vitest";
import { generateOfflineReply } from "../lib/arzu-offline";

describe("Arzu çevrimdışı çekirdeği", () => {
  it("basit Türkçe sohbeti bağlantısız yanıtlar", () => {
    const result = generateOfflineReply("Nasılsın", []);
    expect(result.kind).toBe("conversation");
    expect(result.text).toContain("bağlantı olmadan");
  });
  it("basit hesapları yerelde yapar", () => {
    const result = generateOfflineReply("12 * 4 kaç eder?", []);
    expect(result.kind).toBe("calculation");
    expect(result.text).toContain("48");
  });
  it("aynı yerel hafıza bağlamını kullanır", () => {
    const result = generateOfflineReply("Hafızamda ne var?", [{ id: "1", text: "Türkçe konuş", category: "preference", createdAt: "", updatedAt: "" }]);
    expect(result.text).toContain("Türkçe konuş");
  });
});
