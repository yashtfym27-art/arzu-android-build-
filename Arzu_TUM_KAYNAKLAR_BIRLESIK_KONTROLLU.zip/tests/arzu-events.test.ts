import { describe, expect, it } from "vitest";

import { classifyResearchResult, createArzuEvent } from "../lib/arzu-event-policy";

describe("Arzu proaktif konuşma önceliklendirmesi", () => {
  it("önemli araştırma sonucunu sesli olay yapar", () => {
    const event = classifyResearchResult("Önemli risk bulundu: mevcut yöntem güvenli değil.");
    expect(event.priority).toBe("important");
    expect(event.speech).toContain("araştırmayı tamamladım");
  });

  it("normal araştırma sonucunu sessiz bırakır", () => {
    const event = classifyResearchResult("Genel bilgi özeti hazırlandı.");
    expect(event.priority).toBe("normal");
    expect(event.priority === "critical" || event.priority === "important").toBe(false);
  });

  it("kritik ve önemli olayları çakışmadan kuyruğa alır", () => {
    const first = createArzuEvent({ kind: "warning", priority: "important", title: "Birinci", speech: "Birinci önemli olay." });
    const second = createArzuEvent({ kind: "error", priority: "critical", title: "İkinci", speech: "İkinci kritik olay." });
    const queue = [first, second].sort((a, b) => (b.priority === "critical" ? 1 : 0) - (a.priority === "critical" ? 1 : 0));
    expect(queue[0].priority).toBe("critical");
  });
});
