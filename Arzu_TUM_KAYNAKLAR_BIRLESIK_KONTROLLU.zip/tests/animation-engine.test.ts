import { describe, expect, it } from "vitest";

import { createAnimationSource, getAnimationCapabilities, type AnimationPlan } from "../server/animation-engine";

const plan: AnimationPlan = {
  title: "Arzu tanıtım animasyonu",
  platform: "reels",
  durationSeconds: 6,
  background: "#14121D",
  aspectRatio: "9:16",
  formatLabel: "Instagram Reels",
  width: 1080,
  height: 1920,
  fps: 30,
  scenes: [
    { index: 1, durationSeconds: 3, text: "Fikrin varsa Arzu hazır", subtext: "Samimi, hızlı ve kişisel", accent: "#B8ACFF", effect: "fade" },
    { index: 2, durationSeconds: 3, text: "Birlikte üretelim", subtext: "", accent: "#7CDBBE", effect: "zoomIn" },
  ],
};

describe("animation engine", () => {
  it("reproducible source contains format, fps and scene timeline", () => {
    const source = createAnimationSource(plan);
    expect(source).toContain("1080");
    expect(source).toContain("fps");
    expect(source).toContain("Fikrin varsa Arzu hazır");
    expect(source).toContain("frameAt");
  });

  it("reports real render availability without pretending when credentials are absent", () => {
    const capabilities = getAnimationCapabilities();
    expect(capabilities.planner).toBe(true);
    expect(capabilities.deterministicSource).toBe(true);
    expect(typeof capabilities.videoRender).toBe("boolean");
  });
});
