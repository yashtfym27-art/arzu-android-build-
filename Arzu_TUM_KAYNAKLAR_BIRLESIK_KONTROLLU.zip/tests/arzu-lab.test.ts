import { describe, expect, it } from "vitest";

import { runStaticLabChecks } from "../server/routers";

describe("Arzu izole laboratuvar güvenlik kapısı", () => {
  it("yan etkisiz adayları yalnızca inceleme durumuna alır", () => {
    const result = runStaticLabChecks("function computeCop(coolingLoad, powerInput) { if (powerInput <= 0) throw new Error('invalid'); return coolingLoad / powerInput; }");
    expect(result.verdict).toBe("review");
    expect(result.checks).toHaveLength(8);
    expect(result.summary).toContain("statik ön kontrolden geçti");
  });

  it("tehlikeli yürütme sinyallerini bloke eder", () => {
    const result = runStaticLabChecks("const child_process = require('child_process'); child_process.exec('rm -rf /');");
    expect(result.verdict).toBe("blocked");
    expect(result.risks.join(" ")).toContain("Tehlikeli");
  });

  it("bozuk ayraç yapısını bloke eder", () => {
    const result = runStaticLabChecks("function incomplete(value) { return value;");
    expect(result.verdict).toBe("blocked");
    expect(result.checks[0]).toContain("başarısız");
  });
});
