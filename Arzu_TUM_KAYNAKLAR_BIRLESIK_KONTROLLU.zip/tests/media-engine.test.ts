import { describe, expect, it } from "vitest";

import { createSrt, getMediaCapabilities, type MediaPlan } from "../server/media-engine";

const plan: MediaPlan = {
  title: "Arzu reklamı",
  platform: "reels",
  durationSeconds: 6,
  hook: "İşlerini birlikte çözelim.",
  callToAction: "Arzu'yu keşfet",
  voiceStyle: "samimi ve net",
  aspectRatio: "9:16",
  formatLabel: "Instagram Reels",
  scenes: [
    { index: 1, durationSeconds: 3, visualPrompt: "A calm phone assistant interface", narration: "Arzu yanında.", onScreenText: "Her fikir için" },
    { index: 2, durationSeconds: 3, visualPrompt: "A creator planning a video", narration: "Fikrini içeriğe dönüştür.", onScreenText: "Hemen başla" },
  ],
};

describe("Arzu içerik ve medya motoru", () => {
  it("sahnelerden deterministik SRT altyazı üretir", () => {
    const srt = createSrt(plan);
    expect(srt).toContain("00:00:00,000 --> 00:00:03,000");
    expect(srt).toContain("Her fikir için");
    expect(srt).toContain("00:00:03,000 --> 00:00:06,000");
  });

  it("harici yapılandırma yoksa bunu açıkça bildirir", () => {
    const capabilities = getMediaCapabilities();
    expect(capabilities.planner.available).toBe(true);
    expect(capabilities.publishing.available).toBe(false);
    expect(typeof capabilities.videoRender.note).toBe("string");
  });
});
