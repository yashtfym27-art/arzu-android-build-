import { describe, expect, it } from "vitest";

import { resolveArzuAudioUrl } from "../lib/arzu-audio";

describe("Arzu ses URL'si", () => {
  it("relative storage path'i backend tam adresine çevirir", () => {
    expect(resolveArzuAudioUrl("https://api.example.test/", "/manus-storage/a.mp3")).toBe(
      "https://api.example.test/manus-storage/a.mp3",
    );
  });

  it("zaten tam olan provider URL'sini değiştirmez", () => {
    expect(resolveArzuAudioUrl("https://api.example.test", "https://cdn.example.test/a.mp3")).toBe(
      "https://cdn.example.test/a.mp3",
    );
  });
});
