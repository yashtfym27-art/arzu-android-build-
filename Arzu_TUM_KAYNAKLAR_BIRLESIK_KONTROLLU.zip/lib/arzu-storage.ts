import AsyncStorage from "@react-native-async-storage/async-storage";

import {
  DEFAULT_SETTINGS,
  type ArzuSettings,
  type ChatMessage,
  type LabRun,
  type MemoryItem,
  type ResearchTask,
} from "@/lib/arzu-types";

const KEYS = {
  chats: "arzu.chats.v1",
  memories: "arzu.memories.v1",
  tasks: "arzu.research-tasks.v1",
  labs: "arzu.lab-runs.v1",
  settings: "arzu.settings.v1",
};

async function getJson<T>(key: string, fallback: T): Promise<T> {
  try {
    const stored = await AsyncStorage.getItem(key);
    return stored ? (JSON.parse(stored) as T) : fallback;
  } catch {
    return fallback;
  }
}

async function setJson<T>(key: string, value: T): Promise<void> {
  await AsyncStorage.setItem(key, JSON.stringify(value));
}

export const arzuStorage = {
  getChats: () => getJson<ChatMessage[]>(KEYS.chats, []),
  saveChats: (items: ChatMessage[]) => setJson(KEYS.chats, items.slice(-80)),
  getMemories: () => getJson<MemoryItem[]>(KEYS.memories, []),
  saveMemories: (items: MemoryItem[]) => setJson(KEYS.memories, items.slice(0, 60)),
  getTasks: () => getJson<ResearchTask[]>(KEYS.tasks, []),
  saveTasks: (items: ResearchTask[]) => setJson(KEYS.tasks, items.slice(0, 30)),
  getLabs: () => getJson<LabRun[]>(KEYS.labs, []),
  saveLabs: (items: LabRun[]) => setJson(KEYS.labs, items.slice(0, 25)),
  async getSettings(): Promise<ArzuSettings> {
    const stored = await getJson<Partial<ArzuSettings>>(KEYS.settings, {});
    const settings = { ...DEFAULT_SETTINGS, ...stored };
    if (settings.voiceName === "tr-TR") {
      return { ...settings, voiceName: DEFAULT_SETTINGS.voiceName, speechReplies: true };
    }
    return settings;
  },
  saveSettings: (settings: ArzuSettings) => setJson(KEYS.settings, settings),
  async resetPrivateData(): Promise<void> {
    await AsyncStorage.multiRemove([KEYS.chats, KEYS.memories, KEYS.tasks, KEYS.labs]);
  },
};
