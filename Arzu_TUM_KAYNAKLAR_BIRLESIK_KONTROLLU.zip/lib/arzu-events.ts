import { Platform } from "react-native";
import * as Speech from "expo-speech";
import { eventPriorityRank, type ArzuEventKind, type ArzuEventPriority, type ArzuProactiveEvent, classifyResearchResult, classifySystemError, createArzuEvent } from "@/lib/arzu-event-policy";

export { classifyResearchResult, classifySystemError, createArzuEvent } from "@/lib/arzu-event-policy";
export type { ArzuEventKind, ArzuEventPriority, ArzuProactiveEvent } from "@/lib/arzu-event-policy";


type NativeArzuModule = {
  startWakeWordService: (wakeWord: string) => Promise<boolean>;
  stopWakeWordService: () => Promise<boolean>;
  speakInBackground: (text: string, priority: string) => Promise<boolean>;
  isWakeWordServiceRunning: () => Promise<boolean>;
  consumePendingWake?: () => Promise<string>;
  addListener?: (eventName: string, listener: (event: { text?: string }) => void) => { remove: () => void };
  startOfflineDictation?: () => Promise<boolean>;
  getLocalIpv4?: () => Promise<string>;
  bindToWifi?: (enable: boolean) => Promise<boolean>;
  canDrawOverlays?: () => Promise<boolean>;
  openOverlaySettings?: () => Promise<boolean>;
};

let nativeArzu: NativeArzuModule | null | undefined;
function getNativeArzu() {
  if (nativeArzu !== undefined) return nativeArzu;
  if (Platform.OS !== "android") {
    nativeArzu = null;
    return nativeArzu;
  }
  try {
    // Lazy-load so web previews and Node tests never parse the native bridge.
    const core = require("expo-modules-core");
    nativeArzu = core.requireNativeModule("ArzuNative") as NativeArzuModule;
  } catch {
    nativeArzu = null;
  }
  return nativeArzu;
}

const speechQueue: ArzuProactiveEvent[] = [];
let speaking = false;
let wakeSubscription: { remove: () => void } | null = null;
let dictationSubscription: { remove: () => void } | null = null;
let onWakeWord: ((text: string) => void) | null = null;
let onDictation: ((text: string) => void) | null = null;

function isExpired(event: ArzuProactiveEvent) {
  return event.expiresAt !== undefined && event.expiresAt < Date.now();
}

async function speakNext() {
  if (speaking) return;
  while (speechQueue.length && (speechQueue[0].priority === "trivial" || isExpired(speechQueue[0]))) speechQueue.shift();
  const event = speechQueue.shift();
  if (!event || event.requiresSpeech === false) return;
  speaking = true;
  try {
    const native = getNativeArzu();
    // Servis arka planda başlatılamazsa (Android 12+ kısıtı) cihaz TTS'ine düş.
    const nativeSpoke = native ? await native.speakInBackground(event.speech, event.priority).catch(() => false) : false;
    if (!nativeSpoke) {
        await new Promise<void>((resolve) => {
        Speech.speak(event.speech, { language: "tr-TR", rate: 0.94, onDone: () => resolve(), onStopped: () => resolve(), onError: () => resolve() });
      });
    }
  } finally {
    speaking = false;
    if (speechQueue.length) void speakNext();
  }
}

export const arzuProactiveSpeech = {
  enqueue(event: ArzuProactiveEvent) {
    if (event.priority !== "critical" && event.priority !== "important") return false;
    if (event.requiresSpeech === false) return false;
    const duplicate = speechQueue.some((queued) => queued.kind === event.kind && queued.title === event.title);
    if (duplicate) return false;
    speechQueue.push(event);
    speechQueue.sort((a, b) => eventPriorityRank[b.priority] - eventPriorityRank[a.priority] || a.createdAt - b.createdAt);
    void speakNext();
    return true;
  },
  clearNormal() {
    for (let index = speechQueue.length - 1; index >= 0; index -= 1) {
      if (speechQueue[index].priority === "normal") speechQueue.splice(index, 1);
    }
  },
  pendingCount() {
    return speechQueue.length;
  },
};

export const arzuWakeWord = {
  async start(onDetected: (text: string) => void) {
    onWakeWord = onDetected;
    const native = getNativeArzu();
    if (native) {
      if (!wakeSubscription && native.addListener) {
        wakeSubscription = native.addListener("wakeWordDetected", (event) => onWakeWord?.(event.text ?? "Arzu"));
      }
      const started = await native.startWakeWordService("arzu");
      const pending = await native.consumePendingWake?.();
      if (pending) onWakeWord?.(pending);
      return started;
    }
    return false;
  },
  async stop() {
    wakeSubscription?.remove();
    wakeSubscription = null;
    dictationSubscription?.remove();
    dictationSubscription = null;
    onWakeWord = null;
    onDictation = null;
    const native = getNativeArzu();
    if (native) return native.stopWakeWordService();
    return false;
  },
  async isRunning() {
    const native = getNativeArzu();
    return native ? native.isWakeWordServiceRunning() : false;
  },
  async speakNow(text: string, priority = "important") {
    const native = getNativeArzu();
    return native ? native.speakInBackground(text, priority) : false;
  },
  isNativeAvailable() {
    return Boolean(getNativeArzu());
  },
  async getLocalIpv4() {
    const native = getNativeArzu();
    return native?.getLocalIpv4 ? native.getLocalIpv4() : "";
  },
  async bindToWifi(enable: boolean) {
    const native = getNativeArzu();
    return native?.bindToWifi ? native.bindToWifi(enable) : false;
  },
  async canDrawOverlays() {
    const native = getNativeArzu();
    return native?.canDrawOverlays ? native.canDrawOverlays() : false;
  },
  async openOverlaySettings() {
    const native = getNativeArzu();
    return native?.openOverlaySettings ? native.openOverlaySettings() : false;
  },
  async dictate(onResult: (text: string) => void) {
    const native = getNativeArzu();
    if (!native?.startOfflineDictation || !native.addListener) return false;
    onDictation = onResult;
    dictationSubscription?.remove();
    dictationSubscription = native.addListener("offlineDictation", (event) => {
      const text = event.text?.trim() ?? "";
      onDictation?.(text);
      dictationSubscription?.remove();
      dictationSubscription = null;
      onDictation = null;
    });
    return native.startOfflineDictation();
  },
};

export function stopArzuSpeech() {
  Speech.stop();
  speechQueue.splice(0, speechQueue.length);
  speaking = false;
}
