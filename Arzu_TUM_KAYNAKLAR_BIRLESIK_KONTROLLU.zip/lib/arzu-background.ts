import { Platform } from "react-native";
import * as BackgroundTask from "expo-background-task";
import * as TaskManager from "expo-task-manager";

export const ARZU_BACKGROUND_TASK = "arzu-background-research-sync";

if (Platform.OS !== "web" && !TaskManager.isTaskDefined(ARZU_BACKGROUND_TASK)) {
  TaskManager.defineTask(ARZU_BACKGROUND_TASK, async () => {
    try {
      // Android/iOS çalışma zamanını sistem belirler. Bu görev yalnızca ertelenebilir,
      // kullanıcının talep ettiği araştırma güncellemelerini senkronize etmek içindir.
      return BackgroundTask.BackgroundTaskResult.Success;
    } catch {
      return BackgroundTask.BackgroundTaskResult.Failed;
    }
  });
}

export async function setBackgroundResearch(enabled: boolean): Promise<void> {
  if (Platform.OS === "web") return;
  const registered = await TaskManager.isTaskRegisteredAsync(ARZU_BACKGROUND_TASK);
  if (enabled && !registered) {
    await BackgroundTask.registerTaskAsync(ARZU_BACKGROUND_TASK, { minimumInterval: 15 });
  }
  if (!enabled && registered) {
    await BackgroundTask.unregisterTaskAsync(ARZU_BACKGROUND_TASK);
  }
}
