import * as FileSystem from "expo-file-system/legacy";
import * as MediaLibrary from "expo-media-library";
import { getApiBaseUrl } from "@/constants/oauth";

export async function saveMediaToGallery(url: string, kind: "photo" | "video" = "video") {
  if (!url?.trim()) throw new Error("Galeriye kaydedilecek medya adresi bulunamadı.");
  // Yerel sunucu depolaması /arzu-files/... gibi göreli URL döndürebilir.
  // Bunları uygulamanın o an kullandığı sunucu adresine bağla.
  const cleanUrl = url.trim();
  const absoluteUrl = /^https?:\/\//i.test(cleanUrl)
    ? cleanUrl
    : cleanUrl.startsWith("/") && getApiBaseUrl()
      ? `${getApiBaseUrl().replace(/\/$/, "")}${cleanUrl}`
      : "";
  if (!absoluteUrl) throw new Error("Medya adresi sunucu adresine bağlanamadı. Profil > Sunucu adresini kontrol et.");
  const permission = await MediaLibrary.requestPermissionsAsync(true);
  if (!permission.granted) throw new Error("Galeri izni verilmedi.");
  const extension = kind === "photo" ? "jpg" : "mp4";
  const directory = FileSystem.cacheDirectory ?? FileSystem.documentDirectory;
  if (!directory) throw new Error("Cihazın geçici dosya alanı kullanılamıyor.");
  const localUri = `${directory}arzu-${Date.now()}.${extension}`;
  const download = await FileSystem.downloadAsync(absoluteUrl, localUri, { headers: { Accept: kind === "video" ? "video/mp4,*/*" : "image/*,*/*" } });
  if (download.status < 200 || download.status >= 300) throw new Error(`Medya indirilemedi (${download.status}). Wi‑Fi ve sunucu adresini kontrol et.`);
  const asset = await MediaLibrary.createAssetAsync(download.uri);
  try {
    const album = await MediaLibrary.getAlbumAsync("Arzu");
    if (album) await MediaLibrary.addAssetsToAlbumAsync([asset], album, false);
    else await MediaLibrary.createAlbumAsync("Arzu", asset, false);
  } catch { /* asset oluşturuldu; albüm desteği olmayan cihazlarda yine de galeridedir */ }
  try { await FileSystem.deleteAsync(download.uri, { idempotent: true }); } catch { /* cache temizliği başarısız olsa da kayıt tamamdır */ }
  return asset;
}
