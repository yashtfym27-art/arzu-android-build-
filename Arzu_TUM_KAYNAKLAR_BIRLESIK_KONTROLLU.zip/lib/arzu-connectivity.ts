import { getApiBaseUrl, saveRuntimeApiBaseUrl } from "@/constants/oauth";
import { arzuWakeWord } from "@/lib/arzu-events";
import { Platform } from "react-native";

export type ServerState = "checking" | "online" | "server-down" | "no-internet";

const PRIVATE_HOST = /^(localhost|127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|169\.254\.|[^./:]+\.local)/i;

/** Adres yerel ağdaki bir bilgisayara mı işaret ediyor? (http://192.168.x.x:3000 gibi) */
export function isPrivateUrl(url: string) {
  const host = /^https?:\/\/([^/:]+)/i.exec(url.trim())?.[1];
  return Boolean(host && PRIVATE_HOST.test(host));
}

async function fetchWithTimeout(url: string, ms: number) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), ms);
  try { return await fetch(url, { signal: controller.signal, headers: { Accept: "application/json" } }); }
  finally { clearTimeout(timer); }
}

/** /api/health yanıtı gerçekten Arzu sunucusundan mı geliyor? */
async function probe(baseUrl: string, ms: number): Promise<boolean> {
  try {
    const response = await fetchWithTimeout(`${baseUrl.replace(/\/+$/, "")}/api/health`, ms);
    if (!response.ok) return false;
    const data = await response.json().catch(() => null) as { ok?: boolean; app?: string } | null;
    return Boolean(data?.ok) && (data?.app === undefined || data.app === "arzu");
  } catch { return false; }
}

// Yerel sunucu kullanılırken uygulama süreci Wi‑Fi ağına bağlanır. Wi‑Fi'de internet yoksa Android
// trafiği mobil veriye yönlendirir ve 192.168.x.x adreslerine hiç ulaşılamaz; bu bağlama bunu önler.
let bound: boolean | null = null;
export async function ensureWifiBinding(): Promise<void> {
  if (Platform.OS !== "android") return;
  const wantBound = isPrivateUrl(getApiBaseUrl());
  if (bound === wantBound) return;
  try { if (await arzuWakeWord.bindToWifi(wantBound)) bound = wantBound; } catch { /* eski APK: fonksiyon yok */ }
}

let lastDiscoveryAt = 0;
let discovering: Promise<string | null> | null = null;

function candidateOrder(): number[] {
  const first = [...Array.from({ length: 39 }, (_, i) => i + 2), ...Array.from({ length: 31 }, (_, i) => i + 100)];
  const rest = Array.from({ length: 254 }, (_, i) => i + 1).filter((n) => !first.includes(n));
  return [...first, ...rest];
}

async function scanSubnet(): Promise<string | null> {
  const localIp = await arzuWakeWord.getLocalIpv4();
  const match = localIp.match(/^(\d+\.\d+\.\d+)\.\d+$/);
  if (!match) return null;
  const prefix = match[1];
  const order = candidateOrder();
  // Sunucu 3000 doluysa 3001/3002'ye kayabilir; önce 3000 sonra diğerleri taranır.
  for (const port of [3000, 3001, 3002]) {
    for (let offset = 0; offset < order.length; offset += 80) {
      const batch = order.slice(offset, offset + 80);
      const results = await Promise.all(batch.map(async (last) => {
        const url = `http://${prefix}.${last}:${port}`;
        return (await probe(url, 700)) ? url : null;
      }));
      const found = results.find(Boolean);
      if (found) return found;
    }
  }
  return null;
}

/** Aynı Wi‑Fi ağında Arzu sunucusunu bulur. Aynı anda tek tarama çalışır, 30 sn içinde tekrarlanmaz. */
export function discoverLocalArzuServer(force = false): Promise<string | null> {
  if (Platform.OS !== "android") return Promise.resolve(null);
  if (discovering) return discovering;
  if (!force && Date.now() - lastDiscoveryAt < 30_000) return Promise.resolve(null);
  discovering = (async () => {
    try {
      lastDiscoveryAt = Date.now();
      await ensureWifiBinding();
      const found = await scanSubnet();
      if (found) { await saveRuntimeApiBaseUrl(found); bound = null; await ensureWifiBinding(); }
      return found;
    } finally { discovering = null; }
  })();
  return discovering;
}

/** İnternet var ama Arzu sunucusu kapalıysa bunu "internet yok"tan ayırır. */
export async function checkServer(): Promise<ServerState> {
  await ensureWifiBinding();
  const base = getApiBaseUrl();
  if (base && await probe(base, 3000)) return "online";
  try { if (await discoverLocalArzuServer()) return "online"; } catch { /* yerel ağ taraması başarısız */ }
  try {
    await fetchWithTimeout("https://www.gstatic.com/generate_204", 4000);
    return "server-down";
  } catch {
    return "no-internet";
  }
}

let recovering: Promise<boolean> | null = null;
/** Bir istek ağ hatasıyla düştüğünde adresi doğrular, gerekirse sunucuyu yeniden bulur. */
export function recoverConnection(): Promise<boolean> {
  if (recovering) return recovering;
  recovering = (async () => {
    try {
      await ensureWifiBinding();
      const base = getApiBaseUrl();
      if (base && await probe(base, 2500)) return true;
      return Boolean(await discoverLocalArzuServer(true));
    } catch { return false; } finally { recovering = null; }
  })();
  return recovering;
}

export async function testServerUrl(rawUrl: string): Promise<{ ok: boolean; message: string }> {
  const url = rawUrl.trim().replace(/\/+$/, "");
  if (!/^https?:\/\/[^\s/]+/i.test(url)) return { ok: false, message: "Adres http:// veya https:// ile başlamalı. Wi‑Fi örneği: http://192.168.1.20:3000" };
  try {
    if (isPrivateUrl(url)) { bound = null; await ensureWifiBinding(); }
    const response = await fetchWithTimeout(`${url}/api/health`, 6000);
    return response.ok ? { ok: true, message: "Sunucu yanıt verdi." } : { ok: false, message: `Sunucu yanıt verdi ama hata döndü (${response.status}).` };
  } catch {
    return { ok: false, message: "Bu adrese ulaşılamadı. Sunucu kapalı olabilir, telefon ve bilgisayar aynı Wi‑Fi'de olmayabilir veya Windows güvenlik duvarı 3000 portunu engelliyor olabilir." };
  }
}
