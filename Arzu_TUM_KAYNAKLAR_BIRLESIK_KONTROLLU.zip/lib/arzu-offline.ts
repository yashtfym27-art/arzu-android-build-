import type { MemoryItem } from "./arzu-types";

type OfflineReply = { text: string; kind: "conversation" | "memory" | "calculation" | "command" };

function clean(value: string) { return value.trim().replace(/\s+/g, " "); }

function tryCalculate(input: string): string | null {
  const candidate = input.toLocaleLowerCase("tr-TR").replace(/kaç\s*(eder|dır|dir)\??/g, "").replace(/hesapla|hesapla\s*:/g, "").replace(/üzeri|üssü/g, "^").replace(/çarpı|çarp/g, "*").replace(/bölü/g, "/").replace(/artı/g, "+").replace(/eksi/g, "-").replace(/,/g, ".").trim();
  if (!candidate || !/^[0-9+\-*/().%\s^]+$/.test(candidate) || !/[+\-*/^%]/.test(candidate)) return null;
  const normalized = candidate.replace(/\^/g, "**");
  if (!/^[0-9+\-*/().%\s*]+$/.test(normalized)) return null;
  try {
    const result = Function(`"use strict"; return (${normalized});`)();
    if (typeof result !== "number" || !Number.isFinite(result)) return null;
    return `Hemen hesapladım: ${Number(result.toFixed(10)).toLocaleString("tr-TR")}.`;
  } catch { return null; }
}

export function generateOfflineReply(input: string, memories: MemoryItem[]): OfflineReply {
  const text = clean(input);
  const lower = text.toLocaleLowerCase("tr-TR");
  const calculation = tryCalculate(text);
  if (calculation) return { text: calculation, kind: "calculation" };
  if (/ne hatırlıyorsun|hafızam|hatırladıkların/.test(lower)) {
    if (!memories.length) return { text: "Şu an cihazdaki kalıcı hafızamda kayıtlı bir bilgi yok.", kind: "memory" };
    return { text: `Cihazdaki hafızamda şunlar var: ${memories.slice(-5).map((item) => item.text).join("; ")}.`, kind: "memory" };
  }
  if (/^(naber|ne haber|nasılsın|iyi misin)/.test(lower)) return { text: "İyiyim kaptanım; bağlantı olmadan da buradayım. İnternet gelince daha güçlü çevrimiçi Arzu'ya geçeceğim.", kind: "conversation" };
  if (/^(merhaba|selam|günaydın|iyi akşamlar)/.test(lower)) return { text: "Merhaba kaptanım. Şu an çevrimdışı yerel moddayım ama sohbet, hafıza ve basit hesaplarda yanındayım.", kind: "conversation" };
  if (/saat kaç|bugün günlerden|tarih ne/.test(lower)) return { text: `Cihaz saatine göre şu an ${new Date().toLocaleString("tr-TR", { dateStyle: "full", timeStyle: "short" })}.`, kind: "command" };
  if (/intern(et)? var mı|bağlantı/.test(lower)) return { text: "Şu anda çevrimdışı yerel moddayım. Bağlantı geri geldiğinde araştırma ve güçlü AI yanıtlarını otomatik kullanacağım.", kind: "command" };
  return { text: `Şu an çevrimdışı yerel Arzu olarak çalışıyorum. “${text}” isteğini temel sohbet ve cihaz içi işlemler kapsamında ele alabilirim; güncel araştırma veya karmaşık analiz için internet geri geldiğinde devam edelim.`, kind: "conversation" };
}
