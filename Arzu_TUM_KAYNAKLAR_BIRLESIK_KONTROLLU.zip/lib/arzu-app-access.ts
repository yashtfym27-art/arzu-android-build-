import { Platform } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { requireNativeModule } from "expo-modules-core";

export type InstalledApp = { packageName: string; label: string };
const KEY = "arzu.allowed.app.packages";

type NativeAppBridge = { listLaunchableApps: () => Promise<InstalledApp[]>; launchApp: (packageName: string) => Promise<boolean> };

function nativeBridge(): NativeAppBridge | null {
  if (Platform.OS !== "android") return null;
  try { return requireNativeModule<NativeAppBridge>("ArzuNative"); } catch { return null; }
}

export async function listInstalledApps(): Promise<InstalledApp[]> {
  const native = nativeBridge();
  if (!native) return [];
  return native.listLaunchableApps();
}

export const ARZU_OWN_PACKAGE = "com.app.arzuassistant";

/** Arzu kendi uygulamasını her zaman yönetebilir; diğer uygulamalar Profil'den tek tek açılır. */
export async function getAllowedPackages(): Promise<string[]> {
  const raw = await AsyncStorage.getItem(KEY);
  let stored: string[] = [];
  if (raw) {
    try { const parsed = JSON.parse(raw); if (Array.isArray(parsed)) stored = parsed.filter((item): item is string => typeof item === "string"); } catch { stored = []; }
  }
  return stored.includes(ARZU_OWN_PACKAGE) ? stored : [...stored, ARZU_OWN_PACKAGE];
}

export async function setAllowedPackages(packages: string[]) {
  await AsyncStorage.setItem(KEY, JSON.stringify([...new Set(packages)]));
}

export async function launchAllowedApp(packageName: string): Promise<boolean> {
  const allowed = await getAllowedPackages();
  if (!allowed.includes(packageName)) return false;
  return (await nativeBridge()?.launchApp(packageName)) ?? false;
}
