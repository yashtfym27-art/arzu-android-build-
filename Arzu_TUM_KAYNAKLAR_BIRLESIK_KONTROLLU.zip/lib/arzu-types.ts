export type ArzuMode = "chat" | "research" | "vision";

export type ChatMessage = {
  id: string;
  role: "user" | "assistant";
  text: string;
  createdAt: string;
  mode?: ArzuMode;
};

export type MemoryItem = {
  id: string;
  text: string;
  category: "preference" | "profile" | "goal" | "work" | "other";
  createdAt: string;
  updatedAt: string;
  pinned?: boolean;
};

export type ResearchTask = {
  id: string;
  title: string;
  prompt: string;
  status: "queued" | "running" | "completed" | "failed";
  createdAt: string;
  completedAt?: string;
  summary?: string;
  sourceNote?: string;
};

export type LabRun = {
  id: string;
  candidate: string;
  domain: string;
  source?: string;
  status: "review" | "passed" | "blocked";
  createdAt: string;
  report: string;
  checks: string[];
};

export type ArzuSettings = {
  wakeWord: boolean;
  speechReplies: boolean;
  privateMode: boolean;
  backgroundResearch: boolean;
  voiceName: string;
};

export const DEFAULT_SETTINGS: ArzuSettings = {
  wakeWord: true,
  speechReplies: true,
  privateMode: true,
  backgroundResearch: true,
  voiceName: "Derya — doğal Türkçe kadın sesi",
};
