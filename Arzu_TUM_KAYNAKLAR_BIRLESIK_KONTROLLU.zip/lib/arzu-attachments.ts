import * as DocumentPicker from "expo-document-picker";
import * as ImagePicker from "expo-image-picker";
import * as FileSystem from "expo-file-system/legacy";
import { Platform } from "react-native";
import { requireNativeModule } from "expo-modules-core";

export type AttachmentPayload = { dataUrl: string; mimeType: string; name: string };
type NativeBridge = { getSharedContent: () => Promise<{ text?: string; uri?: string; name?: string; mimeType?: string }> };

function nativeBridge(): NativeBridge | null {
  if (Platform.OS !== "android") return null;
  try { return requireNativeModule<NativeBridge>("ArzuNative"); } catch { return null; }
}

async function fileToPayload(uri: string, mimeType: string, name: string): Promise<AttachmentPayload> {
  const base64 = await FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.Base64 });
  return { dataUrl: `data:${mimeType};base64,${base64}`, mimeType, name };
}

export async function pickAttachment(): Promise<AttachmentPayload | null> {
  const result = await DocumentPicker.getDocumentAsync({ type: ["image/*", "video/*", "audio/*", "text/*", "application/pdf", "application/*"], copyToCacheDirectory: true, multiple: false });
  if (result.canceled || !result.assets[0]) return null;
  const asset = result.assets[0];
  return fileToPayload(asset.uri, asset.mimeType || "application/octet-stream", asset.name || "arzu-dosya");
}

export async function pickPhotoOrVideo(): Promise<AttachmentPayload | null> {
  const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.All, quality: 0.65, base64: false, allowsEditing: false });
  if (result.canceled || !result.assets[0]) return null;
  const asset = result.assets[0];
  const mimeType = asset.mimeType || (asset.type === "video" ? "video/mp4" : "image/jpeg");
  return fileToPayload(asset.uri, mimeType, asset.fileName || `arzu-${Date.now()}.${asset.type === "video" ? "mp4" : "jpg"}`);
}

export async function readAndroidSharedContent(): Promise<{ text?: string; attachment?: AttachmentPayload } | null> {
  const content = await nativeBridge()?.getSharedContent();
  if (!content || (!content.text && !content.uri)) return null;
  const attachment = content.uri ? await fileToPayload(content.uri, content.mimeType || "application/octet-stream", content.name || `arzu-paylasim-${Date.now()}`) : undefined;
  return { text: content.text, attachment };
}
