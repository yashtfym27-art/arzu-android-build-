import { Platform } from "react-native";
import * as Notifications from "expo-notifications";

import { arzuProactiveSpeech, type ArzuProactiveEvent } from "@/lib/arzu-events";

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldPlaySound: false,
    shouldSetBadge: false,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

export async function prepareArzuNotifications(): Promise<boolean> {
  if (Platform.OS === "web") return false;

  if (Platform.OS === "android") {
    await Notifications.setNotificationChannelAsync("arzu-important", {
      name: "Arzu — önemli sonuçlar",
      importance: Notifications.AndroidImportance.DEFAULT,
      vibrationPattern: [0, 150],
      lightColor: "#7C6CF2",
    });
  }

  const existing = await Notifications.getPermissionsAsync();
  if (existing.status === "granted") return true;
  const requested = await Notifications.requestPermissionsAsync();
  return requested.status === "granted";
}

export async function notifyImportantResult(title: string, body: string, event?: ArzuProactiveEvent): Promise<void> {
  if (event) {
    arzuProactiveSpeech.enqueue(event);
    if (event.priority !== "critical" && event.priority !== "important") return;
  }
  const granted = await prepareArzuNotifications();
  if (!granted) return;

  await Notifications.scheduleNotificationAsync({
    content: {
      title,
      body,
      data: { url: "/(tabs)/research" },
    },
    trigger: Platform.OS === "android" ? { channelId: "arzu-important" } : null,
  });
}
