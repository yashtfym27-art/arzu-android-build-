export function resolveArzuAudioUrl(baseUrl: string, audioUrl: string): string {
  if (/^https?:\/\//i.test(audioUrl)) {
    // Android varsayılan olarak http (şifresiz) bağlantıyı engeller; yerel ağ dışındaki adresleri https'e çevir.
    const isLocal = /^http:\/\/(localhost|127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|169\.254\.|[^./:]+\.local)/i.test(audioUrl);
    return !isLocal && /^http:\/\//i.test(audioUrl) ? audioUrl.replace(/^http:/i, "https:") : audioUrl;
  }
  const cleanBase = baseUrl.replace(/\/$/, "");
  const cleanPath = audioUrl.replace(/^\//, "");
  return `${cleanBase}/${cleanPath}`;
}
