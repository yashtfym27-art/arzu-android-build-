import { createTRPCReact } from "@trpc/react-query";
import { httpBatchLink } from "@trpc/client";
import superjson from "superjson";
import type { AppRouter } from "@/server/routers";
import { getApiBaseUrl } from "@/constants/oauth";
import * as Auth from "@/lib/_core/auth";
import { ensureWifiBinding, recoverConnection } from "@/lib/arzu-connectivity";

/**
 * tRPC React client for type-safe API calls.
 *
 * IMPORTANT (tRPC v11): The `transformer` must be inside `httpBatchLink`,
 * NOT at the root createClient level. This ensures client and server
 * use the same serialization format (superjson).
 */
export const trpc = createTRPCReact<AppRouter>();

/**
 * Creates the tRPC client with proper configuration.
 * Call this once in your app's root layout.
 */
export function createTRPCClient() {
  return trpc.createClient({
    links: [
      httpBatchLink({
        url: `${getApiBaseUrl()}/api/trpc`,
        // tRPC v11: transformer MUST be inside httpBatchLink, not at root
        transformer: superjson,
        async headers() {
          const token = await Auth.getSessionToken();
          return token ? { Authorization: `Bearer ${token}` } : {};
        },
        // Custom fetch to include credentials for cookie-based auth
        async fetch(url, options) {
          // Adres çalışma anında okunur: Profil'den veya otomatik taramayla sunucu adresi değişirse yeniden başlatmaya gerek kalmaz.
          const buildTarget = () => {
            const base = getApiBaseUrl();
            const raw = String(url);
            return base
              ? (/^https?:\/\//i.test(raw) ? raw.replace(/^https?:\/\/[^/]+/i, () => base) : `${base}${raw.startsWith("/") ? "" : "/"}${raw}`)
              : raw;
          };
          // Uzun işler (video üretimi) ve büyük yüklemeler için daha uzun zaman aşımı.
          const body = typeof options?.body === "string" ? options.body : "";
          const heavy = /mediaCreate|mediaRender|animationCreate/.test(String(url));
          const timeoutMs = heavy ? 600_000 : body.length > 1_000_000 ? 300_000 : 180_000;
          const attempt = async () => {
            const controller = new AbortController();
            const timer = setTimeout(() => controller.abort(), timeoutMs);
            const outer = options?.signal;
            if (outer) { if (outer.aborted) controller.abort(); else outer.addEventListener("abort", () => controller.abort()); }
            try {
              return await fetch(buildTarget(), { ...options, signal: controller.signal, credentials: "include" });
            } finally { clearTimeout(timer); }
          };
          await ensureWifiBinding();
          try {
            return await attempt();
          } catch (error) {
            const aborted = options?.signal?.aborted;
            if (!aborted && error instanceof TypeError) {
              // Bağlantı koptu (Wi‑Fi değişti, sunucu başka porta/adrese geçti): bir kez kurtarmayı dene.
              if (await recoverConnection()) return attempt();
              throw new Error("Arzu sunucusuna ulaşılamadı. Bilgisayardaki sunucunun açık ve aynı Wi‑Fi'de olduğunu kontrol et.");
            }
            if (!aborted && error instanceof Error && error.name === "AbortError") throw new Error("Sunucu zamanında yanıt vermedi.");
            throw error;
          }
        },
      }),
    ],
  });
}
