export type ArzuEventPriority = "critical" | "important" | "normal" | "trivial";
export type ArzuEventKind = "task_complete" | "error" | "warning" | "system" | "wake_word";

export type ArzuProactiveEvent = {
  id: string;
  kind: ArzuEventKind;
  priority: ArzuEventPriority;
  title: string;
  speech: string;
  createdAt: number;
  expiresAt?: number;
  requiresSpeech?: boolean;
};

export const eventPriorityRank: Record<ArzuEventPriority, number> = { critical: 4, important: 3, normal: 2, trivial: 1 };

export function createArzuEvent(input: Omit<ArzuProactiveEvent, "id" | "createdAt">): ArzuProactiveEvent {
  return { ...input, id: `arzu-event-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, createdAt: Date.now() };
}

export function classifyResearchResult(summary: string): ArzuProactiveEvent {
  const important = /kritik|önemli|risk|uyarı|hata|fırsat|acil/i.test(summary);
  return createArzuEvent({
    kind: "task_complete",
    priority: important ? "important" : "normal",
    speech: important
      ? "Kaptanım, araştırmayı tamamladım. Önemli bir sonuç buldum. İstersen anlatayım."
      : "Kaptanım, araştırma tamamlandı. Sonuçları hazır olduğunda gösterebilirim.",
    title: "Araştırma tamamlandı",
    expiresAt: Date.now() + 24 * 60 * 60 * 1000,
  });
}

export function classifySystemError(message: string): ArzuProactiveEvent {
  return createArzuEvent({
    kind: "error",
    priority: "critical",
    title: "Arzu kritik hata",
    speech: `Kaptanım, önemli bir hata oluştu: ${message}. İncelemene bıraktım.`,
    expiresAt: Date.now() + 60 * 60 * 1000,
  });
}
