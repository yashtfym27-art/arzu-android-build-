import { Platform } from "react-native";
import { requireNativeModule } from "expo-modules-core";

const OWN_PACKAGE = "com.app.arzuassistant";

type AccessibilityBridge = {
  isAccessibilityEnabled: () => Promise<boolean>;
  openAccessibilitySettings: () => Promise<boolean>;
  readScreen: () => Promise<string>;
  foregroundPackage: () => Promise<string>;
  clickText: (target: string) => Promise<boolean>;
  longClickText?: (target: string) => Promise<boolean>;
  canDrawOverlays?: () => Promise<boolean>;
  openOverlaySettings?: () => Promise<boolean>;
  typeText: (text: string, target: string) => Promise<boolean>;
  scrollScreen: (forward: boolean) => Promise<boolean>;
  globalAction: (name: string) => Promise<boolean>;
  launchApp: (packageName: string) => Promise<boolean>;
};

function bridge(): AccessibilityBridge | null {
  if (Platform.OS !== "android") return null;
  try { return requireNativeModule<AccessibilityBridge>("ArzuNative"); } catch { return null; }
}

export async function isAccessibilityEnabled(): Promise<boolean> {
  try { return (await bridge()?.isAccessibilityEnabled()) ?? false; } catch { return false; }
}

export async function openAccessibilitySettings(): Promise<boolean> {
  try { return (await bridge()?.openAccessibilitySettings()) ?? false; } catch { return false; }
}

export async function bringArzuToFront(): Promise<void> {
  try { await bridge()?.launchApp(OWN_PACKAGE); } catch { /* sessizce geç */ }
}

/** Arka plandan Arzu'yu öne getirmek için "Diğer uygulamaların üzerinde göster" izni gerekir. */
export async function canDrawOverlays(): Promise<boolean> {
  try { return (await bridge()?.canDrawOverlays?.()) ?? false; } catch { return false; }
}

export async function openOverlaySettings(): Promise<boolean> {
  try { return (await bridge()?.openOverlaySettings?.()) ?? false; } catch { return false; }
}

export const ARZU_PACKAGE = OWN_PACKAGE;

export type AgentDecision = { action: string; target: string; text: string; say: string };
export type AgentResult = { finished: boolean; summary: string; needsConfirmation?: boolean };

const sleep = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));

/**
 * Ekranı okuyup sunucudan tek adım ister, adımı uygular ve hedef bitene kadar tekrarlar.
 * Hassas işlemler (ödeme, silme, şifre) sunucu tarafında "ask" ile durdurulur.
 */
export async function runScreenAgent(options: {
  goal: string;
  appLabel: string;
  requestStep: (input: { goal: string; appLabel: string; screen: string; history: string[] }) => Promise<AgentDecision>;
  onStatus?: (text: string) => void;
  shouldStop?: () => boolean;
  maxSteps?: number;
  /** Hedef uygulamanın paket adı. Arzu'nun kendi paketi verilirse Arzu kendi ekranını yönetir. */
  packageName?: string;
}): Promise<AgentResult> {
  const native = bridge();
  if (!native) return { finished: false, summary: "Bu özellik yalnızca Android APK'sında çalışır." };
  const history: string[] = [];
  const maxSteps = options.maxSteps ?? 16;
  const controllingSelf = options.packageName === OWN_PACKAGE;
  let waitingForApp = 0;
  let sameScreenCount = 0;
  let lastScreen = "";

  for (let step = 0; step < maxSteps; step += 1) {
    if (options.shouldStop?.()) return { finished: false, summary: "İşlemi durdurdum." };
    await sleep(step === 0 ? 1800 : 1000);
    const screen = await native.readScreen();
    if (!screen) return { finished: false, summary: "Ekranı okuyamadım. Erişilebilirlik izni kapanmış olabilir." };
    const foreground = await native.foregroundPackage();
    // Başka bir uygulama yönetilirken Arzu hâlâ öndeyse hedef uygulamanın açılmasını bekle.
    if (!controllingSelf && foreground === OWN_PACKAGE && waitingForApp < 3) { waitingForApp += 1; step -= 1; continue; }

    // Ekran hiç değişmiyorsa aynı adımı sonsuza dek tekrarlama.
    sameScreenCount = screen === lastScreen ? sameScreenCount + 1 : 0;
    lastScreen = screen;
    if (sameScreenCount >= 4) return { finished: false, summary: "Ekran değişmiyor, takıldım. Ne yapmamı istediğini biraz daha açık söyler misin?" };

    options.onStatus?.(`${options.appLabel}: adım ${step + 1}…`);
    const header = `[ön plandaki paket: ${foreground || "bilinmiyor"}${options.packageName && foreground && foreground !== options.packageName ? ` — hedef uygulama ${options.packageName}; farklıysa geri veya ana ekran ile dön` : ""}]\n`;
    // Sunucu en fazla 24 geçmiş kaydı kabul eder; en yeni kayıtlar gönderilir.
    const decision = await options.requestStep({ goal: options.goal, appLabel: options.appLabel, screen: (header + screen).slice(0, 13900), history: history.slice(-20) });
    history.push(`${decision.action}${decision.target ? ` "${decision.target}"` : ""}${decision.text ? ` → ${decision.text.slice(0, 60)}` : ""}`);

    if (decision.action === "done") return { finished: true, summary: decision.say || "Tamamladım." };
    if (decision.action === "ask") return { finished: false, needsConfirmation: true, summary: decision.say || "Devam etmeden önce onayına ihtiyacım var." };

    let ok = true;
    if (decision.action === "click") ok = await native.clickText(decision.target);
    else if (decision.action === "type") ok = await native.typeText(decision.text, decision.target);
    else if (decision.action === "scroll_down") ok = await native.scrollScreen(true);
    else if (decision.action === "scroll_up") ok = await native.scrollScreen(false);
    else if (decision.action === "long_click") ok = native.longClickText ? await native.longClickText(decision.target) : await native.clickText(decision.target);
    else if (decision.action === "open_notifications") ok = await native.globalAction("notifications");
    else if (decision.action === "wait") { await sleep(1500); ok = true; }
    else if (decision.action === "back") ok = await native.globalAction("back");
    else if (decision.action === "home") ok = await native.globalAction("home");
    if (!ok) history.push("(bu adım uygulanamadı)");
  }
  return { finished: false, summary: "Adım sınırına ulaştım; işlem tamamlanmamış olabilir. Ekrana bakıp devam etmemi söyleyebilirsin." };
}
