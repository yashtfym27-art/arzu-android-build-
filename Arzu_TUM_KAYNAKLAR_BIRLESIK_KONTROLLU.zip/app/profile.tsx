import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { router } from "expo-router";
import { useEffect, useState } from "react";
import { Alert, AppState, FlatList, Platform, Pressable, StyleSheet, Switch, Text, TextInput, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { setBackgroundResearch } from "@/lib/arzu-background";
import { arzuStorage } from "@/lib/arzu-storage";
import { DEFAULT_SETTINGS, type ArzuSettings, type MemoryItem } from "@/lib/arzu-types";
import { arzuWakeWord } from "@/lib/arzu-events";
import { getAllowedPackages, launchAllowedApp, listInstalledApps, setAllowedPackages, type InstalledApp } from "@/lib/arzu-app-access";
import { canDrawOverlays, isAccessibilityEnabled, openAccessibilitySettings, openOverlaySettings } from "@/lib/arzu-accessibility";
import { discoverLocalArzuServer, testServerUrl } from "@/lib/arzu-connectivity";
import { getApiBaseUrl, loadRuntimeApiBaseUrl, saveRuntimeApiBaseUrl } from "@/constants/oauth";

function uid() { return `memory-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`; }

const MEMORY_HINTS = ["Çalışma hedefim…", "Tercih ettiğim yanıt biçimi…", "Devam eden projem…"];

export default function ProfileScreen() {
  const [settings, setSettings] = useState<ArzuSettings>(DEFAULT_SETTINGS);
  const [memories, setMemories] = useState<MemoryItem[]>([]);
  const [draft, setDraft] = useState("");
  const [loaded, setLoaded] = useState(false);
  const [installedApps, setInstalledApps] = useState<InstalledApp[]>([]);
  const [allowedPackages, setAllowedPackagesState] = useState<string[]>([]);
  const [accessOn, setAccessOn] = useState(false);
  const [overlayOn, setOverlayOn] = useState(true);
  const [finding, setFinding] = useState(false);
  const [serverInput, setServerInput] = useState("");
  const [serverMsg, setServerMsg] = useState("");

  useEffect(() => {
    void loadRuntimeApiBaseUrl().then(() => setServerInput(getApiBaseUrl()));
    const refresh = () => { void isAccessibilityEnabled().then(setAccessOn); void canDrawOverlays().then(setOverlayOn); };
    refresh();
    // Kullanıcı Ayarlar'dan izin verip geri dönünce durum kendiliğinden yenilenir.
    const sub = AppState.addEventListener("change", (state) => { if (state === "active") refresh(); });
    return () => sub.remove();
  }, []);

  const testServer = async () => { setServerMsg("Deneniyor…"); const result = await testServerUrl(serverInput); setServerMsg(result.message); };
  const findServer = async () => {
    setFinding(true); setServerMsg("Aynı Wi‑Fi ağında Arzu sunucusu aranıyor… (birkaç saniye sürebilir)");
    try {
      const found = await discoverLocalArzuServer(true);
      if (found) { setServerInput(found); setServerMsg(`Bulundu ve kaydedildi: ${found}`); }
      else setServerMsg("Sunucu bulunamadı. Bilgisayarda sunucunun çalıştığından, aynı Wi‑Fi'de olduğunuzdan ve güvenlik duvarının 3000 portuna izin verdiğinden emin ol.");
    } finally { setFinding(false); }
  };
  const saveServer = async () => {
    await saveRuntimeApiBaseUrl(serverInput);
    setServerMsg(serverInput.trim() ? "Kaydedildi. Ana ekrana dönünce bağlantı yenilenir." : "Varsayılan adrese dönüldü.");
  };

  useEffect(() => { void Promise.all([arzuStorage.getSettings(), arzuStorage.getMemories(), getAllowedPackages(), listInstalledApps()]).then(([storedSettings, storedMemories, allowed, apps]) => { setSettings(storedSettings); setMemories(storedMemories); setAllowedPackagesState(allowed); setInstalledApps(apps); setLoaded(true); }); }, []);

  const updateSettings = async (patch: Partial<ArzuSettings>) => {
    const next = { ...settings, ...patch };
    setSettings(next);
    await arzuStorage.saveSettings(next);
    if (patch.backgroundResearch !== undefined) {
      try { await setBackgroundResearch(patch.backgroundResearch); } catch { Alert.alert("Arka plan görevi", "Bu özellik web önizlemesinde değil, Android uygulama derlemesinde etkinleşir."); }
    }
    if (patch.wakeWord !== undefined) {
      try {
        if (patch.wakeWord) await arzuWakeWord.start(() => undefined);
        else await arzuWakeWord.stop();
      } catch { Alert.alert("Wake word servisi", "Wake-word yalnızca Android native derlemesinde ve mikrofon izniyle çalışır."); }
    }
  };

  const addMemory = () => {
    const text = draft.trim();
    if (!text) return;
    const now = new Date().toISOString();
    const next = [{ id: uid(), text, category: "other" as const, createdAt: now, updatedAt: now, pinned: false }, ...memories];
    setMemories(next); setDraft(""); void arzuStorage.saveMemories(next);
  };

  const removeMemory = (id: string) => { const next = memories.filter((memory) => memory.id !== id); setMemories(next); void arzuStorage.saveMemories(next); };

  const toggleAppAccess = (packageName: string) => {
    const next = allowedPackages.includes(packageName) ? allowedPackages.filter((item) => item !== packageName) : [...allowedPackages, packageName];
    setAllowedPackagesState(next);
    void setAllowedPackages(next);
  };

  const resetData = () => {
    Alert.alert("Cihazdaki verileri sil", "Sohbetler, kalıcı hafızalar, araştırma kayıtları ve laboratuvar raporları bu cihazdan silinecek. Bu işlem geri alınamaz.", [
      { text: "Vazgeç", style: "cancel" },
      { text: "Verileri sil", style: "destructive", onPress: () => { void arzuStorage.resetPrivateData(); setMemories([]); Alert.alert("Silindi", "Arzu'nun cihazdaki yerel geçmişi temizlendi."); } },
    ]);
  };

  const settingRows = [
    { icon: "record-voice-over" as const, title: "“Arzu” ile uyanma", detail: "Sesli kayıt başladığında “Arzu” hitabını ayıkla.", key: "wakeWord" as const },
    { icon: "volume-up" as const, title: "Sesli yanıt", detail: "Arzu, Derya adlı doğal Türkçe kadın sesiyle yanıtlasın.", key: "speechReplies" as const },
    { icon: "lock-outline" as const, title: "Özel mod", detail: "Hafızayı yalnızca bu cihazda sakla.", key: "privateMode" as const },
    { icon: "sync" as const, title: "Arka plan araştırması", detail: "Ertelenebilir görevleri cihaz uygun olduğunda eşitle.", key: "backgroundResearch" as const },
  ];

  return <ScreenContainer edges={["top", "bottom", "left", "right"]}><View style={styles.topbar}><Pressable onPress={() => router.back()} style={({ pressed }) => [styles.back, pressed && styles.pressed]}><MaterialIcons name="arrow-back" size={21} color="#DAD5E8" /></Pressable><View><Text style={styles.eyebrow}>TEK KİŞİLİK ÇALIŞMA ALANI</Text><Text style={styles.title}>Senin Arzu’n</Text></View></View>
    <FlatList data={memories} keyExtractor={(item) => item.id} contentContainerStyle={styles.content} ListHeaderComponent={<>
      <View style={styles.profileCard}><View style={styles.profileMark}><Text style={styles.profileMarkText}>A</Text></View><View style={styles.profileCopy}><Text style={styles.profileTitle}>Kişisel asistanın</Text><Text style={styles.profileText}>Arzu, yalnızca senin bağlamın için tasarlandı. Çok kullanıcılı bir sosyal alan değildir.</Text></View></View>
      <Text style={styles.sectionTitle}>ÇALIŞMA ŞEKLİ</Text>
      <View style={styles.settingsCard}>{settingRows.map((row, index) => <View key={row.key} style={[styles.settingRow, index < settingRows.length - 1 && styles.settingBorder]}><View style={styles.settingIcon}><MaterialIcons name={row.icon} size={20} color="#B7ADFF" /></View><View style={styles.settingCopy}><Text style={styles.settingTitle}>{row.title}</Text><Text style={styles.settingDetail}>{row.detail}</Text></View><Switch value={settings[row.key]} onValueChange={(value) => void updateSettings({ [row.key]: value })} trackColor={{ false: "#4A4558", true: "#7464DE" }} thumbColor="#EEEAFE" /></View>)}</View>
      <View style={styles.androidCard}><MaterialIcons name="android" size={21} color="#7AD7C0" /><View style={styles.androidCopy}><Text style={styles.androidTitle}>Android yetenek katmanı</Text><Text style={styles.androidText}>Mikrofon, kamera, görseller, dosyalar, yerel bildirimler ve sistem izinleri; yalnızca ihtiyaç duyulduğunda istenir.</Text></View></View>
      <Text style={styles.sectionTitle}>UYGULAMA İÇİ İŞLEMLER</Text>
      <View style={px.card}>
        <View style={px.row}>
          <MaterialIcons name={accessOn ? "check-circle" : "accessibility-new"} size={20} color={accessOn ? "#7CDBBE" : "#F3C58C"} />
          <View style={px.copy}>
            <Text style={px.title}>{accessOn ? "Erişilebilirlik izni açık" : "Erişilebilirlik izni kapalı"}</Text>
            <Text style={px.text}>Arzu'nun açtığı uygulamalarda düğmelere basması, yazı yazması ve kaydırması için gerekir. Yalnızca aşağıda izin verdiğin uygulamalarda ve sen bir görev istediğinde çalışır. Şifre alanlarını okumaz; ödeme ve silme gibi adımlarda sana sorar. İstediğin an Android Ayarları'ndan kapatabilirsin.</Text>
          </View>
        </View>
        {!accessOn ? <Pressable onPress={() => void openAccessibilitySettings()} style={px.button}><Text style={px.buttonText}>Erişilebilirlik ayarlarını aç</Text></Pressable> : null}
        {!accessOn ? <Text style={px.hint}>Ayarlarda yüklü veya indirilen uygulamalar altında Arzu'yu bulup aç.</Text> : null}
        {!overlayOn && Platform.OS === "android" ? <Text style={px.hint}>Arzu bir uygulamada iş bitirince arka plandan kendini öne getirebilsin diye “Diğer uygulamaların üzerinde göster” izni gerekir.</Text> : null}
        {!overlayOn && Platform.OS === "android" ? <Pressable onPress={() => void openOverlaySettings()} style={px.button}><Text style={px.buttonText}>Üzerinde göster iznini aç</Text></Pressable> : null}
      </View>
      <Text style={styles.sectionTitle}>SUNUCU ADRESİ</Text>
      <View style={px.card}>
        <Text style={px.text}>Telefon ve sunucu bilgisayarı aynı Wi‑Fi ağında olmalı. Sunucuyu bilgisayarda 0.0.0.0:3000 ile başlatıp bilgisayarın yerel adresini yaz: örneğin http://192.168.1.20:3000</Text>
        <TextInput value={serverInput} onChangeText={setServerInput} autoCapitalize="none" autoCorrect={false} placeholder="http://192.168.1.20:3000" placeholderTextColor="#77718C" style={px.input} />
        <View style={px.buttons}>
          <Pressable onPress={() => void findServer()} disabled={finding} style={[px.button, finding && { opacity: 0.6 }]}><Text style={px.buttonText}>{finding ? "Aranıyor…" : "Otomatik bul"}</Text></Pressable>
          <Pressable onPress={() => void testServer()} style={px.button}><Text style={px.buttonText}>Test et</Text></Pressable>
          <Pressable onPress={() => void saveServer()} style={px.button}><Text style={px.buttonText}>Kaydet</Text></Pressable>
        </View>
        {serverMsg ? <Text style={px.hint}>{serverMsg}</Text> : null}
      </View>
      <Text style={styles.sectionTitle}>UYGULAMA ERİŞİMİ</Text>
      <View style={styles.accessCard}><View style={styles.accessIntro}><MaterialIcons name="apps" size={20} color="#B8ACFF" /><View style={styles.accessCopy}><Text style={styles.accessTitle}>Arzu hangi uygulamaları kullanabilir?</Text><Text style={styles.accessText}>Seçili uygulamayı Arzu şimdi açabilir. Uygulama içindeki düğmelere basma veya mesaj gönderme için Android Erişilebilirlik izni ya da ilgili uygulamanın API’si ayrıca gerekir.</Text></View></View>{installedApps.length ? installedApps.map((app) => <View key={app.packageName} style={styles.appRow}><View style={styles.appMark}><Text style={styles.appMarkText}>{app.label.slice(0, 1).toUpperCase()}</Text></View><View style={styles.appCopy}><Text style={styles.appLabel}>{app.label}</Text><Text style={styles.appPackage}>{app.packageName}</Text></View><Pressable onPress={() => void launchAllowedApp(app.packageName).then((opened) => { if (!opened) Alert.alert("Uygulama açılamadı", "Önce bu uygulamanın yanındaki allowlist anahtarını etkinleştir."); })} style={styles.openApp}><MaterialIcons name="open-in-new" size={14} color="#17131F" /></Pressable><Switch value={allowedPackages.includes(app.packageName)} onValueChange={() => toggleAppAccess(app.packageName)} trackColor={{ false: "#4A4558", true: "#7464DE" }} thumbColor="#EEEAFE" /></View>) : <Text style={styles.noApps}>{Platform.OS === "android" ? "Kurulu uygulamalar okunamadı; Android paket görünürlüğünü kontrol edin." : "Bu liste yalnızca gerçek Android APK’sında doldurulur."}</Text>}<Text style={styles.accessFoot}>Seçili uygulama sayısı: {allowedPackages.length}. Arzu uygulamayı açabilir; uygulama içi otomasyon için ayrıca erişilebilirlik izni ve kullanıcı onayı gerekir.</Text></View>
      <Text style={styles.sectionTitle}>KALICI HAFIZA</Text>
      <Text style={styles.memoryIntro}>Buraya yalnızca uzun süre yararlı olacak bilgileri ekle. Geçici araştırma sonuçları otomatik olarak kalıcı hafızaya yazılmaz.</Text>
      <View style={styles.memoryComposer}><TextInput value={draft} onChangeText={setDraft} placeholder={MEMORY_HINTS[0]} placeholderTextColor="#77718C" style={styles.memoryInput} maxLength={500} /><Pressable onPress={addMemory} disabled={!draft.trim()} style={({ pressed }) => [styles.addButton, !draft.trim() && styles.addDisabled, pressed && styles.pressed]}><MaterialIcons name="add" size={20} color="#17131E" /></Pressable></View>
    </>} renderItem={({ item }) => <View style={styles.memoryCard}><View style={styles.memoryDot} /><Text style={styles.memoryText}>{item.text}</Text><Pressable onPress={() => removeMemory(item.id)} style={({ pressed }) => [styles.deleteButton, pressed && styles.pressed]} accessibilityLabel="Hafızadan kaldır"><MaterialIcons name="close" size={17} color="#A49CAF" /></Pressable></View>} ListEmptyComponent={loaded ? <View style={styles.emptyMemory}><MaterialIcons name="psychology-alt" size={24} color="#776F8A" /><Text style={styles.emptyMemoryText}>Arzu henüz kalıcı bir bilgi tutmuyor.</Text></View> : null} ListFooterComponent={<><Text style={styles.sectionTitle}>VERİ KONTROLÜ</Text><Pressable onPress={resetData} style={({ pressed }) => [styles.reset, pressed && styles.pressed]}><MaterialIcons name="delete-outline" size={19} color="#F3A6B7" /><View><Text style={styles.resetTitle}>Cihazdaki özel verileri sil</Text><Text style={styles.resetText}>Sohbet, hafıza, araştırma ve laboratuvar kayıtlarını temizle.</Text></View></Pressable><Text style={styles.footnote}>{Platform.OS === "web" ? "Web önizlemesinde cihaz güvenliği taklit edilir; Android derlemesi gerçek izin ve depolama katmanını kullanır." : "Hassas verileri paylaşmadan önce cihaz kilidinin etkin olduğundan emin ol."}</Text></>} />
  </ScreenContainer>;
}

const styles = StyleSheet.create({
  topbar: { flexDirection: "row", alignItems: "center", gap: 11, padding: 16, paddingTop: 10 }, back: { width: 39, height: 39, alignItems: "center", justifyContent: "center", borderRadius: 13, backgroundColor: "#211D2E", borderWidth: 1, borderColor: "#373048" }, eyebrow: { color: "#A99BFD", fontSize: 9, fontWeight: "800", letterSpacing: 1.1 }, title: { color: "#F5F3FE", fontSize: 23, lineHeight: 28, fontWeight: "700" }, content: { padding: 16, paddingTop: 0, paddingBottom: 24, gap: 9 }, profileCard: { borderRadius: 20, padding: 15, backgroundColor: "#201C2E", borderWidth: 1, borderColor: "#373048", flexDirection: "row", gap: 12, alignItems: "center" }, profileMark: { width: 48, height: 48, borderRadius: 18, backgroundColor: "#7665E5", justifyContent: "center", alignItems: "center" }, profileMarkText: { color: "#FFF", fontSize: 22, fontWeight: "800" }, profileCopy: { flex: 1 }, profileTitle: { color: "#F3F0FB", fontSize: 15, fontWeight: "700" }, profileText: { color: "#A49EB2", fontSize: 12, lineHeight: 17, marginTop: 3 }, sectionTitle: { color: "#90889D", fontSize: 10, fontWeight: "800", letterSpacing: 1.1, marginTop: 11, marginBottom: 1 }, settingsCard: { borderRadius: 18, backgroundColor: "#1C1928", borderWidth: 1, borderColor: "#322C42", paddingHorizontal: 12 }, settingRow: { minHeight: 67, flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 9 }, settingBorder: { borderBottomWidth: 1, borderBottomColor: "#302A40" }, settingIcon: { width: 34, height: 34, borderRadius: 12, backgroundColor: "#292440", alignItems: "center", justifyContent: "center" }, settingCopy: { flex: 1 }, settingTitle: { color: "#E6E1F0", fontSize: 13, fontWeight: "700" }, settingDetail: { color: "#918A9E", fontSize: 10, lineHeight: 14, marginTop: 2 }, androidCard: { borderRadius: 16, padding: 12, flexDirection: "row", gap: 10, backgroundColor: "#17251F", borderWidth: 1, borderColor: "#2E5043", alignItems: "flex-start" }, androidCopy: { flex: 1 }, androidTitle: { color: "#C0E4D9", fontSize: 12, fontWeight: "700" }, androidText: { color: "#A5C7BC", fontSize: 11, lineHeight: 16, marginTop: 2 }, accessCard: { borderRadius: 18, backgroundColor: "#1C1928", borderWidth: 1, borderColor: "#39324E", padding: 12, gap: 9 }, accessIntro: { flexDirection: "row", gap: 9, alignItems: "flex-start" }, accessCopy: { flex: 1 }, accessTitle: { color: "#E9E4F5", fontSize: 13, fontWeight: "700" }, accessText: { color: "#918A9E", fontSize: 10, lineHeight: 15, marginTop: 3 }, appRow: { minHeight: 50, borderTopWidth: 1, borderTopColor: "#302A40", flexDirection: "row", alignItems: "center", gap: 8 }, appMark: { width: 30, height: 30, borderRadius: 10, backgroundColor: "#7564E5", alignItems: "center", justifyContent: "center" }, appMarkText: { color: "#FFF", fontWeight: "800", fontSize: 12 }, appCopy: { flex: 1 }, appLabel: { color: "#DED8EB", fontSize: 12, fontWeight: "700" }, appPackage: { color: "#79728B", fontSize: 9, marginTop: 2 }, openApp: { width: 27, height: 27, borderRadius: 9, backgroundColor: "#B8ACFF", alignItems: "center", justifyContent: "center" }, noApps: { color: "#918A9E", fontSize: 11, lineHeight: 16 }, accessFoot: { color: "#7E778D", fontSize: 10, lineHeight: 15 }, memoryIntro: { color: "#A19AAF", fontSize: 12, lineHeight: 17, marginBottom: 7 }, memoryComposer: { height: 48, borderRadius: 15, backgroundColor: "#201C2E", borderWidth: 1, borderColor: "#39324E", flexDirection: "row", alignItems: "center", paddingLeft: 11 }, memoryInput: { flex: 1, color: "#EDE8F7", fontSize: 13, paddingVertical: 8 }, addButton: { width: 37, height: 37, backgroundColor: "#C8BEFF", borderRadius: 12, alignItems: "center", justifyContent: "center", marginRight: 5 }, addDisabled: { backgroundColor: "#4B465B" }, memoryCard: { borderRadius: 14, backgroundColor: "#1C1928", borderWidth: 1, borderColor: "#302A40", paddingLeft: 12, paddingRight: 7, paddingVertical: 11, flexDirection: "row", alignItems: "center", gap: 8 }, memoryDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: "#8F7FF0" }, memoryText: { color: "#D5D0E1", fontSize: 12, lineHeight: 17, flex: 1 }, deleteButton: { width: 27, height: 27, alignItems: "center", justifyContent: "center" }, emptyMemory: { alignItems: "center", paddingVertical: 20, gap: 5 }, emptyMemoryText: { color: "#827B90", fontSize: 12 }, reset: { borderWidth: 1, borderColor: "#553441", backgroundColor: "#2A1D27", padding: 12, borderRadius: 16, flexDirection: "row", gap: 9, alignItems: "center" }, resetTitle: { color: "#F0B0BF", fontSize: 12, fontWeight: "700" }, resetText: { color: "#C894A0", fontSize: 10, lineHeight: 14, marginTop: 2 }, footnote: { color: "#716B7F", fontSize: 10, lineHeight: 15, marginTop: 6 }, pressed: { opacity: 0.75, transform: [{ scale: 0.98 }] },
});

const px = StyleSheet.create({
  card: { borderRadius: 18, backgroundColor: "#1C1928", borderWidth: 1, borderColor: "#39324E", padding: 12, gap: 10 },
  row: { flexDirection: "row", gap: 10, alignItems: "flex-start" },
  copy: { flex: 1 },
  title: { color: "#E9E4F5", fontSize: 13, fontWeight: "700" },
  text: { color: "#918A9E", fontSize: 11, lineHeight: 16, marginTop: 2 },
  hint: { color: "#B8ACFF", fontSize: 11, lineHeight: 15 },
  input: { height: 44, borderRadius: 12, backgroundColor: "#201C2E", borderWidth: 1, borderColor: "#39324E", paddingHorizontal: 12, color: "#EDE8F7", fontSize: 12 },
  buttons: { flexDirection: "row", gap: 8 },
  button: { flex: 1, minHeight: 40, borderRadius: 12, backgroundColor: "#6E5CE6", alignItems: "center", justifyContent: "center", paddingHorizontal: 12 },
  buttonText: { color: "#FFFFFF", fontSize: 12, fontWeight: "700" },
});
