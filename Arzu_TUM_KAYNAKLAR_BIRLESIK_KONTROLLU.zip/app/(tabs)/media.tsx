import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ActivityIndicator, Alert, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import type { MediaPlan, MediaPlatform } from "@/server/media-engine";
import type { AnimationPlan } from "@/server/animation-engine";
import { RenderProgress } from "@/components/render-progress";
import { trpc } from "@/lib/trpc";
import { saveMediaToGallery } from "@/lib/arzu-gallery";

const platforms: { key: MediaPlatform; label: string; icon: keyof typeof MaterialIcons.glyphMap }[] = [
  { key: "reels", label: "Reels", icon: "camera-roll" },
  { key: "tiktok", label: "TikTok", icon: "music-video" },
  { key: "shorts", label: "Shorts", icon: "smart-display" },
  { key: "youtube", label: "YouTube", icon: "smart-toy" },
];

const steps = ["Senaryo", "Görseller", "Seslendirme", "Altyazı", "Montaj"];

export default function MediaScreen() {
  const [prompt, setPrompt] = useState("30 saniyelik reklam videosu hazırla: Arzu kişisel AI asistanını samimi ve modern bir dille tanıt.");
  const [platform, setPlatform] = useState<MediaPlatform>("reels");
  const [mode, setMode] = useState<"video" | "animation">("video");
  const [plan, setPlan] = useState<MediaPlan | null>(null);
  const [animationPlan, setAnimationPlan] = useState<AnimationPlan | null>(null);
  const [animationSource, setAnimationSource] = useState("");
  const [resultMessage, setResultMessage] = useState("");
  const [renderJobId, setRenderJobId] = useState("");
  const capabilities = trpc.arzu.mediaCapabilities.useQuery();
  const planMutation = trpc.arzu.mediaPlan.useMutation({
    onSuccess: (data) => { setPlan(data.plan); setResultMessage("Senaryo ve sahne planı hazır. Üretim düğmesi gerçek servisleri çalıştırır; eksik servis varsa Arzu bunu açıkça bildirir."); },
    onError: (error) => setResultMessage(`Plan oluşturulamadı: ${error.message}`),
  });
  const createMutation = trpc.arzu.mediaCreate.useMutation({
    onSuccess: async (data) => {
      setPlan(data.plan);
      setRenderJobId(data.renderJobId ?? "");
      setResultMessage(data.message);
      const images = (data.assets ?? []).filter((asset) => asset.type === "image");
      if (images.length) {
        const saved = await Promise.allSettled(images.map((asset) => saveMediaToGallery(asset.url, "photo")));
        const failed = saved.filter((item) => item.status === "rejected").length;
        const succeeded = saved.length - failed;
        if (failed === 0) {
          setResultMessage(`${data.message} Üretilen ${succeeded} görsel galeriye kaydedildi.`);
        } else {
          const detail = saved.find((item) => item.status === "rejected");
          const reason = detail?.status === "rejected" && detail.reason instanceof Error ? detail.reason.message : "Galeri iznini ve sunucu adresini kontrol et.";
          setResultMessage(`${data.message} ${succeeded}/${saved.length} görsel galeriye kaydedildi; ${failed} görsel kaydedilemedi: ${reason}`);
          Alert.alert("Görsellerin bir kısmı kaydedilemedi", `${succeeded}/${saved.length} görsel kaydedildi. ${reason}`);
        }
      }
    },
    onError: (error) => setResultMessage(`Medya üretimi başlatılamadı: ${error.message}`),
  });
  const renderStatus = trpc.arzu.mediaRenderStatus.useQuery({ renderJobId: renderJobId || "pending" }, { enabled: Boolean(renderJobId), refetchInterval: (query) => { const state = query.state.data?.status; return state === "completed" || state === "failed" ? false : 2500; } });
  const savedRenderRef = useRef("");
  const animationPlanMutation = trpc.arzu.animationPlan.useMutation({ onSuccess: (data) => { setAnimationPlan(data.plan); setAnimationSource(data.source); setResultMessage("Animasyon zaman çizelgesi ve tekrar üretilebilir kaynak kodu hazır."); }, onError: (error) => setResultMessage(`Animasyon planlanamadı: ${error.message}`) });
  const animationCreateMutation = trpc.arzu.animationCreate.useMutation({ onSuccess: (data) => { setAnimationPlan(data.plan); setAnimationSource(data.source); setRenderJobId(data.renderJobId ?? ""); setResultMessage(data.message); }, onError: (error) => setResultMessage(`Animasyon üretimi başlatılamadı: ${error.message}`) });
  const busy = planMutation.isPending || createMutation.isPending || animationPlanMutation.isPending || animationCreateMutation.isPending;
  const selectedPlatform = useMemo(() => platforms.find((item) => item.key === platform), [platform]);
  const saveVideo = useCallback(async (url: string) => {
    try { await saveMediaToGallery(url, "video"); Alert.alert("Galeriye kaydedildi", "MP4 galerine kaydedildi."); }
    catch (error) { Alert.alert("Galeriye kaydedilemedi", error instanceof Error ? error.message : "Galeri iznini kontrol et."); }
  }, []);
  useEffect(() => {
    const url = renderStatus.data?.status === "completed" ? renderStatus.data.url : undefined;
    if (!url || savedRenderRef.current === url) return;
    savedRenderRef.current = url;
    void saveVideo(url);
  }, [renderStatus.data, saveVideo]);

  return (
    <ScreenContainer edges={["top", "left", "right"]} containerClassName="bg-background">
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <View style={styles.header}>
          <View style={styles.eyebrowRow}><MaterialIcons name="auto-awesome" size={15} color="#B8ACFF" /><Text style={styles.eyebrow}>İÇERİK VE MEDYA MOTORU</Text></View>
          <Text style={styles.title}>Bir fikri yayına hazır içeriğe dönüştür.</Text>
          <Text style={styles.subtitle}>Arzu; planlar, üretir ve yalnızca gerçekten hazır olan çıktıları raporlar. Eksik API varsa sahte video göstermez.</Text>
        </View>

        <View style={styles.hero}>
          <View style={styles.heroGlowOne} />
          <View style={styles.heroGlowTwo} />
          <View style={styles.heroCopy}>
            <View style={styles.liveBadge}><View style={styles.liveDot} /><Text style={styles.liveText}>STÜDYO HAZIR</Text></View>
            <Text style={styles.heroTitle}>Fikrini sahneye taşı</Text>
            <Text style={styles.heroSubtitle}>Sen anlat. Arzu senaryoyu, görselleri, sesi ve montajı sıraya koysun.</Text>
            <View style={styles.heroTags}><Text style={styles.heroTag}>✦ Senaryo</Text><Text style={styles.heroTag}>◉ Ses</Text><Text style={styles.heroTag}>▣ MP4</Text></View>
          </View>
          <View style={styles.heroOrb}><MaterialIcons name="movie-filter" size={31} color="#171321" /></View>
        </View>

        <View style={styles.card}>
          <Text style={styles.label}>DOĞAL KOMUT</Text>
          <TextInput value={prompt} onChangeText={setPrompt} multiline maxLength={4000} style={styles.input} placeholder="Örn. 30 saniyelik reklam videosu hazırla" placeholderTextColor="#77718C" />
          <View style={styles.modeRow}><Pressable onPress={() => setMode("video")} style={[styles.mode, mode === "video" && styles.modeActive]}><MaterialIcons name="movie" size={16} color={mode === "video" ? "#16131F" : "#AAA2C2"} /><Text style={[styles.modeText, mode === "video" && styles.modeTextActive]}>Video üret</Text></Pressable><Pressable onPress={() => setMode("animation")} style={[styles.mode, mode === "animation" && styles.modeActive]}><MaterialIcons name="animation" size={16} color={mode === "animation" ? "#16131F" : "#AAA2C2"} /><Text style={[styles.modeText, mode === "animation" && styles.modeTextActive]}>Animasyon yap</Text></Pressable></View>
          <View style={styles.platforms}>
            {platforms.map((item) => <Pressable key={item.key} onPress={() => setPlatform(item.key)} style={[styles.platform, platform === item.key && styles.platformActive]}><MaterialIcons name={item.icon} size={16} color={platform === item.key ? "#16131F" : "#AAA2C2"} /><Text style={[styles.platformText, platform === item.key && styles.platformTextActive]}>{item.label}</Text></Pressable>)}
          </View>
          <Pressable disabled={busy || prompt.trim().length < 5} onPress={() => mode === "animation" ? animationPlanMutation.mutate({ prompt, platform }) : planMutation.mutate({ prompt, platform })} style={({ pressed }) => [styles.primaryButton, (busy || prompt.trim().length < 5) && styles.disabled, pressed && styles.pressed]}>
            {(planMutation.isPending || animationPlanMutation.isPending) ? <ActivityIndicator color="#16131F" /> : <MaterialIcons name={mode === "animation" ? "animation" : "account-tree"} size={19} color="#16131F" />}
            <Text style={styles.primaryText}>{(planMutation.isPending || animationPlanMutation.isPending) ? "Planlanıyor…" : mode === "animation" ? ` ${selectedPlatform?.label} animasyonunu planla` : ` ${selectedPlatform?.label} için planla`}</Text>
          </Pressable>
        </View>

        <View style={styles.pipeline}>{steps.map((step, index) => <View key={step} style={styles.step}><View style={[styles.stepDot, plan && styles.stepDotReady]}><Text style={styles.stepNumber}>{index + 1}</Text></View><Text style={styles.stepText}>{step}</Text>{index < steps.length - 1 && <View style={styles.stepLine} />}</View>)}</View>

        {capabilities.data ? <View style={styles.capCard}><View style={styles.cardTitleRow}><MaterialIcons name="verified" size={18} color="#75D2BC" /><Text style={styles.cardTitle}>Gerçeklik durumu</Text></View><Capability label="Senaryo planlama" available={capabilities.data.planner.available} note={capabilities.data.planner.note} /><Capability label="Görsel üretim" available={capabilities.data.images.available} note={capabilities.data.images.note} /><Capability label="Seslendirme" available={capabilities.data.voiceover.available} note={capabilities.data.voiceover.note} /><Capability label="Video montajı" available={capabilities.data.videoRender.available} note={capabilities.data.videoRender.note} /><Capability label="Altyazı" available={capabilities.data.subtitles.available} note={capabilities.data.subtitles.note} /></View> : null}

        {plan ? <View style={styles.card}><View style={styles.cardTitleRow}><MaterialIcons name="movie-edit" size={19} color="#F3C58C" /><Text style={styles.cardTitle}>{plan.title}</Text></View><Text style={styles.planMeta}>{plan.formatLabel} · {plan.aspectRatio} · {plan.durationSeconds} sn</Text><View style={styles.hook}><Text style={styles.smallLabel}>Kanca</Text><Text style={styles.body}>{plan.hook}</Text></View>{plan.scenes.map((scene) => <View key={scene.index} style={styles.scene}><View style={styles.sceneIndex}><Text style={styles.sceneIndexText}>{scene.index}</Text></View><View style={styles.sceneCopy}><Text style={styles.sceneTime}>{scene.durationSeconds} sn · {scene.onScreenText || "Ekran yazısı yok"}</Text><Text style={styles.body}>{scene.narration}</Text></View></View>)}<Pressable disabled={busy} onPress={() => createMutation.mutate({ prompt, platform })} style={({ pressed }) => [styles.renderButton, busy && styles.disabled, pressed && styles.pressed]}>{createMutation.isPending ? <ActivityIndicator color="#F7D9A5" /> : <MaterialIcons name="play-circle-outline" size={20} color="#F7D9A5" />}<Text style={styles.renderText}>{createMutation.isPending ? "Gerçek üretim çalışıyor…" : "Gerçek üretimi başlat"}</Text></Pressable></View> : null}

        {animationPlan ? <View style={styles.card}><View style={styles.cardTitleRow}><MaterialIcons name="animation" size={19} color="#B8ACFF" /><Text style={styles.cardTitle}>{animationPlan.title}</Text></View><Text style={styles.planMeta}>{animationPlan.formatLabel} · {animationPlan.aspectRatio} · {animationPlan.durationSeconds} sn · {animationPlan.fps} fps</Text>{animationPlan.scenes.map((scene) => <View key={scene.index} style={styles.scene}><View style={[styles.sceneIndex, { backgroundColor: scene.accent }]}><Text style={styles.sceneIndexText}>{scene.index}</Text></View><View style={styles.sceneCopy}><Text style={styles.sceneTime}>{scene.durationSeconds} sn · {scene.effect}</Text><Text style={styles.body}>{scene.text}</Text>{scene.subtext ? <Text style={styles.capNote}>{scene.subtext}</Text> : null}</View></View>)}<Text style={styles.smallLabel}>TEKRAR ÜRETİLEBİLİR KAYNAK</Text><View style={styles.sourceBox}><Text style={styles.sourceText} numberOfLines={8}>{animationSource}</Text></View><Pressable disabled={busy} onPress={() => animationCreateMutation.mutate({ prompt, platform })} style={({ pressed }) => [styles.renderButton, busy && styles.disabled, pressed && styles.pressed]}>{animationCreateMutation.isPending ? <ActivityIndicator color="#F7D9A5" /> : <MaterialIcons name="play-circle-outline" size={20} color="#F7D9A5" />}<Text style={styles.renderText}>{animationCreateMutation.isPending ? "Gerçek animasyon renderı çalışıyor…" : "Gerçek animasyon MP4’ünü başlat"}</Text></Pressable></View> : null}
        {resultMessage ? <View style={styles.message}><MaterialIcons name="info-outline" size={18} color="#B8ACFF" /><Text style={styles.messageText}>{resultMessage}</Text></View> : null}
        {renderStatus.data ? <View style={styles.message}><MaterialIcons name={renderStatus.data.status === "completed" ? "check-circle" : renderStatus.data.status === "failed" ? "error-outline" : "hourglass-top"} size={18} color={renderStatus.data.status === "completed" ? "#75D2BC" : "#F3C58C"} /><View style={styles.messageCopy}><Text style={styles.messageText}>{renderStatus.data.message}{renderStatus.data.status === "completed" && renderStatus.data.url ? ` MP4 hazır.` : ""}</Text>{renderStatus.data.status === "queued" ? <RenderProgress percent={(renderStatus.data as unknown as { progress?: number }).progress} label="Video hazırlanıyor" /> : null}{renderStatus.data.status === "completed" && renderStatus.data.url ? <Pressable onPress={() => void saveVideo(renderStatus.data?.url ?? "")} style={styles.saveButton}><MaterialIcons name="save-alt" size={15} color="#171321" /><Text style={styles.saveButtonText}>Galerime kaydet</Text></Pressable> : null}</View></View> : null}
        <Text style={styles.footer}>Bu ekranda otomatik yayınlama yoktur. YouTube, Instagram ve TikTok hesaplarına yükleme için ayrı OAuth izinleri ve kullanıcı onayı gerekir.</Text>
      </ScrollView>
    </ScreenContainer>
  );
}

function Capability({ label, available, note }: { label: string; available: boolean; note: string }) {
  return <View style={styles.capability}><MaterialIcons name={available ? "check-circle" : "remove-circle-outline"} size={16} color={available ? "#75D2BC" : "#F1B878"} /><View style={styles.capCopy}><Text style={styles.capLabel}>{label} · {available ? "hazır" : "yapılandırma gerekli"}</Text><Text style={styles.capNote}>{note}</Text></View></View>;
}

const styles = StyleSheet.create({ content: { padding: 16, paddingBottom: 34, gap: 14 }, hero: { minHeight: 145, overflow: "hidden", borderRadius: 24, borderWidth: 1, borderColor: "#554B83", backgroundColor: "#282044", padding: 17, position: "relative", justifyContent: "center" }, heroCopy: { width: "72%", gap: 7, zIndex: 2 }, liveBadge: { alignSelf: "flex-start", flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8, backgroundColor: "#3B315E" }, liveDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: "#7CDBBE" }, liveText: { color: "#BFEBDD", fontSize: 9, fontWeight: "800", letterSpacing: 0.8 }, heroTitle: { color: "#F7F3FF", fontSize: 22, lineHeight: 27, fontWeight: "800" }, heroSubtitle: { color: "#C5BDE0", fontSize: 12, lineHeight: 17 }, heroTags: { flexDirection: "row", gap: 6, marginTop: 2 }, heroTag: { color: "#E7DFFF", fontSize: 10, fontWeight: "700", backgroundColor: "#3A3158", paddingHorizontal: 7, paddingVertical: 5, borderRadius: 7 }, heroOrb: { position: "absolute", right: 25, top: 37, width: 62, height: 62, borderRadius: 31, backgroundColor: "#B8ACFF", alignItems: "center", justifyContent: "center", zIndex: 2 }, heroGlowOne: { position: "absolute", width: 150, height: 150, borderRadius: 75, right: -40, top: -34, backgroundColor: "#6A55B4", opacity: 0.35 }, heroGlowTwo: { position: "absolute", width: 110, height: 110, borderRadius: 55, right: 68, bottom: -68, backgroundColor: "#D2669B", opacity: 0.22 }, header: { paddingTop: 8, gap: 7 }, eyebrowRow: { flexDirection: "row", alignItems: "center", gap: 7 }, eyebrow: { color: "#968DB1", fontSize: 10, letterSpacing: 1.2, fontWeight: "800" }, title: { color: "#F4F1FC", fontSize: 27, lineHeight: 33, fontWeight: "800", letterSpacing: -0.5 }, subtitle: { color: "#9F99B5", fontSize: 13, lineHeight: 19 }, card: { borderRadius: 22, padding: 16, backgroundColor: "#1B1828", borderWidth: 1, borderColor: "#312B48", gap: 12 }, label: { color: "#938BAA", fontSize: 10, letterSpacing: 1.3, fontWeight: "800" }, modeRow: { flexDirection: "row", gap: 7 }, mode: { flex: 1, minHeight: 38, borderRadius: 12, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 6, backgroundColor: "#242035", borderWidth: 1, borderColor: "#38314E" }, modeActive: { backgroundColor: "#B8ACFF", borderColor: "#B8ACFF" }, modeText: { color: "#AAA2C2", fontSize: 11, fontWeight: "800" }, modeTextActive: { color: "#16131F" }, input: { minHeight: 92, color: "#F1EEF8", fontSize: 15, lineHeight: 22, padding: 12, borderRadius: 15, backgroundColor: "#242035", borderWidth: 1, borderColor: "#3A3351", textAlignVertical: "top" }, platforms: { flexDirection: "row", gap: 6 }, platform: { flex: 1, minHeight: 38, paddingHorizontal: 7, borderRadius: 12, alignItems: "center", justifyContent: "center", gap: 3, backgroundColor: "#242035", borderWidth: 1, borderColor: "#38314E" }, platformActive: { backgroundColor: "#B8ACFF", borderColor: "#B8ACFF" }, platformText: { color: "#AAA2C2", fontSize: 10, fontWeight: "800" }, platformTextActive: { color: "#16131F" }, primaryButton: { minHeight: 48, borderRadius: 15, backgroundColor: "#B8ACFF", alignItems: "center", justifyContent: "center", flexDirection: "row" }, primaryText: { color: "#16131F", fontWeight: "800", fontSize: 14 }, pipeline: { flexDirection: "row", alignItems: "center", paddingHorizontal: 3, paddingVertical: 3 }, step: { flex: 1, alignItems: "center", gap: 5, position: "relative" }, stepDot: { width: 26, height: 26, borderRadius: 13, alignItems: "center", justifyContent: "center", backgroundColor: "#2A253A", borderWidth: 1, borderColor: "#453B5B" }, stepDotReady: { backgroundColor: "#7564E5", borderColor: "#A99CFF" }, stepNumber: { color: "#E8E2F6", fontSize: 11, fontWeight: "800" }, stepText: { color: "#9088A6", fontSize: 9, fontWeight: "700" }, stepLine: { position: "absolute", height: 1, backgroundColor: "#3D3554", left: "62%", right: "-38%", top: 13, zIndex: -1 }, capCard: { borderRadius: 20, padding: 15, backgroundColor: "#181622", borderWidth: 1, borderColor: "#2D273D", gap: 10 }, cardTitleRow: { flexDirection: "row", alignItems: "center", gap: 8 }, cardTitle: { color: "#F3EFFC", fontSize: 15, fontWeight: "800", flex: 1 }, capability: { flexDirection: "row", gap: 8, alignItems: "flex-start" }, capCopy: { flex: 1, gap: 2 }, capLabel: { color: "#D8D2E8", fontSize: 12, fontWeight: "700" }, capNote: { color: "#858097", fontSize: 11, lineHeight: 16 }, planMeta: { color: "#B8ACFF", fontSize: 12, fontWeight: "700" }, hook: { padding: 11, borderRadius: 13, backgroundColor: "#242035", gap: 4 }, smallLabel: { color: "#988DAE", fontSize: 10, fontWeight: "800" }, body: { color: "#D9D4E7", fontSize: 13, lineHeight: 19 }, scene: { flexDirection: "row", gap: 10, paddingVertical: 9, borderTopWidth: 1, borderTopColor: "#302A42" }, sceneIndex: { width: 25, height: 25, borderRadius: 13, backgroundColor: "#7564E5", alignItems: "center", justifyContent: "center" }, sceneIndexText: { color: "#FFF", fontWeight: "800", fontSize: 11 }, sceneCopy: { flex: 1, gap: 3 }, sceneTime: { color: "#AAA2C2", fontSize: 10, fontWeight: "700" }, renderButton: { minHeight: 47, borderRadius: 15, borderWidth: 1, borderColor: "#775C37", backgroundColor: "#362B1D", flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7 }, renderText: { color: "#F7D9A5", fontSize: 14, fontWeight: "800" }, sourceBox: { maxHeight: 170, borderRadius: 12, backgroundColor: "#14121D", borderWidth: 1, borderColor: "#322C46", padding: 10 }, sourceText: { color: "#AAA2C2", fontSize: 10, lineHeight: 15, fontFamily: "monospace" }, messageCopy: { flex: 1, gap: 7 }, saveButton: { alignSelf: "flex-start", flexDirection: "row", alignItems: "center", gap: 5, minHeight: 34, paddingHorizontal: 10, borderRadius: 10, backgroundColor: "#B8ACFF" }, saveButtonText: { color: "#171321", fontSize: 11, fontWeight: "800" }, message: { flexDirection: "row", gap: 8, padding: 13, borderRadius: 15, backgroundColor: "#211E30", borderWidth: 1, borderColor: "#3B3354" }, messageText: { color: "#C5BEDB", fontSize: 12, lineHeight: 18, flex: 1 }, footer: { color: "#77718C", fontSize: 11, lineHeight: 16, textAlign: "center", paddingHorizontal: 8 }, disabled: { opacity: 0.5 }, pressed: { opacity: 0.78, transform: [{ scale: 0.985 }] } });
