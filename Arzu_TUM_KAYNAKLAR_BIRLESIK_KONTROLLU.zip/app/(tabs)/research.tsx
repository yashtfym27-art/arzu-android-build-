import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useEffect, useState } from "react";
import { ActivityIndicator, FlatList, Pressable, StyleSheet, Text, TextInput, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { arzuStorage } from "@/lib/arzu-storage";
import type { MemoryItem, ResearchTask } from "@/lib/arzu-types";
import { notifyImportantResult } from "@/lib/arzu-notifications";
import { classifyResearchResult } from "@/lib/arzu-events";
import { trpc } from "@/lib/trpc";

function uid() {
  return `research-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}

const EXAMPLES = [
  "Isı pompasında COP'u yükseltmenin etkili yolları neler?",
  "Bir şirketin temel değerlemesini hangi varsayımlar belirler?",
  "Bir RC devresinin şarj eğrisini sezgisel ve matematiksel açıkla.",
];

export default function ResearchScreen() {
  const [question, setQuestion] = useState("");
  const [tasks, setTasks] = useState<ResearchTask[]>([]);
  const [memories, setMemories] = useState<MemoryItem[]>([]);
  const [loaded, setLoaded] = useState(false);
  const research = trpc.arzu.research.useMutation();

  useEffect(() => {
    void Promise.all([arzuStorage.getTasks(), arzuStorage.getMemories()]).then(([storedTasks, storedMemories]) => {
      setTasks(storedTasks);
      setMemories(storedMemories);
      setLoaded(true);
    });
  }, []);

  const persist = (next: ResearchTask[]) => {
    setTasks(next);
    void arzuStorage.saveTasks(next);
  };

  const startResearch = async (override?: string) => {
    const prompt = (override ?? question).trim();
    if (prompt.length < 5 || research.isPending) return;
    const task: ResearchTask = { id: uid(), title: prompt, prompt, status: "running", createdAt: new Date().toISOString() };
    const next = [task, ...tasks];
    persist(next);
    setQuestion("");

    try {
      const result = await research.mutateAsync({
        question: prompt,
        memories: memories.map((item) => ({ text: item.text, category: item.category })),
      });
      const completed = next.map((item) => item.id === task.id ? {
        ...item,
        status: "completed" as const,
        completedAt: new Date().toISOString(),
        summary: result.text,
        sourceNote: "Arzu; kaynakları ve sınırlılıkları yanıt içinde işaretler.",
      } : item);
      persist(completed);
      await notifyImportantResult("Arzu araştırmayı tamamladı", prompt.length > 58 ? `${prompt.slice(0, 58)}…` : prompt, classifyResearchResult(result.text));
    } catch {
      persist(next.map((item) => item.id === task.id ? { ...item, status: "failed" as const, completedAt: new Date().toISOString(), summary: "Araştırma başlatılamadı. İnternet bağlantısını kontrol edip tekrar dene." } : item));
    }
  };

  const renderTask = ({ item }: { item: ResearchTask }) => {
    const color = item.status === "completed" ? "#7BDBB7" : item.status === "failed" ? "#F68AA5" : "#E9C47E";
    return (
      <View style={styles.taskCard}>
        <View style={styles.taskHeader}>
          <View style={[styles.statusDot, { backgroundColor: color }]} />
          <Text style={styles.taskState}>{item.status === "completed" ? "TAMAMLANDI" : item.status === "failed" ? "TEKRAR DENE" : "ARAŞTIRILIYOR"}</Text>
          <Text style={styles.taskTime}>{new Date(item.createdAt).toLocaleDateString("tr-TR", { day: "numeric", month: "short" })}</Text>
        </View>
        <Text style={styles.taskTitle}>{item.title}</Text>
        {item.status === "running" ? <View style={styles.running}><ActivityIndicator size="small" color="#B8ABFF" /><Text style={styles.runningText}>Merak motoru kaynakları, yöntemleri ve sınırlılıkları tarıyor.</Text></View> : null}
        {item.summary ? <Text style={styles.summary} numberOfLines={item.status === "completed" ? undefined : 3}>{item.summary}</Text> : null}
        {item.status === "completed" ? <View style={styles.taskFooter}><MaterialIcons name="auto-awesome" size={14} color="#A99BFD" /><Text style={styles.taskFooterText}>Sonuç; neden, nasıl ve alternatiflerle derlendi.</Text></View> : null}
        {item.status === "failed" ? <Pressable onPress={() => void startResearch(item.prompt)} style={({ pressed }) => [styles.retry, pressed && styles.pressed]}><Text style={styles.retryText}>Araştırmayı tekrar dene</Text></Pressable> : null}
      </View>
    );
  };

  return (
    <ScreenContainer edges={["top", "left", "right"]}>
      <View style={styles.header}>
        <Text style={styles.eyebrow}>MERAK MOTORU</Text>
        <Text style={styles.title}>Araştırma masası</Text>
        <Text style={styles.subtitle}>Arzu yalnızca cevabı değil, nedenini, çalışma biçimini, alternatifleri ve sınırlarını da araştırır.</Text>
      </View>
      <View style={styles.composerCard}>
        <TextInput
          value={question}
          onChangeText={setQuestion}
          placeholder="Araştırmak istediğin konuyu yaz…"
          placeholderTextColor="#77718C"
          style={styles.input}
          multiline
          maxLength={4000}
        />
        <Pressable onPress={() => void startResearch()} disabled={research.isPending || question.trim().length < 5} style={({ pressed }) => [styles.startButton, (research.isPending || question.trim().length < 5) && styles.startDisabled, pressed && styles.pressed]}>
          <MaterialIcons name="travel-explore" size={19} color="#15121F" />
          <Text style={styles.startText}>{research.isPending ? "Araştırılıyor" : "Araştır"}</Text>
        </Pressable>
      </View>
      <View style={styles.examples}><Text style={styles.examplesLabel}>HIZLI BAŞLANGIÇ</Text><View style={styles.exampleRow}>{EXAMPLES.map((example) => <Pressable key={example} onPress={() => setQuestion(example)} style={({ pressed }) => [styles.exampleChip, pressed && styles.pressed]}><Text numberOfLines={1} style={styles.exampleText}>{example}</Text></Pressable>)}</View></View>
      {!loaded ? <ActivityIndicator style={styles.loading} color="#9C8EFA" /> : <FlatList data={tasks} keyExtractor={(item) => item.id} renderItem={renderTask} contentContainerStyle={styles.list} ListEmptyComponent={<View style={styles.empty}><MaterialIcons name="explore" size={28} color="#736D89" /><Text style={styles.emptyTitle}>İlk araştırma görevini başlat</Text><Text style={styles.emptyText}>Uzun süren çalışmalar görev kuyruğunda toplanır; önemli bir sonuç oluştuğunda bildirim verilir.</Text></View>} />}
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: { paddingHorizontal: 20, paddingTop: 10, paddingBottom: 14 },
  eyebrow: { color: "#A79AF4", fontSize: 10, letterSpacing: 1.3, fontWeight: "800" },
  title: { color: "#F5F3FE", fontSize: 27, lineHeight: 34, fontWeight: "700", letterSpacing: -0.6, marginTop: 3 },
  subtitle: { color: "#A19AAF", fontSize: 13, lineHeight: 19, marginTop: 4, maxWidth: 340 },
  composerCard: { marginHorizontal: 16, padding: 12, borderRadius: 20, backgroundColor: "#201C2E", borderWidth: 1, borderColor: "#373048" },
  input: { minHeight: 68, color: "#EEEAF8", fontSize: 15, lineHeight: 22, textAlignVertical: "top" },
  startButton: { height: 42, borderRadius: 13, backgroundColor: "#C9BEFF", alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 7 },
  startDisabled: { backgroundColor: "#514A63" },
  startText: { color: "#15121F", fontSize: 13, fontWeight: "800" },
  examples: { paddingHorizontal: 16, paddingTop: 14, paddingBottom: 8 },
  examplesLabel: { color: "#817A95", fontSize: 10, letterSpacing: 1.2, fontWeight: "800", marginBottom: 7 },
  exampleRow: { gap: 7 },
  exampleChip: { borderWidth: 1, borderColor: "#302A41", backgroundColor: "#191624", paddingHorizontal: 11, height: 31, borderRadius: 10, justifyContent: "center" },
  exampleText: { color: "#B7B0C9", fontSize: 11 },
  list: { paddingHorizontal: 16, paddingBottom: 20, gap: 10, flexGrow: 1 },
  taskCard: { borderRadius: 19, padding: 15, backgroundColor: "#1C1928", borderWidth: 1, borderColor: "#302A40" },
  taskHeader: { flexDirection: "row", alignItems: "center", gap: 6 },
  statusDot: { width: 7, height: 7, borderRadius: 4 },
  taskState: { color: "#968EA9", fontSize: 10, fontWeight: "800", letterSpacing: 0.8 },
  taskTime: { color: "#706A80", fontSize: 10, marginLeft: "auto" },
  taskTitle: { color: "#F0EDF8", fontSize: 15, fontWeight: "700", lineHeight: 21, marginTop: 8 },
  running: { flexDirection: "row", alignItems: "center", gap: 8, marginTop: 10 },
  runningText: { color: "#A29AAF", fontSize: 12, flex: 1, lineHeight: 17 },
  summary: { color: "#C9C3D5", fontSize: 13, lineHeight: 20, marginTop: 10 },
  taskFooter: { flexDirection: "row", alignItems: "center", gap: 5, marginTop: 11, paddingTop: 10, borderTopWidth: 1, borderTopColor: "#302A40" },
  taskFooterText: { color: "#9D91E8", fontSize: 10, flex: 1 },
  retry: { marginTop: 11, borderRadius: 10, paddingVertical: 9, alignItems: "center", borderWidth: 1, borderColor: "#684255" },
  retryText: { color: "#F1A7B9", fontSize: 12, fontWeight: "700" },
  empty: { alignItems: "center", justifyContent: "center", flex: 1, paddingHorizontal: 36, paddingTop: 25 },
  emptyTitle: { color: "#D6D1E5", fontSize: 16, fontWeight: "700", marginTop: 9 },
  emptyText: { color: "#898296", fontSize: 12, lineHeight: 18, textAlign: "center", marginTop: 5 },
  loading: { marginTop: 30 },
  pressed: { opacity: 0.74, transform: [{ scale: 0.98 }] },
});
