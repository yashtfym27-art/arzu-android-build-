import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { Tabs } from "expo-router";
import { Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { HapticTab } from "@/components/haptic-tab";

export default function TabLayout() {
  const insets = useSafeAreaInsets();
  const bottomPadding = Platform.OS === "web" ? 10 : Math.max(insets.bottom, 8);
  const tabHeight = 59 + bottomPadding;

  return <Tabs screenOptions={{ headerShown: false, tabBarButton: HapticTab, tabBarActiveTintColor: "#B8ACFF", tabBarInactiveTintColor: "#7F788F", tabBarStyle: { height: tabHeight, paddingTop: 7, paddingBottom: bottomPadding, backgroundColor: "#14121D", borderTopColor: "#2D273D", borderTopWidth: 1 }, tabBarLabelStyle: { fontSize: 10, fontWeight: "700" } }}>
    <Tabs.Screen name="index" options={{ title: "Arzu", tabBarIcon: ({ color }) => <MaterialIcons name="forum" size={22} color={color} /> }} />
    <Tabs.Screen name="research" options={{ title: "Araştır", tabBarIcon: ({ color }) => <MaterialIcons name="travel-explore" size={22} color={color} /> }} />
    <Tabs.Screen name="lab" options={{ title: "Laboratuvar", tabBarIcon: ({ color }) => <MaterialIcons name="science" size={22} color={color} /> }} />
    <Tabs.Screen name="media" options={{ title: "Medya", tabBarIcon: ({ color }) => <MaterialIcons name="movie-edit" size={22} color={color} /> }} />
  </Tabs>;
}
