import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useEffect, useState } from "react";
import { ActivityIndicator, FlatList, Pressable, StyleSheet, Text, TextInput, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { arzuStorage } from "@/lib/arzu-storage";
import type { LabRun } from "@/lib/arzu-types";
import { trpc } from "@/lib/trpc";

const GUARANTEES = [
  "Ana sisteme doğrudan yazma yok",
  "Geri dönüş noktası korunur",
  "8 aşamalı test kapısı zorunlu",
];

const PIPELINE = ["Aday", "İzole test", "Risk taraması", "Onay / geri al"];

function uid() {
  return `lab-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}

export default function LabScreen() {
  const [candidate, setCandidate] = useState("");
  const [request, setRequest] = useState("");
  const [domain, setDomain] = useState("Algoritma / Kod");
  const [runs, setRuns] = useState<LabRun[]>([]);
  const [loaded, setLoaded] = useState(false);
  const review = trpc.arzu.labReview.useMutation();
  const generate = trpc.arzu.labGenerate.useMutation();

  useEffect(() => {
    void arzuStorage.getLabs().then((items) => { setRuns(items); setLoaded(true); });
  }, []);

  const persist = (next: LabRun[]) => {
    setRuns(next);
    void arzuStorage.saveLabs(next);
  };

  const runReview = async () => {
    const trimmed = candidate.trim();
    if (trimmed.length < 8 || review.isPending) return;
    const pending: LabRun = {
      id: uid(), candidate: trimmed, domain, status: "review", createdAt: new Date().toISOString(),
      report: "İzole inceleme hazırlanıyor…", checks: [],
    };
    const next = [pending, ...runs];
    persist(next);
    setCandidate("");

    try {
      const result = await review.mutateAsync({ candidate: trimmed, domain });
      persist(next.map((run) => run.id === pending.id ? {
        ...run,
        status: result.verdict === "blocked" ? "blocked" as const : "review" as const,
        report: `${result.summary}\n\nRiskler: ${result.risks.join("; ")}\n\nSonraki adımlar: ${result.nextSteps.join("; ")}`,
        checks: result.checks,
      } : run));
    } catch {
      persist(next.map((run) => run.id === pending.id ? {
        ...run, status: "blocked" as const, report: "Laboratuvar raporu alınamadı. Güvenlik gereği aday bloke edildi; ana sisteme hiçbir değişiklik uygulanmadı.", checks: [],
      } : run));
    }
  };

  const generateAndReview = async () => {
    const trimmed = request.trim();
    if (trimmed.length < 5 || generate.isPending) return;
    try {
      const result = await generate.mutateAsync({ request: trimmed, domain });
      const run: LabRun = {
        id: uid(), candidate: result.candidate, domain, status: result.verdict === "blocked" ? "blocked" : "review", createdAt: new Date().toISOString(),
        report: `${result.summary}\n\nRiskler: ${result.risks.join("; ")}\n\nSonraki adımlar: ${result.nextSteps.join("; ")}`, checks: result.checks,
      };
      persist([run, ...runs]);
      setRequest("");
    } catch (error) {
      setCandidate(`// Kod üretilemedi: ${error instanceof Error ? error.message : "bilinmeyen hata"}`);
    }
  };

  const renderRun = ({ item }: { item: LabRun }) => {
    const blocked = item.status === "blocked";
    return <View style={[styles.runCard, blocked && styles.blockedCard]}>
      <View style={styles.runHeader}>
        <View style={[styles.runBadge, blocked ? styles.blockedBadge : styles.reviewBadge]}><MaterialIcons name={blocked ? "block" : "shield"} size={14} color={blocked ? "#FFB1C3" : "#BFC0FF"} /><Text style={[styles.runBadgeText, blocked ? styles.blockedText : styles.reviewText]}>{blocked ? "BLOKE" : "İNCELEMEDE"}</Text></View>
        <Text style={styles.runDomain}>{item.domain}</Text>
      </View>
      <Text style={styles.runCandidate} numberOfLines={3}>{item.candidate}</Text>
      <Text style={styles.report}>{item.report}</Text>
      {item.checks.length ? <View style={styles.checks}>{item.checks.map((check) => <View key={check} style={styles.check}><MaterialIcons name="check-circle-outline" size={13} color="#7CDBBE" /><Text style={styles.checkText}>{check}</Text></View>)}</View> : <View style={styles.pendingLine}><ActivityIndicator size="small" color="#AAA0EE" /><Text style={styles.pendingText}>Güvenlik kapıları hazırlanıyor…</Text></View>}
    </View>;
  };

  return (
    <ScreenContainer edges={["top", "left", "right"]}>
      <View style={styles.header}>
        <Text style={styles.eyebrow}>GÜVENLİ ÖZ-GELİŞİM</Text>
        <Text style={styles.title}>Sanal laboratuvar</Text>
        <Text style={styles.subtitle}>Yeni yöntemler, formüller ve kod önce ana sistemden bağımsız bir inceleme hattına girer.</Text>
      </View>
      <View style={styles.pipeline}>{PIPELINE.map((step, index) => <View key={step} style={styles.pipelineStep}><View style={styles.pipelineDot}><Text style={styles.pipelineNumber}>{index + 1}</Text></View><Text style={styles.pipelineText}>{step}</Text>{index < PIPELINE.length - 1 ? <View style={styles.pipelineLine} /> : null}</View>)}</View>
      <View style={styles.guardrailCard}>{GUARANTEES.map((item) => <View key={item} style={styles.guardrail}><MaterialIcons name="verified-user" size={15} color="#79D6C1" /><Text style={styles.guardrailText}>{item}</Text></View>)}</View>
      <View style={styles.form}>
        <Text style={styles.label}>ARZU’YA KOD YAZDIR</Text>
        <Text style={styles.formHint}>İsteğini yaz; Arzu TypeScript adayı üretip güvenlik kapılarından geçirsin. APK kendini sessizce değiştirmez; sonuç önce laboratuvarda incelenir.</Text>
        <TextInput value={request} onChangeText={setRequest} placeholder="Örn. Serbest soğutma yükünü hesaplayan saf bir fonksiyon yaz" placeholderTextColor="#77718C" multiline style={styles.candidateInput} maxLength={1200} />
        <Pressable onPress={() => void generateAndReview()} disabled={request.trim().length < 5 || generate.isPending} style={({ pressed }) => [styles.generateButton, (request.trim().length < 5 || generate.isPending) && styles.runDisabled, pressed && styles.pressed]}><MaterialIcons name="auto-awesome" size={19} color="#17131F" /><Text style={styles.runButtonText}>{generate.isPending ? "Arzu kod yazıyor…" : "Arzu yazsın ve laboratuvara gönder"}</Text></Pressable>
        <Text style={[styles.label, { marginTop: 14 }]}>VEYA HAZIR ADAYI İNCELE</Text>
        <TextInput value={candidate} onChangeText={setCandidate} placeholder="TypeScript kodunu buraya yapıştır…" placeholderTextColor="#77718C" multiline style={styles.candidateInput} maxLength={6000} />
        <Text style={styles.label}>ALAN</Text>
        <TextInput value={domain} onChangeText={setDomain} placeholder="Alan" placeholderTextColor="#77718C" style={styles.domainInput} maxLength={100} />
        <Pressable onPress={() => void runReview()} disabled={candidate.trim().length < 8 || review.isPending} style={({ pressed }) => [styles.runButton, (candidate.trim().length < 8 || review.isPending) && styles.runDisabled, pressed && styles.pressed]}><MaterialIcons name="play-arrow" size={20} color="#11131A" /><Text style={styles.runButtonText}>{review.isPending ? "İnceleniyor" : "İzole inceleme başlat"}</Text></Pressable>
      </View>
      {!loaded ? <ActivityIndicator style={styles.loading} color="#9C8EFA" /> : <FlatList data={runs} keyExtractor={(item) => item.id} renderItem={renderRun} contentContainerStyle={styles.list} ListEmptyComponent={<View style={styles.empty}><MaterialIcons name="biotech" size={31} color="#716A85" /><Text style={styles.emptyTitle}>Laboratuvar temiz ve hazır</Text><Text style={styles.emptyText}>Bir aday eklediğinde Arzu, ana sisteme hiçbir değişiklik yapmadan test planını oluşturur.</Text></View>} />}
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: { paddingHorizontal: 20, paddingTop: 10, paddingBottom: 13 },
  eyebrow: { color: "#7DDAC2", fontSize: 10, letterSpacing: 1.3, fontWeight: "800" },
  title: { color: "#F5F3FE", fontSize: 27, lineHeight: 34, fontWeight: "700", letterSpacing: -0.6, marginTop: 3 },
  subtitle: { color: "#A19AAF", fontSize: 13, lineHeight: 19, marginTop: 4 },
  pipeline: { flexDirection: "row", alignItems: "flex-start", paddingHorizontal: 19, paddingBottom: 13 },
  pipelineStep: { flex: 1, alignItems: "center", position: "relative", gap: 5 },
  pipelineDot: { width: 25, height: 25, borderRadius: 13, alignItems: "center", justifyContent: "center", backgroundColor: "#2B2640", borderWidth: 1, borderColor: "#655C91" },
  pipelineNumber: { color: "#D8D1FF", fontSize: 10, fontWeight: "800" },
  pipelineText: { color: "#9F98B1", fontSize: 9, lineHeight: 12, fontWeight: "700", textAlign: "center" },
  pipelineLine: { position: "absolute", height: 1, backgroundColor: "#453B5B", left: "60%", right: "-40%", top: 12, zIndex: -1 },
  guardrailCard: { marginHorizontal: 16, borderWidth: 1, borderColor: "#29483F", backgroundColor: "#15231F", borderRadius: 17, padding: 12, gap: 7 },
  guardrail: { flexDirection: "row", alignItems: "center", gap: 7 },
  guardrailText: { color: "#BEE3D8", fontSize: 11, fontWeight: "600" },
  form: { margin: 16, marginBottom: 10, padding: 13, borderWidth: 1, borderColor: "#373048", backgroundColor: "#201C2E", borderRadius: 20 }, formHint: { color: "#A7A0B7", fontSize: 11, lineHeight: 16, marginBottom: 8 },
  label: { color: "#91899F", fontSize: 10, fontWeight: "800", letterSpacing: 1, marginBottom: 7 },
  candidateInput: { minHeight: 65, color: "#F0EDF8", fontSize: 14, lineHeight: 20, backgroundColor: "#17141F", borderRadius: 12, padding: 10, textAlignVertical: "top", marginBottom: 12 },
  domainInput: { height: 40, color: "#F0EDF8", fontSize: 13, backgroundColor: "#17141F", borderRadius: 12, paddingHorizontal: 10, marginBottom: 12 },
  runButton: { height: 42, backgroundColor: "#BDEEDB", borderRadius: 13, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 6 }, generateButton: { minHeight: 44, backgroundColor: "#B8ACFF", borderRadius: 13, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 6, paddingHorizontal: 8 },
  runDisabled: { backgroundColor: "#4B5A57" },
  runButtonText: { color: "#111A18", fontSize: 13, fontWeight: "800" },
  list: { paddingHorizontal: 16, paddingBottom: 20, gap: 10, flexGrow: 1 },
  runCard: { borderRadius: 18, borderWidth: 1, borderColor: "#343047", backgroundColor: "#1C1928", padding: 14 },
  blockedCard: { borderColor: "#573443" },
  runHeader: { flexDirection: "row", alignItems: "center" },
  runBadge: { flexDirection: "row", alignItems: "center", gap: 4, borderRadius: 8, paddingVertical: 4, paddingHorizontal: 7 },
  reviewBadge: { backgroundColor: "#292642" },
  blockedBadge: { backgroundColor: "#3D2430" },
  runBadgeText: { fontSize: 9, fontWeight: "800", letterSpacing: 0.7 },
  reviewText: { color: "#C9C7FF" },
  blockedText: { color: "#FFB1C3" },
  runDomain: { marginLeft: "auto", color: "#857E93", fontSize: 10 },
  runCandidate: { color: "#EDE9F6", fontSize: 14, lineHeight: 20, fontWeight: "700", marginTop: 9 },
  report: { color: "#BAB3C8", fontSize: 12, lineHeight: 18, marginTop: 8 },
  checks: { marginTop: 10, paddingTop: 9, borderTopWidth: 1, borderTopColor: "#322C42", flexDirection: "row", flexWrap: "wrap", gap: 6 },
  check: { flexDirection: "row", alignItems: "center", gap: 3, backgroundColor: "#1C2C29", paddingHorizontal: 6, paddingVertical: 4, borderRadius: 6 },
  checkText: { color: "#ADD9CF", fontSize: 9 },
  pendingLine: { flexDirection: "row", gap: 7, alignItems: "center", marginTop: 10 },
  pendingText: { color: "#9F98B0", fontSize: 11 },
  empty: { alignItems: "center", justifyContent: "center", flex: 1, paddingHorizontal: 35, paddingTop: 20 },
  emptyTitle: { color: "#D7D2E5", fontSize: 16, fontWeight: "700", marginTop: 9 },
  emptyText: { color: "#8A8397", fontSize: 12, lineHeight: 18, textAlign: "center", marginTop: 5 },
  loading: { marginTop: 30 },
  pressed: { opacity: 0.74, transform: [{ scale: 0.98 }] },
});
