import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useAudioPlayer, useAudioPlayerStatus, useAudioRecorder, useAudioRecorderState, RecordingPresets, requestRecordingPermissionsAsync, setAudioModeAsync } from "expo-audio";
import * as Haptics from "expo-haptics";
import * as FileSystem from "expo-file-system/legacy";
import * as Speech from "expo-speech";
import * as Linking from "expo-linking";
import { pickAttachment, pickPhotoOrVideo, readAndroidSharedContent } from "@/lib/arzu-attachments";
import { router } from "expo-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ActivityIndicator, Alert, Animated, AppState, FlatList, KeyboardAvoidingView, Platform, Pressable, StyleSheet, Text, TextInput, View } from "react-native";

import { ArzuOrb } from "@/components/arzu-orb";
import { ScreenContainer } from "@/components/screen-container";
import { arzuStorage } from "@/lib/arzu-storage";
import type { ChatMessage, MemoryItem } from "@/lib/arzu-types";
import { prepareArzuNotifications } from "@/lib/arzu-notifications";
import { arzuWakeWord } from "@/lib/arzu-events";
import { generateOfflineReply } from "@/lib/arzu-offline";
import { trpc } from "@/lib/trpc";
import { getApiBaseUrl } from "@/constants/oauth";
import { resolveArzuAudioUrl } from "@/lib/arzu-audio";
import { ARZU_OWN_PACKAGE, getAllowedPackages, launchAllowedApp, listInstalledApps } from "@/lib/arzu-app-access";
import { RenderProgress } from "@/components/render-progress";
import { saveMediaToGallery } from "@/lib/arzu-gallery";
import { ArzuBackdrop } from "@/components/arzu-backdrop";
import { AnimatedMessage } from "@/components/animated-message";
import { TypingDots } from "@/components/typing-dots";
import { checkServer, type ServerState } from "@/lib/arzu-connectivity";
import { bringArzuToFront, isAccessibilityEnabled, runScreenAgent } from "@/lib/arzu-accessibility";
import { loadRuntimeApiBaseUrl } from "@/constants/oauth";

const WELCOME: ChatMessage = {
  id: "arzu-welcome",
  role: "assistant",
  text: "Merhaba, ben Arzu. Nereden başlamak istersin? Bir konuyu birlikte çözebilir, araştırabilir ya da sadece konuşabiliriz.",
  createdAt: new Date(0).toISOString(),
};

// Türkçe "I/İ/ı" farkı yüzünden "Instagram".toLocaleLowerCase("tr-TR") = "ınstagram" olurdu
// ve kullanıcının yazdığı "instagram" ile eşleşmezdi. İki taraf da aynı biçime çevrilir.
function normalizeTr(value: string) {
  return value.replace(/İ/g, "i").replace(/I/g, "i").replace(/ı/g, "i").toLowerCase();
}

// JS'te \b yalnızca ASCII harflerle çalışır; "aç" ve "çalıştır" hiç eşleşmiyordu.
// Bu yüzden kelimeler tek tek ayrılıp kök ile karşılaştırılır (aç, açar mısın, açsana...).
function wantsToOpenApp(text: string) {
  return normalizeTr(text).split(/[^a-z0-9çğöşüâ]+/i).some((word) => /^(aç|ac$|acar|acsana|gir|baslat|başlat|çaliştir|calistir|open)/.test(word));
}

// "WhatsApp'ı aç" yalnızca açma isteğidir; "WhatsApp'ta Ali'ye merhaba yaz" ise uygulama içi bir görevdir.
function looksLikeTask(text: string, label: string) {
  const split = (value: string) => normalizeTr(value).split(/[^a-z0-9çğöşüâ]+/i).filter(Boolean);
  const labelWords = split(label).filter((word) => word.length > 1);
  const leftover = split(text).filter((word) => word.length > 2
    && !labelWords.some((labelWord) => word.startsWith(labelWord) || labelWord.startsWith(word))
    && !/^(aç|acar|acsana|gir|baslat|başlat|çaliştir|calistir|open|misin|lütfen|lutfen|bana|şimdi|simdi|uygulama)/.test(word));
  return leftover.length >= 2 || /(^|\s)(yaz|gönder|ara|arat|bul|oku|tikla|tıkla|begen|beğen|takip|kaydet|ekle)/.test(normalizeTr(text));
}

function uid(prefix: string) {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

export default function HomeScreen() {
  const [messages, setMessages] = useState<ChatMessage[]>([WELCOME]);
  const [memories, setMemories] = useState<MemoryItem[]>([]);
  const [draft, setDraft] = useState("");
  const [loaded, setLoaded] = useState(false);
  const [speechReplies, setSpeechReplies] = useState(false);
  const [nativeDictating, setNativeDictating] = useState(false);
  const [showSetup, setShowSetup] = useState(false);
  const [serverState, setServerState] = useState<ServerState>("checking");
  const [speaking, setSpeaking] = useState(false);
  const [preparingVoice, setPreparingVoice] = useState(false);
  const [liveMode, setLiveMode] = useState(false);
  const [agentStatus, setAgentStatus] = useState("");
  const liveModeRef = useRef(false);
  const agentStopRef = useRef(false);
  const startListeningRef = useRef<() => void>(() => undefined);
  const listRef = useRef<FlatList<ChatMessage>>(null);
  const [chatRenderJobId, setChatRenderJobId] = useState("");
  const audioRecorder = useAudioRecorder(RecordingPresets.HIGH_QUALITY);
  const speechPlayer = useAudioPlayer(null);
  const recorderState = useAudioRecorderState(audioRecorder);
  const chatMutation = trpc.arzu.chat.useMutation();
  const uploadAudioMutation = trpc.arzu.uploadAudio.useMutation();
  const transcribeMutation = trpc.arzu.transcribe.useMutation();
  const uploadAttachmentMutation = trpc.arzu.uploadAttachment.useMutation();
  const agentStepMutation = trpc.arzu.agentStep.useMutation();
  const chatRenderStatus = trpc.arzu.mediaRenderStatus.useQuery({ renderJobId: chatRenderJobId || "pending" }, { enabled: Boolean(chatRenderJobId), refetchInterval: (query) => { const state = query.state.data?.status; return state === "completed" || state === "failed" ? false : 2500; } });
  const sendMessageRef = useRef<(override?: string) => Promise<void>>(async () => undefined);
  const ambient = useRef(new Animated.Value(0)).current;

  const saveRenderToGallery = useCallback(async (url: string) => {
    try {
      await saveMediaToGallery(url, "video");
      Alert.alert("Galeriye kaydedildi", "Arzu’nun hazırladığı MP4 galerine kaydedildi.");
    } catch (error) {
      Alert.alert("Galeriye kaydedilemedi", error instanceof Error ? error.message : "Galeri iznini kontrol edip tekrar dene.");
    }
  }, []);

  const speechStatus = useAudioPlayerStatus(speechPlayer);

  const afterSpeech = useCallback(() => {
    setSpeaking(false);
    // Canlı konuşma açıksa Arzu bitirince mikrofon kendiliğinden tekrar dinlemeye geçer.
    if (liveModeRef.current) setTimeout(() => { if (liveModeRef.current) startListeningRef.current(); }, 450);
  }, []);

  useEffect(() => {
    if (speechStatus.didJustFinish) afterSpeech();
    else if (speechStatus.playing) setSpeaking(true);
  }, [speechStatus.didJustFinish, speechStatus.playing, afterSpeech]);

  // Sesi önce hazırlar; metin ve ses aynı anda başlasın diye mesaj ekrana ses hazır olunca düşer.
  const prepareSpeech = useCallback(async (text: string): Promise<string | null> => {
    // Sohbet yanıtlarında harici ElevenLabs kullanma; eski davranış olan
    // Android yerel Türkçe TTS'si playSpeech içinde devreye girer.
    void text;
    return null;
  }, []);

  const playSpeech = useCallback(async (text: string, url: string | null) => {
    if (url) {
      try {
        speechPlayer.replace({ uri: url });
        await speechPlayer.seekTo(0);
        speechPlayer.play();
        setSpeaking(true);
        return;
      } catch {
        // Ses dosyası açılamazsa cihazın yerel Türkçe sesine geç.
      }
    }
    if (Platform.OS === "android" && arzuWakeWord.isNativeAvailable()) {
      const spoken = await arzuWakeWord.speakNow(text, "important");
      if (spoken) {
        setSpeaking(true);
        setTimeout(afterSpeech, Math.min(25000, 1200 + text.length * 70));
        return;
      }
    }
    Speech.stop();
    Speech.speak(text, { language: "tr-TR", rate: 0.95, onStart: () => setSpeaking(true), onDone: afterSpeech, onStopped: () => setSpeaking(false), onError: () => setSpeaking(false) });
  }, [afterSpeech, speechPlayer]);

  const speakReply = useCallback(async (text: string) => {
    const url = await prepareSpeech(text);
    await playSpeech(text, url);
  }, [playSpeech, prepareSpeech]);

  useEffect(() => {
    void Promise.all([arzuStorage.getChats(), arzuStorage.getMemories(), arzuStorage.getSettings()]).then(([storedChats, storedMemories, settings]) => {
      setMessages(storedChats.length ? storedChats : [WELCOME]);
      setMemories(storedMemories);
      setSpeechReplies(settings.speechReplies);
      setLoaded(true);
    });
    void prepareArzuNotifications();
    void setAudioModeAsync({ playsInSilentMode: true, allowsRecording: true });
    void AsyncStorage.getItem("arzu.setup.completed").then((value) => { if (value !== "1") setShowSetup(true); });
  }, []);

  useEffect(() => {
    const pulse = Animated.loop(Animated.sequence([
      Animated.timing(ambient, { toValue: 1, duration: 3200, useNativeDriver: true }),
      Animated.timing(ambient, { toValue: 0, duration: 3200, useNativeDriver: true }),
    ]));
    pulse.start();
    return () => pulse.stop();
  }, [ambient]);

  useEffect(() => {
    let active = true;
    const check = async () => { const state = await checkServer(); if (active) setServerState(state); };
    void loadRuntimeApiBaseUrl().then(check);
    const timer = setInterval(() => void check(), 20000);
    const sub = AppState.addEventListener("change", (state) => { if (state === "active") void check(); });
    return () => { active = false; clearInterval(timer); sub.remove(); };
  }, []);

  useEffect(() => { liveModeRef.current = liveMode; }, [liveMode]);

  const uploadAttachmentRef = useRef(uploadAttachmentMutation.mutateAsync);
  useEffect(() => { uploadAttachmentRef.current = uploadAttachmentMutation.mutateAsync; }, [uploadAttachmentMutation.mutateAsync]);

  // Paylaşım hem açılışta hem de uygulama arka plandan öne gelince okunur.
  useEffect(() => {
    if (!loaded || Platform.OS !== "android") return;
    const readShared = () => {
      void readAndroidSharedContent().then(async (shared) => {
        if (!shared) return;
        if (shared.attachment) {
          try {
            const uploaded = await uploadAttachmentRef.current(shared.attachment);
            setDraft(`${shared.text ? `${shared.text}\n` : ""}Ek dosya: ${uploaded.name} (${uploaded.url})`);
          } catch (error) {
            Alert.alert("Paylaşılan dosya yüklenemedi", error instanceof Error ? error.message : "Sunucuya ulaşılamadı.");
          }
        } else if (shared.text) setDraft(shared.text);
      }).catch(() => undefined);
    };
    readShared();
    const sub = AppState.addEventListener("change", (state) => { if (state === "active") readShared(); });
    return () => sub.remove();
  }, [loaded]);

  const completeSetup = useCallback(async () => {
    await AsyncStorage.setItem("arzu.setup.completed", "1");
    setShowSetup(false);
    const permission = await requestRecordingPermissionsAsync();
    if (!permission.granted) Alert.alert("Mikrofon izni", "Sesli giriş ve wake-word için mikrofon iznini Android Ayarları'ndan etkinleştirebilirsin.");
  }, []);

  const saveMessages = useCallback((next: ChatMessage[]) => {
    setMessages(next);
    void arzuStorage.saveChats(next);
  }, []);

  const sendMessage = useCallback(async (override?: string) => {
    const text = (override ?? draft).trim();
    if (!text || chatMutation.isPending) return;
    void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => undefined);

    const userMessage: ChatMessage = { id: uid("user"), role: "user", text, createdAt: new Date().toISOString(), mode: "chat" };
    const before = messages;
    const next = [...messages, userMessage];
    saveMessages(next);
    setDraft("");

    try {
      if (Platform.OS === "android" && wantsToOpenApp(text)) {
        const [apps, allowed] = await Promise.all([listInstalledApps(), getAllowedPackages()]);
        const normalizedText = normalizeTr(text);
        const allMatched = apps.filter((app) => app.label.trim().length > 1 && normalizedText.includes(normalizeTr(app.label)));
        // "Arzu, YouTube'u aç" cümlesindeki "Arzu" hitaptır; Arzu kendi uygulaması ancak açıkça kastedilirse hedef olur.
        const ownIntent = /(kendi|arzu).{0,24}(uygulama|ayar|profil|medya|hafiza|bellek|sekme|ekran)|kendi (uygulama|ayar)/.test(normalizedText);
        const matched = allMatched.filter((app) => app.packageName !== ARZU_OWN_PACKAGE);
        const ownApp = allMatched.find((app) => app.packageName === ARZU_OWN_PACKAGE) ?? (ownIntent ? { packageName: ARZU_OWN_PACKAGE, label: "Arzu" } : undefined);
        const target = matched.find((app) => allowed.includes(app.packageName)) ?? (ownIntent ? ownApp : undefined);
        if (!target && matched.length) {
          const denied: ChatMessage = { id: uid("arzu"), role: "assistant", text: `${matched[0].label} yüklü ama henüz izin vermedin. Profil > Uygulama erişimi bölümünden ${matched[0].label} anahtarını aç, sonra tekrar iste.`, createdAt: new Date().toISOString(), mode: "chat" };
          saveMessages([...next, denied]);
          if (speechReplies) void speakReply(denied.text);
          return;
        }
        if (target) {
          const opened = await launchAllowedApp(target.packageName);
          let replyText = opened ? `${target.label} uygulamasını açtım.` : `${target.label} açılamadı. Profil > Uygulama erişimi bölümünde önce bu uygulamayı seç.`;
          if (opened && looksLikeTask(text, target.label)) {
            if (!(await isAccessibilityEnabled())) {
              replyText = `${target.label} uygulamasını açtım ama içinde işlem yapabilmem için Erişilebilirlik iznini vermen gerekiyor. Profil > Uygulama içi işlemler bölümünden Arzu'yu etkinleştir.`;
            } else {
              agentStopRef.current = false;
              setAgentStatus(`${target.label} içinde çalışıyorum…`);
              try {
                const outcome = await runScreenAgent({ goal: text, appLabel: target.label, packageName: target.packageName, requestStep: (input) => agentStepMutation.mutateAsync(input), onStatus: setAgentStatus, shouldStop: () => agentStopRef.current });
                replyText = outcome.summary;
              } catch (error) {
                replyText = `${target.label} içinde işlem yaparken takıldım: ${error instanceof Error ? error.message : "sunucuya ulaşılamadı"}.`;
              } finally {
                setAgentStatus("");
                await bringArzuToFront();
              }
            }
          }
          const openReply: ChatMessage = { id: uid("arzu"), role: "assistant", text: replyText, createdAt: new Date().toISOString(), mode: "chat" };
          saveMessages([...next, openReply]);
          if (speechReplies || liveModeRef.current) void speakReply(openReply.text);
          return;
        }
      }
      const result = await chatMutation.mutateAsync({
        message: text,
        recent: before.filter((item) => item.id !== "arzu-welcome").slice(-10).map((item) => ({ role: item.role, text: item.text })),
        memories: memories.map((item) => ({ text: item.text, category: item.category })),
        mode: "chat",
      });
      const reply: ChatMessage = { id: uid("arzu"), role: "assistant", text: result.text, createdAt: new Date().toISOString(), mode: "chat" };
      if (result.mediaJob?.renderJobId) setChatRenderJobId(result.mediaJob.renderJobId);
      const wantsVoice = speechReplies || liveModeRef.current;
      if (wantsVoice && result.text.length <= 500) {
        setPreparingVoice(true);
        const url = await prepareSpeech(result.text);
        setPreparingVoice(false);
        saveMessages([...next, reply]);
        void playSpeech(result.text, url);
      } else {
        saveMessages([...next, reply]);
        if (wantsVoice) void speakReply(result.text);
      }
    } catch {
      const offline = generateOfflineReply(text, memories);
      const fallback: ChatMessage = { id: uid("arzu-offline"), role: "assistant", text: offline.text, createdAt: new Date().toISOString(), mode: "chat" };
      saveMessages([...next, fallback]);
      if (speechReplies) void speakReply(offline.text);
    }
  }, [agentStepMutation, chatMutation, draft, memories, messages, playSpeech, prepareSpeech, saveMessages, speakReply, speechReplies]);

  useEffect(() => { sendMessageRef.current = sendMessage; }, [sendMessage]);

  const toggleRecording = useCallback(async () => {
    if (Platform.OS === "android" && arzuWakeWord.isNativeAvailable()) {
      const permission = await requestRecordingPermissionsAsync();
      if (!permission.granted) {
        Alert.alert("Mikrofon izni gerekli", "Çevrimdışı sesli konuşma için Android mikrofon iznini ver.");
        return;
      }
      setNativeDictating(true);
      const started = await arzuWakeWord.dictate((text) => {
        setNativeDictating(false);
        if (text) void sendMessage(text);
        else if (liveModeRef.current) setLiveMode(false);
        else Alert.alert("Ses anlaşılamadı", "Kısa ve net bir cümle söyleyip tekrar deneyebilirsin.");
      });
      if (!started) {
        setNativeDictating(false);
        setLiveMode(false);
        Alert.alert("Çevrimdışı ses kullanılamıyor", "Bu Android cihazda Türkçe konuşma tanıma dili yüklü değil. Yazılı sohbet ve cihaz TTS'si çalışmaya devam eder.");
      }
      return;
    }
    if (recorderState.isRecording) {
      try {
        await audioRecorder.stop();
        const uri = audioRecorder.uri;
        if (!uri) return;
        const base64 = await FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.Base64 });
        const uploaded = await uploadAudioMutation.mutateAsync({ audioDataUrl: `data:audio/m4a;base64,${base64}`, mimeType: "audio/m4a" });
        const transcript = await transcribeMutation.mutateAsync({ audioUrl: uploaded.audioUrl });
        const clean = transcript.text.replace(/^\s*arzu[,:;.!]?\s*/i, "").trim();
        setDraft(clean || transcript.text);
      } catch {
        Alert.alert("Ses işlenemedi", "Kaydı kısa tutup mikrofon iznini kontrol ederek tekrar dene.");
      }
      return;
    }

    const permission = await requestRecordingPermissionsAsync();
    if (!permission.granted) {
      Alert.alert("Mikrofon izni gerekli", "Arzu'nun sesli konuşmayı anlayabilmesi için mikrofon izni vermelisin.");
      return;
    }
    try {
      await audioRecorder.prepareToRecordAsync();
      audioRecorder.record();
    } catch {
      Alert.alert("Kayıt başlatılamadı", "Cihazın mikrofonu şu an kullanılamıyor.");
    }
  }, [audioRecorder, recorderState.isRecording, sendMessage, transcribeMutation, uploadAudioMutation]);

  useEffect(() => {
    startListeningRef.current = () => {
      if (!nativeDictating && !recorderState.isRecording && !chatMutation.isPending) void toggleRecording();
    };
  }, [chatMutation.isPending, nativeDictating, recorderState.isRecording, toggleRecording]);

  const toggleLiveMode = useCallback(() => {
    const next = !liveModeRef.current;
    liveModeRef.current = next;
    setLiveMode(next);
    void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => undefined);
    if (next) startListeningRef.current();
    else { speechPlayer.pause(); Speech.stop(); setSpeaking(false); }
  }, [speechPlayer]);

  const attachFromDevice = useCallback(async (kind: "file" | "media") => {
    try {
      const attachment = kind === "file" ? await pickAttachment() : await pickPhotoOrVideo();
      if (!attachment) return;
      const uploaded = await uploadAttachmentMutation.mutateAsync(attachment);
      setDraft((current) => `${current ? `${current}\n` : ""}Ek dosya: ${uploaded.name} (${uploaded.url})`);
    } catch {
      Alert.alert("Dosya eklenemedi", "Dosya okunamadı veya boyutu çok büyük. Daha küçük bir dosyayla tekrar dene.");
    }
  }, [uploadAttachmentMutation]);

    useEffect(() => {
      if (!loaded || Platform.OS !== "android") return;
    let wakeEnabled = false;
    const handleWake = (text: string) => {
      if (!/\barzu\b/i.test(text)) return;
      void arzuWakeWord.dictate((spoken) => { if (spoken.trim()) void sendMessageRef.current(spoken.trim()); });
    };
    const ensureWakeWord = () => {
      if (wakeEnabled && arzuWakeWord.isNativeAvailable()) void arzuWakeWord.start(handleWake);
    };
    void arzuStorage.getSettings().then((settings) => {
      if (!settings.wakeWord || !arzuWakeWord.isNativeAvailable()) return;
      wakeEnabled = true;
      void requestRecordingPermissionsAsync().then((permission) => {
        if (!permission.granted) return;
        void arzuWakeWord.start(handleWake);
      });
    });
    const sub = AppState.addEventListener("change", (state) => { if (state === "active") ensureWakeWord(); });
    return () => sub.remove();
    // The native service is intentionally kept alive after this screen unmounts.
  }, [audioRecorder, loaded]);

  const statusText = useMemo(() => {
    if (recorderState.isRecording || nativeDictating) return "Dinliyorum…";
    if (uploadAudioMutation.isPending || transcribeMutation.isPending) return "Sesi çözümlüyorum…";
    if (chatMutation.isPending) return "Düşünüyorum…";
    if (preparingVoice) return "Sesimi hazırlıyorum…";
    if (speaking) return "Konuşuyorum…";
    if (agentStatus) return agentStatus;
    return liveMode ? "Canlı konuşma açık" : "Hazırım";
  }, [agentStatus, chatMutation.isPending, liveMode, nativeDictating, preparingVoice, recorderState.isRecording, speaking, transcribeMutation.isPending, uploadAudioMutation.isPending]);

  const renderMessage = ({ item }: { item: ChatMessage }) => (
    <AnimatedMessage fromUser={item.role === "user"}>
    <View style={[styles.messageRow, item.role === "user" ? styles.userRow : styles.assistantRow]}>
      {item.role === "assistant" ? <View style={[styles.avatar, fx.avatarGlow]}><Text style={styles.avatarText}>A</Text></View> : null}
      <View style={[styles.bubble, item.role === "user" ? styles.userBubble : styles.assistantBubble, item.role === "user" ? fx.userGlow : fx.assistantGlow]}>
        <Text style={[styles.bubbleText, item.role === "user" && styles.userBubbleText]}>{item.text}</Text>
      </View>
    </View>
    </AnimatedMessage>
  );

  if (!loaded) {
    return <ScreenContainer className="items-center justify-center"><ActivityIndicator color="#8E7AF3" /></ScreenContainer>;
  }

  return (
    <ScreenContainer edges={["top", "left", "right"]} containerClassName="bg-background">
      <ArzuBackdrop />
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <View style={styles.header}>
          <View>
            <Text style={styles.eyebrow}>KİŞİSEL YAPAY ZEKA ASİSTANIN</Text>
            <Text style={styles.title}>Arzu</Text>
          </View>
          <View style={styles.headerActions}>
            {Platform.OS === "android" && arzuWakeWord.isNativeAvailable() ? (
              <Pressable onPress={toggleLiveMode} style={({ pressed }) => [styles.iconButton, liveMode && fx.liveOn, pressed && styles.pressed]} accessibilityLabel="Canlı sesli konuşmayı aç veya kapat">
                <MaterialIcons name={liveMode ? "hearing" : "record-voice-over"} size={21} color={liveMode ? "#FFFFFF" : "#AFA9CA"} />
              </Pressable>
            ) : null}
            <Pressable onPress={() => router.push("/vision")} style={({ pressed }) => [styles.iconButton, pressed && styles.pressed]} accessibilityLabel="Görsel analiz aç">
              <MaterialIcons name="photo-camera" size={21} color="#AFA9CA" />
            </Pressable>
            <Pressable onPress={() => router.push("/profile")} style={({ pressed }) => [styles.iconButton, pressed && styles.pressed]} accessibilityLabel="Ayarlar aç">
              <MaterialIcons name="tune" size={21} color="#AFA9CA" />
            </Pressable>
          </View>
        </View>

        <View style={styles.voicePanel}>
          <ArzuOrb active={recorderState.isRecording || nativeDictating} speaking={speaking} busy={chatMutation.isPending || preparingVoice || transcribeMutation.isPending || uploadAudioMutation.isPending} onPress={toggleRecording} />
          <View style={styles.voiceCopy}>
            <Text style={styles.voiceStatus}>{statusText}</Text>
            <Text style={styles.voiceHint}>Dokun ve konuş veya yalnızca “Arzu” de. Wake word aktif konuşmayı başlatır; Arzu&apos;nun kendi bildirimleri için gerekmez.</Text>
          </View>
        </View>

        <View style={styles.statusGrid}>
          <Pressable onPress={() => { if (serverState === "server-down") router.push("/profile"); else { setServerState("checking"); void checkServer().then(setServerState); } }} style={({ pressed }) => [styles.statusCard, pressed && styles.pressed]}>
            <View style={[styles.statusIcon, { backgroundColor: serverState === "online" ? "#203B35" : "#2C2948" }]}><MaterialIcons name={serverState === "online" ? "cloud-done" : serverState === "checking" ? "sync" : "cloud-off"} size={17} color={serverState === "online" ? "#7CDBBE" : "#B8ACFF"} /></View>
            <View style={styles.statusCopy}><Text style={styles.statusLabel}>HİBRİT ÇEKİRDEK</Text><Text style={styles.statusValue}>{serverState === "online" ? "Çevrim içi AI" : serverState === "checking" ? "Bağlantı kontrol ediliyor" : serverState === "server-down" ? "İnternet var · sunucu yanıt vermiyor (dokun)" : "İnternet yok · yerel mod"}</Text></View>
          </Pressable>
          <View style={styles.statusCard}>
            <View style={[styles.statusIcon, { backgroundColor: "#203B35" }]}><MaterialIcons name="memory" size={17} color="#7CDBBE" /></View>
            <View style={styles.statusCopy}><Text style={styles.statusLabel}>KALICI HAFIZA</Text><Text style={styles.statusValue}>{memories.length} kayıt aktif</Text></View>
          </View>
        </View>

        <View style={styles.shortcuts}>
          <Pressable onPress={() => router.push("/research")} style={({ pressed }) => [styles.shortcut, pressed && styles.pressed]}>
            <MaterialIcons name="travel-explore" size={18} color="#BFB5FF" />
            <Text style={styles.shortcutText}>Araştır</Text>
          </Pressable>
          <Pressable onPress={() => router.push("/lab")} style={({ pressed }) => [styles.shortcut, pressed && styles.pressed]}>
            <MaterialIcons name="science" size={18} color="#77D3C2" />
            <Text style={styles.shortcutText}>Laboratuvar</Text>
          </Pressable>
          <Pressable onPress={() => setDraft("Bugün önceliklerimi birlikte planlayalım.")} style={({ pressed }) => [styles.shortcut, pressed && styles.pressed]}>
            <MaterialIcons name="event-note" size={18} color="#F3C58C" />
            <Text style={styles.shortcutText}>Planla</Text>
          </Pressable>
        </View>

        <FlatList
          ref={listRef}
          onContentSizeChange={() => listRef.current?.scrollToEnd({ animated: true })}
          ListFooterComponent={chatMutation.isPending || preparingVoice ? <View style={fx.typingRow}><View style={[styles.avatar, fx.avatarGlow]}><Text style={styles.avatarText}>A</Text></View><View style={[styles.bubble, styles.assistantBubble, fx.assistantGlow]}><TypingDots /></View></View> : null}
          data={messages}
          keyExtractor={(item) => item.id}
          renderItem={renderMessage}
          contentContainerStyle={styles.messages}
          showsVerticalScrollIndicator={false}
          style={styles.messageList}
        />

        {agentStatus ? <View style={fx.agentBar}><ActivityIndicator color="#B8ACFF" size="small" /><Text style={fx.agentText}>{agentStatus}</Text><Pressable onPress={() => { agentStopRef.current = true; }} style={fx.agentStop}><Text style={fx.agentStopText}>Durdur</Text></Pressable></View> : null}

        {chatRenderStatus.data ? <View style={styles.renderStatus}><MaterialIcons name={chatRenderStatus.data.status === "completed" ? "check-circle" : chatRenderStatus.data.status === "failed" ? "error-outline" : "hourglass-top"} size={18} color={chatRenderStatus.data.status === "completed" ? "#7CDBBE" : "#F3C58C"} /><View style={styles.renderStatusCopy}><Text style={styles.renderStatusTitle}>Medya üretimi</Text><Text style={styles.renderStatusText}>{chatRenderStatus.data.message}</Text>{chatRenderStatus.data.status === "queued" ? <RenderProgress percent={(chatRenderStatus.data as unknown as { progress?: number }).progress} label="Video hazırlanıyor" /> : null}{chatRenderStatus.data.status === "completed" && chatRenderStatus.data.url ? <View style={styles.renderActions}><Pressable onPress={() => { const url = chatRenderStatus.data?.url; if (url) void Linking.openURL(url); }} style={styles.downloadButton}><MaterialIcons name="open-in-new" size={15} color="#171321" /><Text style={styles.downloadText}>MP4&apos;ü aç</Text></Pressable><Pressable onPress={() => { const url = chatRenderStatus.data?.url; if (url) void saveRenderToGallery(url); }} style={styles.downloadButton}><MaterialIcons name="save-alt" size={15} color="#171321" /><Text style={styles.downloadText}>Galerime kaydet</Text></Pressable></View> : null}</View></View> : null}

        <View style={styles.composerWrap}>
          <View style={styles.composer}>
            <Pressable onPress={() => void attachFromDevice("media")} style={({ pressed }) => [styles.attachButton, pressed && styles.pressed]} accessibilityLabel="Fotoğraf veya video ekle">
              <MaterialIcons name="add-photo-alternate" size={19} color="#B8ACFF" />
            </Pressable>
            <Pressable onPress={() => void attachFromDevice("file")} style={({ pressed }) => [styles.attachButton, pressed && styles.pressed]} accessibilityLabel="Dosya ekle">
              <MaterialIcons name="attach-file" size={19} color="#B8ACFF" />
            </Pressable>
            <TextInput
              value={draft}
              onChangeText={setDraft}
              placeholder="Arzu'ya bir şey sor…"
              placeholderTextColor="#77718C"
              style={styles.input}
              multiline
              maxLength={6000}
              onSubmitEditing={() => void sendMessage()}
              returnKeyType="send"
            />
            <Pressable onPress={() => void sendMessage()} disabled={!draft.trim() || chatMutation.isPending} style={({ pressed }) => [styles.sendButton, (!draft.trim() || chatMutation.isPending) && styles.sendDisabled, pressed && styles.pressed]} accessibilityLabel="Mesaj gönder">
              <MaterialIcons name="arrow-upward" size={20} color="#11101A" />
            </Pressable>
          </View>
          <Text style={styles.privacyNote}>Sohbet geçmişi ve seçtiğin hafızalar bu cihazda saklanır. Hassas bilgileri bilinçli olarak paylaş.</Text>
        </View>
      </KeyboardAvoidingView>
      {showSetup ? <View style={styles.setupBackdrop}><View style={styles.setupCard}><View style={styles.setupIcon}><MaterialIcons name="auto-awesome" size={26} color="#16131F" /></View><Text style={styles.setupTitle}>Arzu&apos;yu kuralım</Text><Text style={styles.setupText}>Arzu kişisel kullanım için hazırlandı. Sesli giriş, “Arzu” wake-word, kamera analizi ve önemli olay bildirimleri için izinleri sonraki adımda isteyecek.</Text><View style={styles.setupRow}><MaterialIcons name="lock-outline" size={18} color="#75D2BC" /><Text style={styles.setupRowText}>Hafıza bu cihazda tutulur.</Text></View><View style={styles.setupRow}><MaterialIcons name="record-voice-over" size={18} color="#B8ACFF" /><Text style={styles.setupRowText}>Wake-word yalnızca “Arzu” kelimesidir.</Text></View><Pressable onPress={() => void completeSetup()} style={({ pressed }) => [styles.setupButton, pressed && styles.pressed]}><Text style={styles.setupButtonText}>İzinleri ayarla ve başla</Text></Pressable><Text style={styles.setupFoot}>İzinleri daha sonra Android Ayarları’ndan değiştirebilirsin.</Text></View></View> : null}
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  ambientLayer: { position: "absolute", top: -35, right: -20, width: 260, height: 260, zIndex: 0 },
  ambientOrbOne: { position: "absolute", width: 190, height: 190, borderRadius: 95, right: 10, top: 0, backgroundColor: "#7259E8" },
  ambientOrbTwo: { position: "absolute", width: 130, height: 130, borderRadius: 65, right: 100, top: 105, backgroundColor: "#D364A8" },
  header: { paddingHorizontal: 20, paddingTop: 10, paddingBottom: 14, flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  eyebrow: { color: "#837C9B", fontSize: 10, letterSpacing: 1.4, fontWeight: "700" },
  title: { color: "#F5F3FE", fontSize: 31, lineHeight: 38, fontWeight: "700", letterSpacing: -0.8 },
  headerActions: { flexDirection: "row", gap: 9 },
  iconButton: { width: 42, height: 42, alignItems: "center", justifyContent: "center", borderRadius: 15, borderWidth: 1, borderColor: "#302B45", backgroundColor: "#1D1A2A" },
  voicePanel: { marginHorizontal: 16, padding: 16, borderRadius: 24, backgroundColor: "#1B1828", borderWidth: 1, borderColor: "#312B48", flexDirection: "row", alignItems: "center", gap: 15 },
  voiceCopy: { flex: 1, gap: 5 },
  voiceStatus: { color: "#F2F0FA", fontSize: 16, lineHeight: 22, fontWeight: "700" },
  voiceHint: { color: "#9F99B5", fontSize: 12, lineHeight: 18 },
  statusGrid: { flexDirection: "row", gap: 9, paddingHorizontal: 16, paddingTop: 1 },
  statusCard: { flex: 1, minHeight: 64, borderRadius: 17, backgroundColor: "#1C1929", borderWidth: 1, borderColor: "#312B48", padding: 10, flexDirection: "row", alignItems: "center", gap: 9 },
  statusIcon: { width: 34, height: 34, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  statusCopy: { flex: 1, gap: 3 },
  statusLabel: { color: "#89819F", fontSize: 8, letterSpacing: 0.7, fontWeight: "800" },
  statusValue: { color: "#E6E1F2", fontSize: 11, lineHeight: 15, fontWeight: "700" },
  shortcuts: { flexDirection: "row", gap: 8, paddingHorizontal: 16, paddingVertical: 13 },
  shortcut: { flex: 1, minHeight: 43, borderRadius: 14, backgroundColor: "#201C2E", alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 6, borderWidth: 1, borderColor: "#312B45" },
  shortcutText: { color: "#D8D3E8", fontSize: 12, fontWeight: "700" },
  messageList: { flex: 1 },
  messages: { paddingHorizontal: 16, paddingBottom: 12, gap: 11 },
  messageRow: { flexDirection: "row", alignItems: "flex-end", gap: 8 },
  userRow: { justifyContent: "flex-end" },
  assistantRow: { justifyContent: "flex-start" },
  avatar: { width: 27, height: 27, borderRadius: 14, backgroundColor: "#7564E5", alignItems: "center", justifyContent: "center", marginBottom: 2 },
  avatarText: { color: "#FFF", fontSize: 12, fontWeight: "800" },
  bubble: { paddingVertical: 10, paddingHorizontal: 13, borderRadius: 17, maxWidth: "83%" },
  assistantBubble: { backgroundColor: "#211E30", borderBottomLeftRadius: 5 },
  userBubble: { backgroundColor: "#8070E5", borderBottomRightRadius: 5 },
  bubbleText: { color: "#EAE7F4", fontSize: 14, lineHeight: 20 },
  userBubbleText: { color: "#11101A" },
  composerWrap: { paddingHorizontal: 16, paddingTop: 8, paddingBottom: 10, borderTopWidth: 1, borderTopColor: "#2B263D", backgroundColor: "#14121D" },
  composer: { minHeight: 51, borderRadius: 18, borderWidth: 1, borderColor: "#39324E", backgroundColor: "#201C2D", flexDirection: "row", alignItems: "flex-end", padding: 6 },
  attachButton: { width: 30, height: 38, alignItems: "center", justifyContent: "center" },
  input: { flex: 1, color: "#F1EEF8", fontSize: 15, lineHeight: 21, paddingHorizontal: 10, paddingVertical: 8, maxHeight: 95 },
  sendButton: { width: 38, height: 38, borderRadius: 14, alignItems: "center", justifyContent: "center", backgroundColor: "#C9BEFF" },
  sendDisabled: { backgroundColor: "#4B465C" },
  privacyNote: { color: "#77718A", fontSize: 10, lineHeight: 14, marginTop: 7, paddingHorizontal: 4 },
  renderActions: { flexDirection: "row", gap: 7, flexWrap: "wrap" }, renderStatus: { marginHorizontal: 16, marginBottom: 8, padding: 11, borderRadius: 16, borderWidth: 1, borderColor: "#594D78", backgroundColor: "#242035", flexDirection: "row", gap: 9, alignItems: "flex-start" },
  renderStatusCopy: { flex: 1, gap: 3 },
  renderStatusTitle: { color: "#E9E3FA", fontSize: 12, fontWeight: "800" },
  renderStatusText: { color: "#BDB5D0", fontSize: 11, lineHeight: 16 },
  downloadButton: { alignSelf: "flex-start", marginTop: 5, borderRadius: 9, paddingHorizontal: 9, paddingVertical: 6, backgroundColor: "#B8ACFF", flexDirection: "row", alignItems: "center", gap: 5 },
  downloadText: { color: "#171321", fontSize: 11, fontWeight: "800" },
  pressed: { opacity: 0.74, transform: [{ scale: 0.97 }] },
  setupBackdrop: { position: "absolute", top: 0, right: 0, bottom: 0, left: 0, backgroundColor: "rgba(10, 8, 16, 0.78)", alignItems: "center", justifyContent: "center", padding: 22 },
  setupCard: { width: "100%", maxWidth: 390, borderRadius: 24, padding: 22, backgroundColor: "#211E30", borderWidth: 1, borderColor: "#514577", gap: 12 },
  setupIcon: { width: 48, height: 48, borderRadius: 16, backgroundColor: "#B8ACFF", alignItems: "center", justifyContent: "center" },
  setupTitle: { color: "#F5F3FE", fontSize: 24, fontWeight: "800" },
  setupText: { color: "#C4BED3", fontSize: 13, lineHeight: 20 },
  setupRow: { flexDirection: "row", alignItems: "center", gap: 9 },
  setupRowText: { color: "#E3DEED", fontSize: 12, flex: 1 },
  setupButton: { minHeight: 48, borderRadius: 15, alignItems: "center", justifyContent: "center", backgroundColor: "#B8ACFF", marginTop: 5 },
  setupButtonText: { color: "#16131F", fontWeight: "800", fontSize: 14 },
  setupFoot: { color: "#8E87A4", fontSize: 10, textAlign: "center" },
});

const fx = StyleSheet.create({
  userGlow: { shadowColor: "#7A5CFF", shadowOpacity: 0.55, shadowRadius: 12, shadowOffset: { width: 0, height: 4 }, elevation: 6 },
  assistantGlow: { borderWidth: 1, borderColor: "rgba(184,172,255,0.22)", shadowColor: "#000000", shadowOpacity: 0.3, shadowRadius: 10, shadowOffset: { width: 0, height: 3 }, elevation: 3 },
  avatarGlow: { shadowColor: "#7A5CFF", shadowOpacity: 0.7, shadowRadius: 10, shadowOffset: { width: 0, height: 0 }, elevation: 5 },
  typingRow: { flexDirection: "row", alignItems: "flex-end", gap: 8, marginTop: 4 },
  liveOn: { backgroundColor: "#2FA894", borderColor: "#7CDBBE" },
  agentBar: { marginHorizontal: 16, marginBottom: 8, paddingHorizontal: 12, paddingVertical: 9, borderRadius: 16, flexDirection: "row", alignItems: "center", gap: 10, backgroundColor: "rgba(40,34,66,0.92)", borderWidth: 1, borderColor: "rgba(184,172,255,0.35)" },
  agentText: { flex: 1, color: "#DAD3FF", fontSize: 12 },
  agentStop: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 12, backgroundColor: "#F0589A" },
  agentStopText: { color: "#FFFFFF", fontSize: 12, fontWeight: "700" },
});
