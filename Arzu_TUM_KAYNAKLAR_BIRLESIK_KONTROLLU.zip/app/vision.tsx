import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import * as ImagePicker from "expo-image-picker";
import { router } from "expo-router";
import { useEffect, useState } from "react";
import { ActivityIndicator, Alert, Image, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { arzuStorage } from "@/lib/arzu-storage";
import type { MemoryItem } from "@/lib/arzu-types";
import { trpc } from "@/lib/trpc";

export default function VisionScreen() {
  const [imageUri, setImageUri] = useState<string | null>(null);
  const [imageDataUrl, setImageDataUrl] = useState<string | null>(null);
  const [question, setQuestion] = useState("Bu görseli teknik açıdan analiz et; önemli öğeleri, olası riskleri ve dikkat edilmesi gerekenleri belirt.");
  const [answer, setAnswer] = useState("");
  const [memories, setMemories] = useState<MemoryItem[]>([]);
  const vision = trpc.arzu.vision.useMutation();

  useEffect(() => { void arzuStorage.getMemories().then(setMemories); }, []);

  const setImage = (asset: ImagePicker.ImagePickerAsset) => {
    if (!asset.base64) {
      Alert.alert("Görsel okunamadı", "Lütfen daha küçük bir fotoğrafla tekrar dene.");
      return;
    }
    const mime = asset.mimeType === "image/png" ? "image/png" : asset.mimeType === "image/webp" ? "image/webp" : "image/jpeg";
    setImageUri(asset.uri);
    setImageDataUrl(`data:${mime};base64,${asset.base64}`);
    setAnswer("");
  };

  const pickImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, allowsEditing: true, aspect: [4, 3], quality: 0.5, base64: true });
    if (!result.canceled) setImage(result.assets[0]);
  };

  const takePhoto = async () => {
    const permission = await ImagePicker.requestCameraPermissionsAsync();
    if (!permission.granted) { Alert.alert("Kamera izni gerekli", "Arzu'nun görseli analiz edebilmesi için kamera izni vermelisin."); return; }
    const result = await ImagePicker.launchCameraAsync({ allowsEditing: true, aspect: [4, 3], quality: 0.5, base64: true });
    if (!result.canceled) setImage(result.assets[0]);
  };

  const analyze = async () => {
    if (!imageDataUrl || !question.trim()) return;
    try {
      const result = await vision.mutateAsync({ imageDataUrl, prompt: question.trim(), memories: memories.map((item) => ({ text: item.text, category: item.category })) });
      setAnswer(result.text);
    } catch {
      Alert.alert("Görsel analiz edilemedi", "Ağ bağlantını kontrol edip daha küçük bir görselle tekrar dene.");
    }
  };

  return <ScreenContainer edges={["top", "bottom", "left", "right"]}><ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
    <View style={styles.topbar}><Pressable onPress={() => router.back()} style={({ pressed }) => [styles.back, pressed && styles.pressed]}><MaterialIcons name="arrow-back" size={21} color="#DAD5E8" /></Pressable><View><Text style={styles.eyebrow}>KAMERA · GÖRSEL ANALİZ</Text><Text style={styles.title}>Arzu’nun gözü</Text></View></View>
    <Text style={styles.subtitle}>Fotoğraf çek veya galeriden seç. Arzu görseli sorununla birlikte değerlendirir; belirsiz ayrıntıları kesinmiş gibi sunmaz.</Text>
    {imageUri ? <Image source={{ uri: imageUri }} style={styles.preview} /> : <View style={styles.placeholder}><MaterialIcons name="center-focus-strong" size={37} color="#8279A1" /><Text style={styles.placeholderTitle}>Analiz için bir görsel ekle</Text><Text style={styles.placeholderText}>Makine/tesisat, devre, belge, çizim veya günlük bir nesne olabilir.</Text></View>}
    <View style={styles.pickRow}><Pressable onPress={takePhoto} style={({ pressed }) => [styles.pickButton, styles.primaryPick, pressed && styles.pressed]}><MaterialIcons name="photo-camera" size={18} color="#16121F" /><Text style={styles.primaryPickText}>Fotoğraf çek</Text></Pressable><Pressable onPress={pickImage} style={({ pressed }) => [styles.pickButton, styles.secondaryPick, pressed && styles.pressed]}><MaterialIcons name="collections" size={18} color="#D2CBEC" /><Text style={styles.secondaryPickText}>Galeriden seç</Text></Pressable></View>
    <Text style={styles.label}>ARZU NEYE BAKSIN?</Text>
    <TextInput value={question} onChangeText={setQuestion} multiline maxLength={2000} style={styles.question} placeholderTextColor="#77718C" />
    <Pressable onPress={() => void analyze()} disabled={!imageDataUrl || vision.isPending} style={({ pressed }) => [styles.analyze, (!imageDataUrl || vision.isPending) && styles.disabled, pressed && styles.pressed]}>{vision.isPending ? <ActivityIndicator color="#15111C" /> : <><MaterialIcons name="visibility" size={19} color="#15111C" /><Text style={styles.analyzeText}>Görseli analiz et</Text></>}</Pressable>
    {answer ? <View style={styles.answer}><View style={styles.answerHeader}><View style={styles.answerAvatar}><Text style={styles.answerAvatarText}>A</Text></View><Text style={styles.answerLabel}>ARZU&apos;NUN ANALİZİ</Text></View><Text style={styles.answerText}>{answer}</Text></View> : null}
    <View style={styles.privacy}><MaterialIcons name="lock-outline" size={16} color="#7AD6BF" /><Text style={styles.privacyText}>Görsel analiz için güvenli işlem hattına aktarılır; kalıcı hafızaya yalnızca sen özellikle eklersen kaydedilir.</Text></View>
  </ScrollView></ScreenContainer>;
}

const styles = StyleSheet.create({
  scroll: { padding: 16, paddingTop: 10, gap: 12 }, topbar: { flexDirection: "row", alignItems: "center", gap: 11 }, back: { width: 39, height: 39, alignItems: "center", justifyContent: "center", borderRadius: 13, backgroundColor: "#211D2E", borderWidth: 1, borderColor: "#373048" }, eyebrow: { color: "#A99BFD", fontSize: 9, fontWeight: "800", letterSpacing: 1.1 }, title: { color: "#F5F3FE", fontSize: 23, lineHeight: 28, fontWeight: "700" }, subtitle: { color: "#A19AAF", fontSize: 13, lineHeight: 19, marginTop: 2 }, placeholder: { height: 205, borderRadius: 21, backgroundColor: "#1C1928", borderWidth: 1, borderColor: "#353045", borderStyle: "dashed", alignItems: "center", justifyContent: "center", paddingHorizontal: 33 }, placeholderTitle: { color: "#DCD7E9", fontSize: 15, fontWeight: "700", marginTop: 8 }, placeholderText: { color: "#8D869B", fontSize: 12, lineHeight: 17, textAlign: "center", marginTop: 3 }, preview: { width: "100%", height: 230, borderRadius: 21, backgroundColor: "#201C2E" }, pickRow: { flexDirection: "row", gap: 8 }, pickButton: { flex: 1, height: 45, borderRadius: 14, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 6 }, primaryPick: { backgroundColor: "#C9BEFF" }, secondaryPick: { backgroundColor: "#201C2E", borderWidth: 1, borderColor: "#39324E" }, primaryPickText: { color: "#15121F", fontSize: 12, fontWeight: "800" }, secondaryPickText: { color: "#D9D3E9", fontSize: 12, fontWeight: "800" }, label: { color: "#91899F", fontSize: 10, fontWeight: "800", letterSpacing: 1, marginTop: 4 }, question: { minHeight: 75, textAlignVertical: "top", borderRadius: 16, backgroundColor: "#201C2E", borderWidth: 1, borderColor: "#373048", color: "#EFEAF8", padding: 12, fontSize: 14, lineHeight: 20 }, analyze: { height: 46, borderRadius: 14, backgroundColor: "#BDEEDB", alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 7 }, disabled: { backgroundColor: "#4D5D59" }, analyzeText: { color: "#151A18", fontWeight: "800", fontSize: 13 }, answer: { borderRadius: 18, backgroundColor: "#1C1928", borderWidth: 1, borderColor: "#342E46", padding: 14 }, answerHeader: { flexDirection: "row", alignItems: "center", gap: 7 }, answerAvatar: { width: 25, height: 25, borderRadius: 13, backgroundColor: "#7868E4", alignItems: "center", justifyContent: "center" }, answerAvatarText: { color: "#FFF", fontWeight: "800", fontSize: 11 }, answerLabel: { color: "#ACA2C5", fontSize: 10, letterSpacing: 1, fontWeight: "800" }, answerText: { color: "#D8D3E4", fontSize: 13, lineHeight: 20, marginTop: 10 }, privacy: { flexDirection: "row", gap: 7, borderRadius: 13, padding: 11, backgroundColor: "#16231F", alignItems: "flex-start" }, privacyText: { color: "#B8D8D0", fontSize: 11, lineHeight: 16, flex: 1 }, pressed: { opacity: 0.75, transform: [{ scale: 0.98 }] },
});
