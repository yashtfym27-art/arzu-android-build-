import { useEffect, useMemo, useRef } from "react";
import { Animated, Easing, StyleSheet, View } from "react-native";

/** Dinlerken veya konuşurken orb'un altında dalgalanan ses çubukları. */
export function ArzuWaveform({ active, color }: { active: boolean; color: string }) {
  const bars = useMemo(() => [0.55, 0.9, 0.7, 1, 0.65, 0.85, 0.5], []);
  const values = useRef(bars.map(() => new Animated.Value(0))).current;

  useEffect(() => {
    if (!active) { values.forEach((value) => value.setValue(0)); return; }
    const loops = values.map((value, index) => Animated.loop(Animated.sequence([
      Animated.delay(index * 90),
      Animated.timing(value, { toValue: 1, duration: 320 + index * 35, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      Animated.timing(value, { toValue: 0, duration: 320 + index * 35, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
    ])));
    loops.forEach((loop) => loop.start());
    return () => loops.forEach((loop) => loop.stop());
  }, [active, values]);

  return (
    <View style={styles.row} pointerEvents="none">
      {values.map((value, index) => (
        <Animated.View
          key={index}
          style={[styles.bar, { backgroundColor: color, opacity: active ? 1 : 0.25, transform: [{ scaleY: value.interpolate({ inputRange: [0, 1], outputRange: [0.25, bars[index]] }) }] }]}
        />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  row: { height: 26, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 4 },
  bar: { width: 4, height: 26, borderRadius: 2 },
});
