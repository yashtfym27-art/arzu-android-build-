import { useEffect, useRef } from "react";
import { Animated, Easing, StyleSheet, Text, View } from "react-native";

/** Video/animasyon üretimi sırasında kayan ışıklı ilerleme çubuğu. */
export function RenderProgress({ percent, label }: { percent?: number; label?: string }) {
  const shimmer = useRef(new Animated.Value(0)).current;
  const fill = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const loop = Animated.loop(Animated.timing(shimmer, { toValue: 1, duration: 1400, easing: Easing.linear, useNativeDriver: true }));
    loop.start();
    return () => loop.stop();
  }, [shimmer]);

  useEffect(() => {
    Animated.timing(fill, { toValue: Math.max(4, Math.min(100, percent ?? 8)), duration: 600, easing: Easing.out(Easing.cubic), useNativeDriver: false }).start();
  }, [fill, percent]);

  return (
    <View style={styles.wrap}>
      <View style={styles.track}>
        <Animated.View style={[styles.fill, { width: fill.interpolate({ inputRange: [0, 100], outputRange: ["0%", "100%"] }) }]}>
          <Animated.View style={[styles.shine, { transform: [{ translateX: shimmer.interpolate({ inputRange: [0, 1], outputRange: [-60, 220] }) }] }]} />
        </Animated.View>
      </View>
      <View style={styles.row}>
        <Text style={styles.label} numberOfLines={1}>{label ?? "Hazırlanıyor…"}</Text>
        {typeof percent === "number" ? <Text style={styles.percent}>%{Math.round(percent)}</Text> : null}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { gap: 6, alignSelf: "stretch" },
  track: { height: 8, borderRadius: 4, backgroundColor: "#2E2845", overflow: "hidden" },
  fill: { height: 8, borderRadius: 4, backgroundColor: "#8B7BFF", overflow: "hidden" },
  shine: { position: "absolute", top: 0, bottom: 0, width: 60, backgroundColor: "rgba(255,255,255,0.35)" },
  row: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  label: { color: "#C5BEDB", fontSize: 11, flex: 1 },
  percent: { color: "#B8ACFF", fontSize: 11, fontWeight: "800" },
});
