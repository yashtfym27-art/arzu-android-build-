import { useEffect, useRef } from "react";
import { Animated, Easing, StyleSheet, View } from "react-native";

function Dot({ delay }: { delay: number }) {
  const value = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(Animated.sequence([
      Animated.delay(delay),
      Animated.timing(value, { toValue: 1, duration: 320, easing: Easing.out(Easing.quad), useNativeDriver: true }),
      Animated.timing(value, { toValue: 0, duration: 320, easing: Easing.in(Easing.quad), useNativeDriver: true }),
      Animated.delay(480 - delay),
    ]));
    loop.start();
    return () => loop.stop();
  }, [delay, value]);
  return <Animated.View style={[styles.dot, { opacity: value.interpolate({ inputRange: [0, 1], outputRange: [0.35, 1] }), transform: [{ translateY: value.interpolate({ inputRange: [0, 1], outputRange: [0, -5] }) }] }]} />;
}

export function TypingDots() {
  return <View style={styles.row}><Dot delay={0} /><Dot delay={160} /><Dot delay={320} /></View>;
}

const styles = StyleSheet.create({
  row: { flexDirection: "row", alignItems: "center", gap: 6, paddingVertical: 6, paddingHorizontal: 4 },
  dot: { width: 8, height: 8, borderRadius: 4, backgroundColor: "#B8ACFF" },
});
