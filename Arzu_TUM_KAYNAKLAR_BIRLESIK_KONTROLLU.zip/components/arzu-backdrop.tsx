import { useEffect, useMemo, useRef } from "react";
import { Animated, Dimensions, Easing, StyleSheet, View } from "react-native";
import Svg, { Circle, Defs, RadialGradient, Stop } from "react-native-svg";

function Blob({ id, color, size, opacity }: { id: string; color: string; size: number; opacity: number }) {
  return (
    <Svg width={size} height={size}>
      <Defs>
        <RadialGradient id={id} cx="50%" cy="50%" r="50%">
          <Stop offset="0" stopColor={color} stopOpacity={opacity} />
          <Stop offset="1" stopColor={color} stopOpacity={0} />
        </RadialGradient>
      </Defs>
      <Circle cx={size / 2} cy={size / 2} r={size / 2} fill={`url(#${id})`} />
    </Svg>
  );
}

/** Yavaşça süzülen renkli ışık küreleri ve hafifçe yanıp sönen yıldız tozu. */
export function ArzuBackdrop() {
  const drift = useRef(new Animated.Value(0)).current;
  const twinkle = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const driftLoop = Animated.loop(Animated.sequence([
      Animated.timing(drift, { toValue: 1, duration: 9000, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      Animated.timing(drift, { toValue: 0, duration: 9000, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
    ]));
    const twinkleLoop = Animated.loop(Animated.sequence([
      Animated.timing(twinkle, { toValue: 1, duration: 2600, useNativeDriver: true }),
      Animated.timing(twinkle, { toValue: 0, duration: 2600, useNativeDriver: true }),
    ]));
    driftLoop.start();
    twinkleLoop.start();
    return () => { driftLoop.stop(); twinkleLoop.stop(); };
  }, [drift, twinkle]);

  const { width, height } = Dimensions.get("window");
  const stars = useMemo(() => {
    let seed = 7;
    const rand = () => { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; };
    return Array.from({ length: 36 }, () => ({ x: rand() * width, y: rand() * height, r: 0.6 + rand() * 1.1, o: 0.2 + rand() * 0.5 }));
  }, [width, height]);

  const moveA = drift.interpolate({ inputRange: [0, 1], outputRange: [-18, 24] });
  const moveB = drift.interpolate({ inputRange: [0, 1], outputRange: [22, -28] });
  const starOpacity = twinkle.interpolate({ inputRange: [0, 1], outputRange: [0.35, 1] });

  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill}>
      <Animated.View style={[styles.blob, { top: -110, right: -110, transform: [{ translateX: moveA }, { translateY: moveB }] }]}>
        <Blob id="arzuGlowA" color="#7A5CFF" size={360} opacity={0.5} />
      </Animated.View>
      <Animated.View style={[styles.blob, { bottom: 80, left: -140, transform: [{ translateX: moveB }, { translateY: moveA }] }]}>
        <Blob id="arzuGlowB" color="#E0589E" size={320} opacity={0.28} />
      </Animated.View>
      <Animated.View style={[styles.blob, { top: height * 0.36, right: -120, transform: [{ translateY: moveB }] }]}>
        <Blob id="arzuGlowC" color="#2FC9B0" size={260} opacity={0.2} />
      </Animated.View>
      <Animated.View style={[StyleSheet.absoluteFill, { opacity: starOpacity }]}>
        <Svg width={width} height={height}>
          {stars.map((star, index) => <Circle key={index} cx={star.x} cy={star.y} r={star.r} fill="#FFFFFF" fillOpacity={star.o} />)}
        </Svg>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  blob: { position: "absolute" },
});
