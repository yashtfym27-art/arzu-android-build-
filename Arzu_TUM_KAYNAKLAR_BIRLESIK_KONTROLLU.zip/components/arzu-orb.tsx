import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useEffect, useRef } from "react";
import { Animated, Easing, Pressable, StyleSheet, View } from "react-native";
import Svg, { Circle, Defs, Ellipse, RadialGradient, Stop } from "react-native-svg";
import { ArzuWaveform } from "@/components/arzu-waveform";

type ArzuOrbProps = {
  active?: boolean;
  busy?: boolean;
  speaking?: boolean;
  onPress: () => void;
};

const PALETTES = {
  idle: { light: "#C9BCFF", mid: "#7A66F0", dark: "#4331B8", glow: "#7A66F0" },
  listening: { light: "#FFC2DC", mid: "#F0589A", dark: "#A3205F", glow: "#F0589A" },
  speaking: { light: "#B7F3E6", mid: "#2FC9B0", dark: "#117A68", glow: "#2FC9B0" },
  busy: { light: "#FFE2B5", mid: "#F2A650", dark: "#A8611A", glow: "#F2A650" },
};

function Ring({ delay, running, period }: { delay: number; running: boolean; period: number }) {
  const progress = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (!running) { progress.stopAnimation(); progress.setValue(0); return; }
    const loop = Animated.loop(Animated.sequence([
      Animated.delay(delay),
      Animated.timing(progress, { toValue: 1, duration: period, easing: Easing.out(Easing.quad), useNativeDriver: true }),
    ]));
    loop.start();
    return () => loop.stop();
  }, [delay, period, progress, running]);
  return (
    <Animated.View
      pointerEvents="none"
      style={[styles.ring, { opacity: progress.interpolate({ inputRange: [0, 1], outputRange: [0.5, 0] }), transform: [{ scale: progress.interpolate({ inputRange: [0, 1], outputRange: [1, 2.1] }) }] }]}
    />
  );
}

function Orbiter({ color, running, seconds, size, phase = 0 }: { color: string; running: boolean; seconds: number; size: number; phase?: number }) {
  const turn = useRef(new Animated.Value(phase)).current;
  useEffect(() => {
    if (!running) { turn.stopAnimation(); return; }
    const loop = Animated.loop(Animated.timing(turn, { toValue: phase + 1, duration: seconds * 1000, easing: Easing.linear, useNativeDriver: true }));
    loop.start();
    return () => loop.stop();
  }, [phase, running, seconds, turn]);
  return (
    <Animated.View pointerEvents="none" style={{ position: "absolute", width: 112, height: 112, alignItems: "center", opacity: running ? 1 : 0, transform: [{ rotate: turn.interpolate({ inputRange: [phase, phase + 1], outputRange: ["0deg", "360deg"] }) }] }}>
      <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: color, shadowColor: color, shadowOpacity: 0.9, shadowRadius: 6, elevation: 4 }} />
    </Animated.View>
  );
}

export function ArzuOrb({ active = false, busy = false, speaking = false, onPress }: ArzuOrbProps) {
  const breathe = useRef(new Animated.Value(0)).current;
  const state = active ? "listening" : speaking ? "speaking" : busy ? "busy" : "idle";
  const palette = PALETTES[state];
  const lively = active || speaking || busy;

  useEffect(() => {
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(breathe, { toValue: 1, duration: lively ? 700 : 2200, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      Animated.timing(breathe, { toValue: 0, duration: lively ? 700 : 2200, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
    ]));
    loop.start();
    return () => loop.stop();
  }, [breathe, lively]);

  const scale = breathe.interpolate({ inputRange: [0, 1], outputRange: [1, lively ? 1.09 : 1.04] });
  const glow = breathe.interpolate({ inputRange: [0, 1], outputRange: [0.35, 0.8] });
  const icon = speaking ? "graphic-eq" : active ? "mic" : busy ? "auto-awesome" : "mic-none";

  return (
    <Pressable accessibilityRole="button" accessibilityLabel="Arzu sesli konuşmayı başlat" onPress={onPress} style={({ pressed }) => [styles.pressable, pressed && styles.pressed]}>
      <View style={styles.stage}>
        <Ring delay={0} running={lively} period={1700} />
        <Ring delay={560} running={lively} period={1700} />
        <Ring delay={1120} running={lively} period={1700} />
        <Orbiter color={palette.light} running={lively} seconds={busy && !active && !speaking ? 1.6 : 3.2} size={7} />
        <Orbiter color="#FFFFFF" running={lively} seconds={4.8} size={4} phase={0.5} />
        <Animated.View pointerEvents="none" style={[styles.glow, { backgroundColor: palette.glow, opacity: glow, transform: [{ scale }] }]} />
        <Animated.View style={{ transform: [{ scale }] }}>
          <Svg width={84} height={84} viewBox="0 0 84 84">
            <Defs>
              <RadialGradient id={`orb-${state}`} cx="36%" cy="30%" r="75%">
                <Stop offset="0" stopColor={palette.light} />
                <Stop offset="0.55" stopColor={palette.mid} />
                <Stop offset="1" stopColor={palette.dark} />
              </RadialGradient>
            </Defs>
            <Circle cx="42" cy="42" r="40" fill={`url(#orb-${state})`} />
            <Ellipse cx="30" cy="23" rx="15" ry="8" fill="#FFFFFF" fillOpacity={0.28} />
          </Svg>
          <View style={styles.iconWrap}><MaterialIcons name={icon} size={34} color="#FFFFFF" /></View>
        </Animated.View>
      </View>
      <ArzuWaveform active={active || speaking} color={palette.light} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  pressable: { alignItems: "center", justifyContent: "center" },
  pressed: { opacity: 0.88, transform: [{ scale: 0.97 }] },
  stage: { width: 112, height: 112, alignItems: "center", justifyContent: "center" },
  ring: { position: "absolute", width: 84, height: 84, borderRadius: 42, borderWidth: 1.5, borderColor: "rgba(255,255,255,0.55)" },
  glow: { position: "absolute", width: 96, height: 96, borderRadius: 48 },
  iconWrap: { position: "absolute", top: 0, left: 0, right: 0, bottom: 0, alignItems: "center", justifyContent: "center" },
});
