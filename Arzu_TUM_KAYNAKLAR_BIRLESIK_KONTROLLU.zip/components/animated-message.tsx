import { type ReactNode, useEffect, useRef } from "react";
import { Animated, Easing } from "react-native";

/** Yeni mesaj yumuşakça yukarı kayıp belirir. */
export function AnimatedMessage({ children, fromUser }: { children: ReactNode; fromUser: boolean }) {
  const progress = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(progress, { toValue: 1, duration: 320, easing: Easing.out(Easing.cubic), useNativeDriver: true }).start();
  }, [progress]);
  return (
    <Animated.View
      style={{
        opacity: progress,
        transform: [
          { translateY: progress.interpolate({ inputRange: [0, 1], outputRange: [14, 0] }) },
          { translateX: progress.interpolate({ inputRange: [0, 1], outputRange: [fromUser ? 18 : -18, 0] }) },
          { scale: progress.interpolate({ inputRange: [0, 1], outputRange: [0.96, 1] }) },
        ],
      }}
    >
      {children}
    </Animated.View>
  );
}
