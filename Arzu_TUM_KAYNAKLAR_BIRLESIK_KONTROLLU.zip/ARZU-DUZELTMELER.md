# Arzu düzeltmeleri — nasıl uygulanır

Bu zip'teki dosyalar projedeki aynı yollara kopyalanır (üzerine yazılır). Yeni dosyalar: `server/local-render.ts`,
`server/assets/fonts/DejaVuSans-Bold.ttf`, `components/render-progress.tsx`, `components/arzu-waveform.tsx`, `tests/local-render.test.ts`.

**Native (Kotlin/XML/manifest) değiştiği için APK'yı yeniden derlemek gerekir.** Sunucu için yeniden başlatmak yeterli.

## Bilgisayarda (sunucu) yapılacaklar
1. **ffmpeg kur** (video/animasyon için): Windows `winget install ffmpeg` · macOS `brew install ffmpeg` · Linux `sudo apt install ffmpeg`.
   Sunucu açılırken "ffmpeg bulundu" yazmalı. API anahtarı gerekmez.
2. **Güvenlik duvarı (Windows):** `netsh advfirewall firewall add rule name="Arzu 3000" dir=in action=allow protocol=TCP localport=3000`
3. Sunucuyu başlat; konsolda telefona yazılacak `http://192.168.x.x:3000` adresleri listelenir.
4. İsteğe bağlı ortam değişkenleri: `ARZU_RENDER_SCALE=1` (1080p), `ARZU_RENDER_ENGINE=shotstack`, `ARZU_DATA_DIR`, `ARZU_FONT_FILE`, `FFMPEG_PATH`.
   Sesli anlatım için `ELEVENLABS_API_KEY` + `ELEVENLABS_VOICE_ID` hâlâ gerekir; yoksa video sessiz üretilir.

## Ne değişti
- **Video/animasyon:** ffmpeg ile bu bilgisayarda MP4 üretimi (Shotstack gerekmez). Sahne geçişleri, animasyonlu yazı, süzülen ışıklar,
  görsel varsa Ken Burns yakınlaştırma, ses varsa sahneler sese uydurulur. İlerleme çubuğu eklendi.
- **Dosyalar:** Manus Forge yoksa yüklemeler/üretilen dosyalar `.arzu-data/` klasörüne yazılır ve `/arzu-files/` ile servis edilir.
- **Wi‑Fi:** Doğru Wi‑Fi IP'si seçimi, Wi‑Fi'ye süreç bağlama (Wi‑Fi'de internet olmasa da yerel sunucuya ulaşır), hızlı/tek seferlik tarama
  (3000–3002 portları), bağlantı kopunca otomatik yeniden bulma + 1 kez tekrar deneme, istek zaman aşımları, 172.16–31.x desteği,
  ekran kapalıyken Wi‑Fi kilidi, Profil'de "Otomatik bul" düğmesi.
- **Uygulama kontrolü:** adım geçmişi sınırı çökmesi giderildi; ekran değişmezse durur; dokunma/kaydırma jest yedeği; uzun basma;
  bildirim paneli; Arzu kendi uygulamasını da yönetebilir ("Arzu uygulamasında ayarlara git…"); eksik görünümler için erişilebilirlik bayrakları.
- **Wake word:** kendi sesini duyma, hata döngüsü, sistem öldürünce geri gelmeme, çoklu tetikleme, çevrimdışı Türkçe paket yoksa döngü düzeltildi.
- **Arayüz:** orb'a dönen ışık noktaları ve ses dalgası çubukları, video ilerleme çubuğu, gereksiz sürekli sorgulama kaldırıldı.
- **Güvenlik:** CORS yalnızca yerel/özel ağ kökenleri.
- Son kontrolde bulunan ek düzeltmeler: "Merhaba Arzu" gibi kelimenin cümle sonunda geçtiği tetiklemeler algılanır, üst üste binen yeniden başlatmalar engellendi, `.arzu-data/` `.gitignore`'a eklendi.

## Yapılmayanlar / dikkat
- **Kotlin burada derlenemedi**; söz dizimi elle kontrol edildi. Derleme hatası olursa hata metnini gönder.
- Android 12+ mikrofon tipli servisi arka plandan başlatmayı kısıtlayabilir; artık çökmek yerine cihaz TTS'ine düşer. Cihazda test et.
- Reboot sonrası wake word kendiliğinden başlamaz; uygulamayı bir kez aç.
- Endpoint'ler hâlâ kimliksiz (aynı Wi‑Fi'deki herkes erişebilir). İstersen API anahtarı ekleriz.
- **`android/app/arzu-nova-release.keystore` ve şifresi (`build.gradle`) proje zip'inde düz duruyor.** Başkasıyla paylaşma.
- Şablondan kalan kullanılmayan dosyalar silinmedi: `components/hello-wave.tsx`, `parallax-scroll-view.tsx`, `external-link.tsx`, `collapsible.tsx`, `app/dev/theme-lab.tsx`.
