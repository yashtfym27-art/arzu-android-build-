import { spawn } from "node:child_process";
import fs from "node:fs/promises";
import { existsSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import { randomUUID } from "node:crypto";

import { LOCAL_FILES_ROUTE, localDataDir, localFilePath } from "./storage";

/**
 * Arzu yerel render motoru.
 * Sunucunun çalıştığı bilgisayardaki ffmpeg ile MP4 üretir: harici servis, API anahtarı veya
 * internetten erişilebilir adres gerekmez. Telefon dosyayı aynı Wi‑Fi üzerinden indirir.
 */

export type LocalEffect = "fade" | "slideLeft" | "slideRight" | "zoomIn" | "zoomOut";

export type LocalScene = {
  durationSeconds: number;
  text: string;
  subtext?: string;
  accent?: string;
  effect?: LocalEffect;
  /** İsteğe bağlı sahne görseli (sunucuya göre mutlak/göreli URL veya yerel dosya yolu). */
  imageUrl?: string;
};

export type LocalRenderInput = {
  title: string;
  width: number;
  height: number;
  fps?: number;
  background?: string;
  scenes: LocalScene[];
  /** Yerel dosya yolu veya URL. Varsa sahne süreleri sese göre uzatılır. */
  audioUrl?: string;
  brand?: string;
};

type JobStatus = "queued" | "processing" | "completed" | "failed";
type Job = { id: string; status: JobStatus; message: string; file?: string; startedAt: number; progress: number };

const jobs = new Map<string, Job>();
export const LOCAL_JOB_PREFIX = "local-";

let serverPort = Number(process.env.PORT || 3000);
export function setServerPort(port: number) { serverPort = port; }

// ---------------------------------------------------------------------------------------------
// ffmpeg bulma ve yetenek denetimi
// ---------------------------------------------------------------------------------------------

let ffmpegReady: boolean | null = null;
let ffmpegFilters = new Set<string>();
let ffmpegProblem = "";
const FFMPEG = process.env.FFMPEG_PATH || "ffmpeg";
const FFPROBE = process.env.FFPROBE_PATH || (process.env.FFMPEG_PATH ? path.join(path.dirname(process.env.FFMPEG_PATH), "ffprobe") : "ffprobe");

function run(cmd: string, args: string[], options: { cwd?: string; timeoutMs?: number } = {}) {
  return new Promise<{ code: number; stdout: string; stderr: string }>((resolve, reject) => {
    const child = spawn(cmd, args, { cwd: options.cwd, windowsHide: true });
    let stdout = "";
    let stderr = "";
    const timer = options.timeoutMs ? setTimeout(() => { child.kill("SIGKILL"); }, options.timeoutMs) : null;
    child.stdout.on("data", (chunk) => { stdout += chunk.toString(); if (stdout.length > 200_000) stdout = stdout.slice(-100_000); });
    child.stderr.on("data", (chunk) => { stderr += chunk.toString(); if (stderr.length > 200_000) stderr = stderr.slice(-100_000); });
    child.on("error", (error) => { if (timer) clearTimeout(timer); reject(error); });
    child.on("close", (code) => { if (timer) clearTimeout(timer); resolve({ code: code ?? -1, stdout, stderr }); });
  });
}

export async function detectLocalRender(): Promise<boolean> {
  try {
    const version = await run(FFMPEG, ["-hide_banner", "-version"], { timeoutMs: 15000 });
    if (version.code !== 0) throw new Error("ffmpeg çalışmadı");
    const filters = await run(FFMPEG, ["-hide_banner", "-filters"], { timeoutMs: 15000 });
    ffmpegFilters = new Set(filters.stdout.split("\n").map((line) => line.trim().split(/\s+/)[1]).filter(Boolean));
    const missing = ["drawtext", "overlay", "geq", "vignette"].filter((name) => !ffmpegFilters.has(name));
    if (missing.length) {
      ffmpegReady = false;
      ffmpegProblem = `ffmpeg bulundu ama şu filtreler eksik: ${missing.join(", ")}. Tam (full) ffmpeg sürümünü kur.`;
    } else {
      ffmpegReady = true;
      ffmpegProblem = "";
    }
  } catch {
    ffmpegReady = false;
    ffmpegProblem = "Bu bilgisayarda ffmpeg bulunamadı. Windows: winget install ffmpeg · macOS: brew install ffmpeg · Linux: sudo apt install ffmpeg";
  }
  return ffmpegReady;
}

export function localRenderReady() { return ffmpegReady === true; }
export function localRenderProblem() { return ffmpegProblem; }
void detectLocalRender();

// ---------------------------------------------------------------------------------------------
// Yardımcılar
// ---------------------------------------------------------------------------------------------

function fontCandidates() {
  // import.meta/__dirname kullanılmaz (tsx CJS ve esbuild ESM çıktısında ortak çalışsın diye).
  const entry = process.argv[1] ? path.dirname(path.resolve(process.argv[1])) : process.cwd();
  return [
    process.env.ARZU_FONT_FILE || "",
    path.join(process.cwd(), "server/assets/fonts/DejaVuSans-Bold.ttf"),
    path.join(entry, "assets/fonts/DejaVuSans-Bold.ttf"),
    path.join(entry, "../server/assets/fonts/DejaVuSans-Bold.ttf"),
    path.join(entry, "../../server/assets/fonts/DejaVuSans-Bold.ttf"),
    "C:/Windows/Fonts/arialbd.ttf",
    "C:/Windows/Fonts/segoeuib.ttf",
    "/Library/Fonts/Arial Bold.ttf",
    "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
  ].filter(Boolean);
}

function findFont() {
  return fontCandidates().find((candidate) => { try { return existsSync(candidate); } catch { return false; } }) || "";
}

function hexToRgb(hex: string, fallback: [number, number, number] = [184, 172, 255]): [number, number, number] {
  const match = /^#?([0-9a-fA-F]{6})$/.exec(hex || "");
  if (!match) return fallback;
  const value = parseInt(match[1], 16);
  return [(value >> 16) & 255, (value >> 8) & 255, value & 255];
}

function toFfHex(rgb: [number, number, number]) {
  return `0x${rgb.map((part) => Math.max(0, Math.min(255, Math.round(part))).toString(16).padStart(2, "0")).join("")}`;
}

function mix(a: [number, number, number], b: [number, number, number], amount: number): [number, number, number] {
  return [a[0] + (b[0] - a[0]) * amount, a[1] + (b[1] - a[1]) * amount, a[2] + (b[2] - a[2]) * amount];
}

function even(value: number) { const rounded = Math.round(value); return rounded % 2 === 0 ? rounded : rounded + 1; }

/** drawtext satır sonu bilmediği için metni karakter genişliği tahminiyle böler. */
export function wrapText(text: string, maxChars: number, maxLines = 6): string {
  const words = text.replace(/\s+/g, " ").trim().split(" ").filter(Boolean);
  const lines: string[] = [];
  let current = "";
  for (const word of words) {
    const candidate = current ? `${current} ${word}` : word;
    if (candidate.length > maxChars && current) { lines.push(current); current = word; } else { current = candidate; }
  }
  if (current) lines.push(current);
  if (lines.length > maxLines) {
    const kept = lines.slice(0, maxLines);
    kept[maxLines - 1] = `${kept[maxLines - 1].slice(0, Math.max(1, maxChars - 1))}…`;
    return kept.join("\n");
  }
  return lines.join("\n");
}

async function fetchToFile(source: string, destination: string): Promise<boolean> {
  try {
    if (source.startsWith(LOCAL_FILES_ROUTE + "/")) {
      await fs.copyFile(localFilePath(source.slice(LOCAL_FILES_ROUTE.length + 1)), destination);
      return true;
    }
    if (path.isAbsolute(source) && existsSync(source)) { await fs.copyFile(source, destination); return true; }
    const url = source.startsWith("/") ? `http://127.0.0.1:${serverPort}${source}` : source;
    const response = await fetch(url, { redirect: "follow" });
    if (!response.ok) return false;
    await fs.writeFile(destination, Buffer.from(await response.arrayBuffer()));
    return true;
  } catch {
    return false;
  }
}

async function probeDuration(file: string): Promise<number> {
  try {
    const result = await run(FFPROBE, ["-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", file], { timeoutMs: 20000 });
    const value = parseFloat(result.stdout.trim());
    return Number.isFinite(value) ? value : 0;
  } catch { return 0; }
}

// ---------------------------------------------------------------------------------------------
// Sahne üretimi
// ---------------------------------------------------------------------------------------------

type PreparedScene = LocalScene & { index: number; duration: number; imageFile?: string };

function escapeFilterPath(value: string) { return value.replace(/\\/g, "/").replace(/:/g, "\\:").replace(/'/g, "\\'"); }

async function makeSprite(workDir: string, name: string, rgb: [number, number, number]) {
  const file = path.join(workDir, `${name}.png`);
  const [r, g, b] = rgb.map((part) => Math.round(part));
  const expr = `nullsrc=s=320x320,format=rgba,geq=r=${r}:g=${g}:b=${b}:a='255*pow(max(0\\,1-hypot(X-160\\,Y-160)/160)\\,2)*0.85'`;
  const result = await run(FFMPEG, ["-y", "-hide_banner", "-loglevel", "error", "-f", "lavfi", "-i", expr, "-frames:v", "1", file], { cwd: workDir, timeoutMs: 30000 });
  if (result.code !== 0) throw new Error(`Işık küresi hazırlanamadı: ${result.stderr.slice(-300)}`);
  return `${name}.png`;
}

async function renderSceneClip(options: {
  workDir: string; scene: PreparedScene; width: number; height: number; fps: number; background: [number, number, number];
  fontFile: string; sprites: Record<string, string>; brand: string; total: number; outFile: string;
}) {
  const { workDir, scene, width, height, fps, background, outFile } = options;
  const accent = hexToRgb(scene.accent || "#B8ACFF");
  const dur = scene.duration;
  const portrait = height >= width;
  const base = Math.min(width, height);
  const mainSize = even(base * (portrait ? 0.082 : 0.085));
  const subSize = even(base * (portrait ? 0.044 : 0.045));
  const maxChars = Math.max(8, Math.floor((width * 0.84) / (mainSize * 0.6)));
  const subChars = Math.max(10, Math.floor((width * 0.84) / (subSize * 0.58)));
  const mainText = wrapText(scene.text || "Arzu", maxChars, 5);
  const subText = scene.subtext ? wrapText(scene.subtext, subChars, 4) : "";
  const mainLines = mainText.split("\n").length;
  const subLines = subText ? subText.split("\n").length : 0;
  const mainH = mainLines * mainSize * 1.28;
  const subH = subLines * subSize * 1.3;
  const blockH = mainH + (subText ? subSize * 0.9 + subH : 0);
  const mainY = Math.round(height * 0.46 - blockH / 2);
  const lineY = Math.round(mainY + mainH + subSize * 0.25);
  const subY = Math.round(lineY + subSize * 0.7);

  const font = `fontfile=font.ttf`;
  const fadeIn = 0.55;
  const fadeOut = Math.min(0.45, dur * 0.2);
  const alpha = `if(lt(t\\,${fadeIn})\\,t/${fadeIn}\\,if(gt(t\\,${(dur - fadeOut).toFixed(3)})\\,max(0\\,(${dur.toFixed(3)}-t)/${fadeOut.toFixed(3)})\\,1))`;
  const subAlpha = `if(lt(t\\,${fadeIn + 0.25})\\,max(0\\,(t-0.25)/${fadeIn})\\,if(gt(t\\,${(dur - fadeOut).toFixed(3)})\\,max(0\\,(${dur.toFixed(3)}-t)/${fadeOut.toFixed(3)})\\,1))`;
  const ease = (span: number) => `pow(1-min(t/${span}\\,1)\\,3)`;
  const effect = scene.effect || "fade";
  let mainX = "(w-text_w)/2";
  let mainFont = `fontsize=${mainSize}`;
  if (effect === "slideLeft") mainX = `(w-text_w)/2+${ease(0.8)}*${Math.round(width * 0.22)}`;
  if (effect === "slideRight") mainX = `(w-text_w)/2-${ease(0.8)}*${Math.round(width * 0.22)}`;
  if (effect === "zoomIn") mainFont = `fontsize='${mainSize}*(0.9+0.14*min(t/${Math.max(0.8, dur).toFixed(2)}\\,1))'`;
  if (effect === "zoomOut") mainFont = `fontsize='${mainSize}*(1.08-0.1*min(t/${Math.max(0.8, dur).toFixed(2)}\\,1))'`;
  const shadow = `shadowcolor=black@0.55:shadowx=3:shadowy=4`;

  const inputs: string[] = [];
  const graph: string[] = [];
  let last: string;

  if (scene.imageFile) {
    inputs.push("-loop", "1", "-framerate", String(fps), "-t", dur.toFixed(3), "-i", scene.imageFile);
    const frames = Math.max(2, Math.round(dur * fps));
    const zoomExpr = effect === "zoomOut" ? `max(1.0\\,1.25-0.25*on/${frames})` : `min(1.25\\,1.0+0.25*on/${frames})`;
    const panX = effect === "slideLeft" ? `(iw-iw/zoom)*on/${frames}` : effect === "slideRight" ? `(iw-iw/zoom)*(1-on/${frames})` : `iw/2-(iw/zoom/2)`;
    graph.push(`[0:v]scale=${width * 2}:${height * 2}:force_original_aspect_ratio=increase,crop=${width * 2}:${height * 2},zoompan=z='${zoomExpr}':x='${panX}':y='ih/2-(ih/zoom/2)':d=1:s=${width}x${height}:fps=${fps},format=yuv420p[bg0]`);
    graph.push(`[bg0]drawbox=x=0:y=0:w=iw:h=ih:color=black@0.34:t=fill[bg]`);
    last = "bg";
  } else {
    graph.push(`color=c=${toFfHex(mix(background, accent, 0.08))}:s=${width}x${height}:r=${fps}:d=${dur.toFixed(3)},format=yuv420p[bg0]`);
    // iki yavaş süzülen ışık küresi
    inputs.push("-loop", "1", "-framerate", String(fps), "-t", dur.toFixed(3), "-i", options.sprites.accent);
    inputs.push("-loop", "1", "-framerate", String(fps), "-t", dur.toFixed(3), "-i", options.sprites.cool);
    const sizeA = even(width * 1.15);
    const sizeB = even(width * 0.9);
    graph.push(`[0:v]scale=${sizeA}:${sizeA},format=rgba[o1]`);
    graph.push(`[1:v]scale=${sizeB}:${sizeB},format=rgba[o2]`);
    graph.push(`[bg0][o1]overlay=x='(W-w)*(0.5+0.42*sin(t*0.55+${scene.index}))':y='(H-h)*(0.32+0.28*cos(t*0.42+${scene.index}))':format=auto[bg1]`);
    graph.push(`[bg1][o2]overlay=x='(W-w)*(0.5+0.4*cos(t*0.47+${scene.index * 2}))':y='(H-h)*(0.68+0.26*sin(t*0.38+${scene.index}))':format=auto[bg2]`);
    graph.push(`[bg2]vignette=angle=0.55:eval=init[bg]`);
    last = "bg";
  }

  // Üst bilgi çizgisi, ana metin, alt metin, vurgu çizgisi, marka
  const lineW = Math.round(width * 0.18);
  const chain: string[] = [];
  const pending: Promise<unknown>[] = [];
  mainText.split("\n").forEach((line, lineIndex) => {
    const file = `main${scene.index}-${lineIndex}.txt`;
    pending.push(fs.writeFile(path.join(workDir, file), line, "utf8"));
    chain.push(`drawtext=${font}:textfile=${file}:${mainFont}:fontcolor=white:x='${mainX}':y=${Math.round(mainY + lineIndex * mainSize * 1.28)}:alpha='${alpha}':${shadow}`);
  });
  subText.split("\n").filter(Boolean).forEach((line, lineIndex) => {
    const file = `sub${scene.index}-${lineIndex}.txt`;
    pending.push(fs.writeFile(path.join(workDir, file), line, "utf8"));
    chain.push(`drawtext=${font}:textfile=${file}:fontsize=${subSize}:fontcolor=${toFfHex(mix(accent, [255, 255, 255], 0.35))}:x=(w-text_w)/2:y=${Math.round(subY + lineIndex * subSize * 1.3)}:alpha='${subAlpha}':${shadow}`);
  });
  await Promise.all(pending);
  chain.push(`drawbox=x=${Math.round((width - lineW) / 2)}:y=${lineY}:w=${lineW}:h=${Math.max(4, Math.round(base * 0.007))}:color=${toFfHex(accent)}@0.95:t=fill:enable='between(t\\,0.4\\,${(dur - fadeOut).toFixed(3)})'`);
  if (options.brand) {
    await fs.writeFile(path.join(workDir, "brand.txt"), options.brand, "utf8");
    chain.push(`drawtext=${font}:textfile=brand.txt:fontsize=${even(base * 0.03)}:fontcolor=white@0.55:x=(w-text_w)/2:y=h-${even(base * 0.09)}`);
  }
  chain.push(`format=yuv420p`);
  graph.push(`[${last}]${chain.join(",")}[v]`);

  const args = ["-y", "-hide_banner", "-loglevel", "error", ...inputs, "-filter_complex", graph.join(";"), "-map", "[v]", "-t", dur.toFixed(3), "-r", String(fps),
    "-c:v", "libx264", "-preset", "veryfast", "-crf", "21", "-pix_fmt", "yuv420p", "-an", outFile];
  const result = await run(FFMPEG, args, { cwd: workDir, timeoutMs: 8 * 60_000 });
  if (result.code !== 0) throw new Error(`Sahne ${scene.index} üretilemedi: ${result.stderr.slice(-500)}`);
}

// ---------------------------------------------------------------------------------------------
// Ana akış
// ---------------------------------------------------------------------------------------------

async function runRender(job: Job, input: LocalRenderInput) {
  const fps = input.fps ?? 30;
  const scale = Number(process.env.ARZU_RENDER_SCALE || 2 / 3);
  const width = even(input.width * scale);
  const height = even(input.height * scale);
  const background = hexToRgb(input.background || "#14121D", [20, 18, 29]);
  const workDir = await fs.mkdtemp(path.join(os.tmpdir(), "arzu-render-"));
  try {
    job.status = "processing";
    job.message = "Hazırlanıyor…";
    const fontSource = findFont();
    if (!fontSource) throw new Error("Yazı tipi bulunamadı. server/assets/fonts/DejaVuSans-Bold.ttf dosyasını koru veya ARZU_FONT_FILE ayarla.");
    await fs.copyFile(fontSource, path.join(workDir, "font.ttf"));

    // Ses varsa indir ve süreyi ölç; sahneler sese uyacak şekilde uzatılır.
    let audioFile = "";
    let audioDuration = 0;
    if (input.audioUrl) {
      const target = path.join(workDir, "voice.mp3");
      if (await fetchToFile(input.audioUrl, target)) { audioFile = target; audioDuration = await probeDuration(target); }
    }

    const transition = Math.min(0.5, Math.max(0.2, Math.min(...input.scenes.map((scene) => scene.durationSeconds)) * 0.25));
    const useXfade = ffmpegFilters.has("xfade") && input.scenes.length > 1;
    const overlap = useXfade ? transition : 0;
    const planned = input.scenes.reduce((sum, scene) => sum + scene.durationSeconds, 0) - overlap * (input.scenes.length - 1);
    const stretch = audioDuration > planned ? Math.min(3, (audioDuration + 0.6 + overlap * (input.scenes.length - 1)) / (planned + overlap * (input.scenes.length - 1))) : 1;

    const scenes: PreparedScene[] = [];
    for (let i = 0; i < input.scenes.length; i += 1) {
      const scene = input.scenes[i];
      let imageFile: string | undefined;
      if (scene.imageUrl) {
        const target = path.join(workDir, `img${i + 1}.jpg`);
        if (await fetchToFile(scene.imageUrl, target)) imageFile = path.basename(target);
      }
      scenes.push({ ...scene, index: i + 1, duration: Math.max(1.5, scene.durationSeconds * stretch), imageFile });
    }

    const sprites = {
      accent: await makeSprite(workDir, "sprite-accent", mix([120, 90, 255], hexToRgb(scenes[0].accent || "#B8ACFF"), 0.5)),
      cool: await makeSprite(workDir, "sprite-cool", [47, 201, 176]),
    };

    const clips: string[] = [];
    for (const scene of scenes) {
      job.message = `Sahne ${scene.index}/${scenes.length} hazırlanıyor…`;
      job.progress = Math.round((scene.index - 1) / (scenes.length + 1) * 100);
      const clip = `clip${scene.index}.mp4`;
      await renderSceneClip({ workDir, scene, width, height, fps, background, fontFile: "font.ttf", sprites: scene.imageFile ? { accent: "", cool: "" } : sprites, brand: input.brand ?? "ARZU", total: scenes.length, outFile: clip });
      clips.push(clip);
    }

    job.message = "Sahneler birleştiriliyor…";
    job.progress = Math.round(scenes.length / (scenes.length + 1) * 100);
    const outDir = path.join(localDataDir(), "renders");
    await fs.mkdir(outDir, { recursive: true });
    const outName = `${job.id.replace(LOCAL_JOB_PREFIX, "")}.mp4`;
    const outPath = path.join(outDir, outName);
    
    if (useXfade && clips.length > 1) {
      const inputs = [...clips.flatMap((clip) => ["-i", clip]), ...(audioFile ? ["-i", audioFile] : [])];
      const filters: string[] = [];
      let previous = "0:v";
      let elapsed = scenes[0].duration;
      for (let i = 1; i < clips.length; i += 1) {
        const name = scenes[i].effect === "slideLeft" ? "slideleft" : scenes[i].effect === "slideRight" ? "slideright" : "fade";
        const offset = Math.max(0, elapsed - transition);
        const label = i === clips.length - 1 ? "vout" : `x${i}`;
        filters.push(`[${previous}][${i}:v]xfade=transition=${name}:duration=${transition.toFixed(3)}:offset=${offset.toFixed(3)}[${label}]`);
        previous = label;
        elapsed = elapsed + scenes[i].duration - transition;
      }
      const mapAudio = audioFile ? ["-map", `${clips.length}:a`, "-c:a", "aac", "-b:a", "160k", "-shortest"] : ["-an"];
      const result = await run(FFMPEG, ["-y", "-hide_banner", "-loglevel", "error", ...inputs, "-filter_complex", filters.join(";"), "-map", "[vout]", ...mapAudio,
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "21", "-pix_fmt", "yuv420p", "-movflags", "+faststart", outPath], { cwd: workDir, timeoutMs: 15 * 60_000 });
      if (result.code !== 0) throw new Error(`Birleştirme başarısız: ${result.stderr.slice(-500)}`);
    } else {
      await fs.writeFile(path.join(workDir, "list.txt"), clips.map((clip) => `file '${clip}'`).join("\n"), "utf8");
      const concatArgs = ["-y", "-hide_banner", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", "list.txt"];
      if (audioFile) concatArgs.push("-i", audioFile, "-map", "0:v", "-map", "1:a", "-c:v", "copy", "-c:a", "aac", "-b:a", "160k", "-shortest");
      else concatArgs.push("-map", "0:v", "-c:v", "copy", "-an");
      concatArgs.push("-movflags", "+faststart", outPath);
      const result = await run(FFMPEG, concatArgs, { cwd: workDir, timeoutMs: 10 * 60_000 });
      if (result.code !== 0) throw new Error(`Birleştirme başarısız: ${result.stderr.slice(-500)}`);
    }

    job.file = outPath;
    job.status = "completed";
    job.progress = 100;
    job.message = "MP4 hazır.";
  } catch (error) {
    job.status = "failed";
    job.message = `Video üretilemedi: ${error instanceof Error ? error.message.slice(0, 400) : "bilinmeyen hata"}`;
    console.error("[local-render]", job.message);
  } finally {
    void fs.rm(workDir, { recursive: true, force: true }).catch(() => undefined);
  }
}

export function startLocalRender(input: LocalRenderInput): { jobId: string } {
  const id = `${LOCAL_JOB_PREFIX}${randomUUID().replace(/-/g, "").slice(0, 20)}`;
  const job: Job = { id, status: "queued", message: "Sırada…", startedAt: Date.now(), progress: 0 };
  jobs.set(id, job);
  // Eski kayıtlar bellekte birikmesin.
  for (const [key, value] of jobs) if (Date.now() - value.startedAt > 6 * 3600_000) jobs.delete(key);
  void runRender(job, input);
  return { jobId: id };
}

export async function getLocalRenderStatus(jobId: string, publicBaseUrl = ""): Promise<{ status: "queued" | "completed" | "failed"; url?: string; message: string; progress?: number }> {
  const job = jobs.get(jobId);
  const urlFor = (name: string) => `${publicBaseUrl.replace(/\/$/, "")}${LOCAL_FILES_ROUTE}/renders/${name}`;
  if (job) {
    if (job.status === "completed" && job.file) return { status: "completed", url: urlFor(path.basename(job.file)), message: "MP4 hazır.", progress: 100 };
    if (job.status === "failed") return { status: "failed", message: job.message };
    return { status: "queued", message: job.message, progress: job.progress };
  }
  // Sunucu yeniden başladıysa dosya diskte duruyor olabilir.
  const name = `${jobId.replace(LOCAL_JOB_PREFIX, "")}.mp4`;
  if (/^[a-z0-9]+\.mp4$/i.test(name) && existsSync(path.join(localDataDir(), "renders", name))) return { status: "completed", url: urlFor(name), message: "MP4 hazır." };
  return { status: "failed", message: "Bu render işi bulunamadı (sunucu yeniden başlatılmış olabilir)." };
}
