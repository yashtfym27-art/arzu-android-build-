import { storagePut } from "./storage";

const DEFAULT_MODEL = "eleven_multilingual_v2";

export async function synthesizeArzuSpeech(text: string) {
  const key = process.env.ELEVENLABS_API_KEY;
  const voiceId = process.env.ELEVENLABS_VOICE_ID;
  if (!key || !voiceId) {
    throw new Error("Doğal seslendirme yapılandırılmamış: ELEVENLABS_API_KEY ve ELEVENLABS_VOICE_ID gerekli.");
  }

  const cleanText = text.trim().slice(0, 5000);
  if (!cleanText) throw new Error("Seslendirilecek metin boş.");

  const modelId = process.env.ELEVENLABS_MODEL_ID || DEFAULT_MODEL;
  const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(voiceId)}`, {
    method: "POST",
    headers: {
      accept: "audio/mpeg",
      "content-type": "application/json",
      "xi-api-key": key,
    },
    body: JSON.stringify({
      text: cleanText,
      model_id: modelId,
      // language_code yalnızca eleven_turbo_v2_5 / eleven_flash_v2_5 modellerinde desteklenir.
      // eleven_multilingual_v2 ile gönderilirse ElevenLabs isteği reddeder.
      ...(/(turbo|flash)_v2_5/.test(modelId) ? { language_code: "tr" } : {}),
      output_format: "mp3_44100_128",
      voice_settings: {
        stability: 0.44,
        similarity_boost: 0.8,
        style: 0.24,
        use_speaker_boost: true,
      },
    }),
  });

  if (!response.ok) {
    if (response.status === 402) throw new Error("ElevenLabs ses üretimi şu anda kullanım yetkisi veya hesap limiti nedeniyle reddedildi.");
    const body = await response.text().catch(() => "");
    console.error(`[ElevenLabs] ${response.status} ${body.slice(0, 500)}`);
    if (response.status === 401) throw new Error("ElevenLabs API anahtarı geçersiz veya iptal edilmiş (401).");
    if (response.status === 404) throw new Error("ElevenLabs ses ID'si bulunamadı (404). ELEVENLABS_VOICE_ID değerini kontrol et.");
    throw new Error(`ElevenLabs ses üretimi başarısız (${response.status}): ${body.slice(0, 160)}`);
  }

  const audio = Buffer.from(await response.arrayBuffer());
  if (audio.length < 1000) throw new Error("ElevenLabs geçerli bir MP3 döndürmedi.");
  const stored = await storagePut(`arzu-private/speech/${crypto.randomUUID()}.mp3`, audio, "audio/mpeg");
  return { audioUrl: stored.url, voiceId };
}
