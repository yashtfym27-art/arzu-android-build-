import { z } from "zod";

import { invokeLLM } from "./_core/llm";
import { ENV } from "./_core/env";
import { generateImage } from "./_core/imageGeneration";
import { storagePut } from "./storage";
import { LOCAL_JOB_PREFIX, getLocalRenderStatus, localRenderProblem, localRenderReady, startLocalRender } from "./local-render";

export const mediaPlatforms = ["youtube", "reels", "tiktok", "shorts"] as const;
export type MediaPlatform = (typeof mediaPlatforms)[number];

const formatMap: Record<MediaPlatform, { label: string; aspectRatio: "9:16" | "16:9"; width: number; height: number; maxDuration: number }> = {
  youtube: { label: "YouTube", aspectRatio: "16:9", width: 1920, height: 1080, maxDuration: 900 },
  reels: { label: "Instagram Reels", aspectRatio: "9:16", width: 1080, height: 1920, maxDuration: 90 },
  tiktok: { label: "TikTok", aspectRatio: "9:16", width: 1080, height: 1920, maxDuration: 600 },
  shorts: { label: "YouTube Shorts", aspectRatio: "9:16", width: 1080, height: 1920, maxDuration: 180 },
};

const sceneSchema = z.object({
  index: z.number().int().min(1).max(12),
  durationSeconds: z.number().min(1).max(30),
  visualPrompt: z.string().min(5).max(1200),
  narration: z.string().min(1).max(1200),
  onScreenText: z.string().max(240).default(""),
});

const planSchema = z.object({
  title: z.string().min(1).max(160),
  platform: z.enum(mediaPlatforms),
  durationSeconds: z.number().int().min(3).max(900),
  hook: z.string().min(1).max(500),
  callToAction: z.string().max(300),
  voiceStyle: z.string().max(300),
  scenes: z.array(sceneSchema).min(1).max(12),
});

export type MediaPlan = z.infer<typeof planSchema> & {
  aspectRatio: "9:16" | "16:9";
  formatLabel: string;
};

export type MediaCapabilities = {
  planner: { available: true; note: string };
  images: { available: boolean; note: string };
  voiceover: { available: boolean; note: string };
  videoRender: { available: boolean; note: string };
  subtitles: { available: true; note: string };
  publishing: { available: false; note: string };
};

export type MediaJobResult = {
  status: "queued" | "completed" | "needs_configuration" | "failed";
  plan: MediaPlan;
  assets: Array<{ type: "image" | "voiceover" | "subtitles" | "video"; url: string; note?: string }>;
  message: string;
  renderJobId?: string;
};

function contentText(content: string | Array<{ type: string; text?: string }>): string {
  return typeof content === "string" ? content : content.map((part) => part.text ?? "").join("\n");
}

function parseJson<T>(value: string): T {
  const cleaned = value.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "").trim();
  try {
    return JSON.parse(cleaned) as T;
  } catch (firstError) {
    // Bazı LLM yanıtları kısa bir açıklama veya code fence ekleyebilir.
    // İlk ve son JSON nesnesini seçip bir kez daha ayrıştırmayı dene.
    const start = cleaned.indexOf("{");
    const end = cleaned.lastIndexOf("}");
    if (start >= 0 && end > start) {
      try {
        return JSON.parse(cleaned.slice(start, end + 1)) as T;
      } catch {
        // Aşağıdaki hata, üst katmanda kullanıcıya anlaşılır biçimde raporlanır.
      }
    }
    throw firstError;
  }
}

function shotstackConfig() {
  const sandbox = process.env.SHOTSTACK_ENV === "sandbox";
  return {
    sandbox,
    key: sandbox ? process.env.SHOTSTACK_SANDBOX_API_KEY : process.env.SHOTSTACK_API_KEY,
    baseUrl: sandbox ? "https://api.shotstack.io/edit/stage" : "https://api.shotstack.io/edit/v1",
  };
}

export type RenderEngine = "local" | "shotstack" | "none";

/** Varsayılan: bu bilgisayardaki ffmpeg (anahtar ve internetten erişilebilir adres gerektirmez). */
export function pickRenderEngine(): RenderEngine {
  const hasShotstack = Boolean(shotstackConfig().key);
  const forced = (process.env.ARZU_RENDER_ENGINE || "").toLowerCase();
  if (forced === "shotstack") return hasShotstack ? "shotstack" : localRenderReady() ? "local" : "none";
  if (forced === "local") return localRenderReady() ? "local" : hasShotstack ? "shotstack" : "none";
  if (localRenderReady()) return "local";
  return hasShotstack ? "shotstack" : "none";
}

export function getMediaCapabilities(): MediaCapabilities {
  const hasImage = Boolean(ENV.forgeApiUrl && ENV.forgeApiKey);
  const hasVoice = Boolean(process.env.ELEVENLABS_API_KEY && process.env.ELEVENLABS_VOICE_ID);
  const shotstack = shotstackConfig();
  const engine = pickRenderEngine();
  const hasVideo = engine !== "none";
  return {
    planner: { available: true, note: "Arzu sunucu tarafındaki yerleşik LLM ile gerçek plan üretir." },
    images: { available: hasImage, note: hasImage ? "Yerleşik Forge ImageService ile gerçek görsel üretimi kullanılabilir." : "BUILT_IN_FORGE_API_URL ve BUILT_IN_FORGE_API_KEY yapılandırılmalı." },
    voiceover: { available: hasVoice, note: hasVoice ? "Sunucu tarafı ElevenLabs adaptörü etkin." : "ELEVENLABS_API_KEY ve ELEVENLABS_VOICE_ID gerekli; cihaz TTS yalnızca önizleme içindir." },
    videoRender: { available: hasVideo, note: engine === "local" ? "Bu bilgisayardaki ffmpeg ile yerel MP4 render etkin (API anahtarı gerekmez)." : engine === "shotstack" ? `Shotstack ${shotstack.sandbox ? "sandbox" : "üretim"} render adaptörü etkin; MP4 sonucu asenkron sorgulanır.` : (localRenderProblem() || "Gerçek MP4 için sunucu bilgisayarına ffmpeg kur veya SHOTSTACK_API_KEY ekle.") },
    subtitles: { available: true, note: "SRT altyazı dosyası deterministik olarak üretilir." },
    publishing: { available: false, note: "YouTube/Instagram/TikTok yayınlama bu sürümde otomatik yapılmaz; hesap OAuth ve platform onayı gerektirir." },
  };
}

function normalizePlan(raw: z.infer<typeof planSchema>, requestedPlatform: MediaPlatform): MediaPlan {
  const platform = raw.platform || requestedPlatform;
  const format = formatMap[platform];
  const duration = Math.min(raw.durationSeconds, format.maxDuration);
  const scenes = raw.scenes.map((scene, index) => ({ ...scene, index: index + 1 })).slice(0, 12);
  return { ...raw, platform, durationSeconds: duration, scenes, aspectRatio: format.aspectRatio, formatLabel: format.label };
}

function offlineMediaPlan(prompt: string, platform: MediaPlatform): MediaPlan {
  const format = formatMap[platform];
  const durationSeconds = Math.min(format.maxDuration, 15);
  const sceneDuration = durationSeconds / 5;
  const topic = prompt.replace(/^.*?(video|reels|tiktok|shorts|youtube)\s*/i, "").trim().slice(0, 120) || "Arzu kişisel yapay zekâ asistanı";
  const scenes = [
    ["Güçlü açılış", "Modern telefon arayüzü, yumuşak mor ve turkuaz ışıklar, dinamik yakın plan, premium teknoloji reklamı", "Hayatını daha akıllı yönet.", "Arzu yanında."],
    ["Günlük destek", "Kullanıcı telefonda üretkenlik asistanıyla konuşuyor, sıcak ev ışığı, modern ve gerçekçi reklam görseli", "Sor, planla, harekete geç.", "Tek komutla daha fazlası."],
    ["Sesli kontrol", "Eller serbest sesli asistan kullanımı, hareketli gün içinde telefon, sinematik dikey kompozisyon", "Konuş. Arzu anlasın.", "Sesli kontrol."],
    ["Üretkenlik", "Dijital görevler, takvim ve yaratıcı içerik akışı, neon veri çizgileri, temiz teknoloji estetiği", "Fikirden sonuca daha hızlı.", "Zamanını geri kazan."],
    ["Kapanış", "Parlayan Arzu orb logosu, koyu mor arka plan, premium ürün kapanış karesi, dikey sosyal medya reklamı", "Arzu'yu şimdi dene.", "Kişisel AI asistanın."],
  ].map(([_, visualPrompt, narration, onScreenText], index) => ({ index: index + 1, durationSeconds: sceneDuration, visualPrompt: `${visualPrompt}. Tema: ${topic}`, narration, onScreenText }));
  return normalizePlan({ title: `${format.label} için Arzu videosu`, platform, durationSeconds, hook: "Hayatını daha akıllı yönet.", callToAction: "Arzu'yu şimdi dene.", voiceStyle: "Samimi, modern ve güven veren Türkçe anlatım", scenes }, platform);
}

export async function planMediaRequest(prompt: string, platform: MediaPlatform = "reels"): Promise<MediaPlan> {
  const format = formatMap[platform];
  try {
    const response = await invokeLLM({
    model: "gpt-5-mini",
    // 6–8 sahneli planlar 2600 token sınırında kesilebildiği için
    // JSON'un ortasında kalan "Unterminated string" hatasını önle.
    maxTokens: 5000,
    messages: [
      {
        role: "system",
        content: `Sen Arzu'nun içerik yönetmenisin. Türkçe üretim planı oluştur. Kullanıcının doğal komutunu; kanca, kısa senaryo, sahne görselleri, seslendirme metni, ekranda yazı ve CTA'ya böl. JSON dışında hiçbir şey yazma. Hedef platform ${format.label}; oran ${format.aspectRatio}; üst süre ${format.maxDuration} saniye. Her sahne görsel üretim aracına verilebilecek İngilizce visualPrompt ve Türkçe narration içermeli. Görsel promptlarına yazı ekleme; onScreenText ayrı alanda olsun.`,
      },
      { role: "user", content: `İstek: ${prompt}\nVarsayılan platform: ${format.label}` },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "arzu_media_plan",
        strict: true,
        schema: {
          type: "object",
          additionalProperties: false,
          required: ["title", "platform", "durationSeconds", "hook", "callToAction", "voiceStyle", "scenes"],
          properties: {
            title: { type: "string" },
            platform: { type: "string", enum: mediaPlatforms },
            durationSeconds: { type: "number" },
            hook: { type: "string" },
            callToAction: { type: "string" },
            voiceStyle: { type: "string" },
            scenes: { type: "array", minItems: 1, maxItems: 12, items: { type: "object", additionalProperties: false, required: ["index", "durationSeconds", "visualPrompt", "narration", "onScreenText"], properties: { index: { type: "integer" }, durationSeconds: { type: "number" }, visualPrompt: { type: "string" }, narration: { type: "string" }, onScreenText: { type: "string" } } } },
          },
        },
      },
    } as any,
    });
    const parsed = planSchema.parse(parseJson(contentText(response.choices[0]?.message.content ?? "{}")));
    return normalizePlan(parsed, platform);
  } catch (error) {
    const detail = error instanceof Error ? error.message : String(error);
    if (/usage exhausted|quota|precondition|429|rate limit/i.test(detail)) {
      console.warn("[media] planlama LLM kullanılamıyor; yerel şablon plan kullanılıyor:", detail.slice(0, 240));
      return offlineMediaPlan(prompt, platform);
    }
    throw error;
  }
}

function srtTime(seconds: number) {
  const ms = Math.round(seconds * 1000);
  const h = Math.floor(ms / 3600000);
  const m = Math.floor((ms % 3600000) / 60000);
  const s = Math.floor((ms % 60000) / 1000);
  const milli = ms % 1000;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")},${String(milli).padStart(3, "0")}`;
}

export function createSrt(plan: MediaPlan) {
  let cursor = 0;
  return plan.scenes.map((scene, index) => {
    const start = cursor;
    cursor += scene.durationSeconds;
    const text = scene.onScreenText || scene.narration;
    return `${index + 1}\n${srtTime(start)} --> ${srtTime(cursor)}\n${text}\n`;
  }).join("\n");
}

async function createVoiceover(plan: MediaPlan) {
  const key = process.env.ELEVENLABS_API_KEY;
  const voiceId = process.env.ELEVENLABS_VOICE_ID;
  if (!key || !voiceId) return null;
  const narration = plan.scenes.map((scene) => scene.narration).join(" ");
  const voiceModel = process.env.ELEVENLABS_MODEL_ID || "eleven_multilingual_v2";
  const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(voiceId)}`, {
    method: "POST",
    headers: { accept: "audio/mpeg", "content-type": "application/json", "xi-api-key": key },
    body: JSON.stringify({ text: narration, model_id: voiceModel, ...(/(turbo|flash)_v2_5/.test(voiceModel) ? { language_code: "tr" } : {}), output_format: "mp3_44100_128", voice_settings: { stability: 0.48, similarity_boost: 0.78, style: 0.22, use_speaker_boost: true } }),
  });
  if (!response.ok) throw new Error(`ElevenLabs TTS başarısız (${response.status}).`);
  const buffer = Buffer.from(await response.arrayBuffer());
  const stored = await storagePut(`arzu-media/${crypto.randomUUID()}.mp3`, buffer, "audio/mpeg");
  return stored.url;
}

function providerUrl(url: string, publicBaseUrl = "") {
  if (!publicBaseUrl) return url;
  if (url.startsWith("/")) return `${publicBaseUrl.replace(/\/$/, "")}${url}`;
  try {
    const parsed = new URL(url);
    if (parsed.hostname === "127.0.0.1" || parsed.hostname === "localhost") return `${publicBaseUrl.replace(/\/$/, "")}${parsed.pathname}${parsed.search}`;
  } catch { /* yerel olmayan URL olduğu gibi kullanılır */ }
  return url;
}

async function renderShotstack(plan: MediaPlan, imageUrls: string[], voiceoverUrl: string | null, publicBaseUrl = "") {
  const shotstack = shotstackConfig();
  const key = shotstack.key;
  if (!key) return null;
  const textOnly = imageUrls.length === 0;
  const clips = imageUrls.map((url, index) => ({ asset: { type: "image", src: providerUrl(url, publicBaseUrl) }, start: plan.scenes.slice(0, index).reduce((sum, scene) => sum + scene.durationSeconds, 0), length: plan.scenes[index].durationSeconds, fit: "cover", effect: "zoomIn" }));
  const tracks: Array<{ clips: unknown[] }> = [];
  // Shotstack'te ilk track en üst katmandır; yazılar görsellerin altında kalmasın diye başa eklenir.
  tracks.push({ clips: plan.scenes.map((scene, index) => ({ asset: { type: "rich-text", text: scene.onScreenText || scene.narration, font: { family: "Open Sans", size: textOnly ? 46 : 34, weight: "700", color: "#ffffff" }, align: { horizontal: "center", vertical: "middle" } }, start: plan.scenes.slice(0, index).reduce((sum, item) => sum + item.durationSeconds, 0), length: scene.durationSeconds, position: textOnly ? "center" : "bottom", offset: { y: textOnly ? 0 : 0.12 }, transition: { in: "fade", out: "fade" } })) });
  if (!textOnly) tracks.push({ clips });
  if (voiceoverUrl) tracks.push({ clips: [{ asset: { type: "audio", src: providerUrl(voiceoverUrl, publicBaseUrl) }, start: 0, length: plan.durationSeconds }] });
  const response = await fetch(`${shotstack.baseUrl}/render`, {
    method: "POST",
    headers: { "content-type": "application/json", accept: "application/json", "x-api-key": key },
    body: JSON.stringify({ timeline: { background: "#11101A", tracks }, output: { format: "mp4", resolution: "hd", aspectRatio: plan.aspectRatio } }),
  });
  if (!response.ok) {
    const detail = (await response.text()).slice(0, 800);
    throw new Error(`Shotstack render isteği başarısız (${response.status}): ${detail}`);
  }
  const data = await response.json() as { response?: { id?: string } };
  if (!data.response?.id) throw new Error("Shotstack render kimliği dönmedi.");
  return data.response.id;
}

export async function renderMediaPlan(plan: MediaPlan, publicBaseUrl = ""): Promise<MediaJobResult> {
  const capabilities = getMediaCapabilities();
  const assets: MediaJobResult["assets"] = [];
  let voiceWarning = "";
  const engine = pickRenderEngine();
  if (engine === "none") {
    return { status: "needs_configuration", plan, assets, message: `Plan hazır. ${localRenderProblem() || "Gerçek MP4 için sunucu bilgisayarına ffmpeg kur."}` };
  }

  // Görsel üretim hesabın kredisi/limiti dolunca (ör. "usage exhausted") tüm işi çökertmek yerine
  // yazı sahneli, animasyonlu bir video üretilir ve nedeni kullanıcıya söylenir.
  let imageWarning = capabilities.images.available ? "" : " Görsel üretim yapılandırılmadığı için video animasyonlu yazı sahneleriyle hazırlanıyor.";
  for (const scene of plan.scenes) {
    if (!capabilities.images.available) break;
    try {
      const image = await generateImage({ prompt: `${scene.visualPrompt}. No readable text, social media ad visual, consistent campaign style, ${plan.aspectRatio} composition.`, quality: "medium" });
      if (!image.url) throw new Error("Görsel üretim servisi URL döndürmedi.");
      assets.push({ type: "image", url: image.url, note: `Sahne ${scene.index}` });
    } catch (error) {
      const detail = error instanceof Error ? error.message : "bilinmeyen hata";
      console.error("[media] görsel üretilemedi:", detail);
      const exhausted = /exhaust|quota|credit|precondition|402|429/i.test(detail);
      imageWarning = exhausted
        ? " Görsel üretim kredisi/limiti dolu olduğu için video yalnızca animasyonlu yazı sahneleriyle hazırlanıyor."
        : ` Görsel üretilemedi (${detail.slice(0, 120)}); video yalnızca yazı sahneleriyle hazırlanıyor.`;
      assets.length = 0;
      break;
    }
  }
  let voiceover: string | null = null;
  try {
    voiceover = await createVoiceover(plan);
  } catch (error) {
    voiceWarning = error instanceof Error ? ` ElevenLabs seslendirme kullanılamadı (${error.message}); MP4 sessiz olarak devam ediyor.` : " ElevenLabs seslendirme kullanılamadı; MP4 sessiz olarak devam ediyor.";
  }
  if (voiceover) assets.push({ type: "voiceover", url: voiceover });
  const srt = Buffer.from(createSrt(plan), "utf8");
  const subtitles = await storagePut(`arzu-media/${crypto.randomUUID()}.srt`, srt, "application/x-subrip");
  assets.push({ type: "subtitles", url: subtitles.url, note: "SRT yan dosyası; burn-in için renderer ayarı gerekir." });
  if (engine === "local") {
    const imageAssets = assets.filter((asset) => asset.type === "image");
    const useImages = imageAssets.length === plan.scenes.length;
    const { jobId } = startLocalRender({
      title: plan.title,
      width: plan.aspectRatio === "9:16" ? 1080 : 1920,
      height: plan.aspectRatio === "9:16" ? 1920 : 1080,
      background: "#14121D",
      audioUrl: voiceover ?? undefined,
      scenes: plan.scenes.map((scene, index) => ({
        durationSeconds: scene.durationSeconds,
        text: scene.onScreenText || scene.narration,
        subtext: scene.onScreenText && !voiceover ? (scene.narration.length > 120 ? `${scene.narration.slice(0, 117)}…` : scene.narration) : "",
        accent: ["#B8ACFF", "#7CDBBE", "#F3C58C", "#F1A6C5", "#8FC7FF"][index % 5],
        effect: (["fade", "zoomIn", "slideLeft", "slideRight", "zoomOut"] as const)[index % 5],
        imageUrl: useImages ? imageAssets[index].url : undefined,
      })),
    });
    const note = imageWarning || voiceWarning ? `${imageWarning}${voiceWarning}`.trim() : "";
    return { status: "queued", plan, assets, renderJobId: jobId, message: `Video bu bilgisayarda hazırlanıyor (yerel render).${note ? ` ${note}` : ""}` };
  }
  const renderJobId = await renderShotstack(plan, assets.filter((asset) => asset.type === "image").map((asset) => asset.url), voiceover, publicBaseUrl);
  return { status: "queued", plan, assets, renderJobId: renderJobId ?? undefined, message: renderJobId ? `${imageWarning ? "SRT ve MP4 render işi kuyruğa alındı." : "Gerçek görseller, SRT ve MP4 render işi kuyruğa alındı."} Render kimliği: ${renderJobId}.${imageWarning}${voiceWarning}` : `${imageWarning ? "SRT hazırlandı" : "Gerçek görseller ve SRT hazırlandı"}; video render servisi sonuç vermedi.${imageWarning}${voiceWarning}` };
}

export async function getMediaRenderStatus(renderJobId: string, publicBaseUrl = "") {
  if (renderJobId.startsWith(LOCAL_JOB_PREFIX)) return getLocalRenderStatus(renderJobId, publicBaseUrl);
  const shotstack = shotstackConfig();
  const key = shotstack.key;
  if (!key) return { status: "needs_configuration" as const, message: "SHOTSTACK_API_KEY yapılandırılmalı." };
  const response = await fetch(`${shotstack.baseUrl}/render/${encodeURIComponent(renderJobId)}`, { headers: { accept: "application/json", "x-api-key": key } });
  if (!response.ok) throw new Error(`Shotstack durum sorgusu başarısız (${response.status}).`);
  const data = await response.json() as { response?: { status?: string; url?: string } };
  const renderResponse = data.response;
  const status = renderResponse?.status;
  if (status === "done" && renderResponse?.url) return { status: "completed" as const, url: renderResponse.url, message: "MP4 render tamamlandı." };
  if (status === "failed") return { status: "failed" as const, message: "MP4 render başarısız oldu; çıktı kullanılmadı." };
  return { status: "queued" as const, message: `MP4 render durumu: ${status || "queued"}.` };
}
