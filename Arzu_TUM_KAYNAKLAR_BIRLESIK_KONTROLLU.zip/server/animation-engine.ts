import { z } from "zod";

import { invokeLLM } from "./_core/llm";
import { localRenderProblem, localRenderReady, startLocalRender } from "./local-render";

export const animationPlatforms = ["reels", "tiktok", "shorts", "youtube"] as const;
export type AnimationPlatform = (typeof animationPlatforms)[number];

const formatMap: Record<AnimationPlatform, { label: string; aspectRatio: "9:16" | "16:9"; width: number; height: number }> = {
  reels: { label: "Instagram Reels", aspectRatio: "9:16", width: 1080, height: 1920 },
  tiktok: { label: "TikTok", aspectRatio: "9:16", width: 1080, height: 1920 },
  shorts: { label: "YouTube Shorts", aspectRatio: "9:16", width: 1080, height: 1920 },
  youtube: { label: "YouTube", aspectRatio: "16:9", width: 1920, height: 1080 },
};

const sceneSchema = z.object({
  index: z.number().int().min(1).max(12),
  durationSeconds: z.number().min(1).max(30),
  text: z.string().min(1).max(180),
  subtext: z.string().max(240).default(""),
  accent: z.string().regex(/^#[0-9a-fA-F]{6}$/).default("#B8ACFF"),
  effect: z.enum(["fade", "slideLeft", "slideRight", "zoomIn", "zoomOut"]).default("fade"),
});

const planSchema = z.object({
  title: z.string().min(1).max(160),
  platform: z.enum(animationPlatforms),
  durationSeconds: z.number().int().min(3).max(180),
  background: z.string().regex(/^#[0-9a-fA-F]{6}$/),
  scenes: z.array(sceneSchema).min(1).max(12),
});

export type AnimationPlan = z.infer<typeof planSchema> & {
  aspectRatio: "9:16" | "16:9";
  formatLabel: string;
  width: number;
  height: number;
  fps: 30;
};

function offlineAnimationPlan(prompt: string, platform: AnimationPlatform): AnimationPlan {
  const format = formatMap[platform];
  const topic = prompt.slice(0, 100) || "Arzu kişisel AI asistanı";
  const raw = {
    title: `${format.label} Arzu animasyonu`, platform, durationSeconds: 12, background: "#14121D",
    scenes: [
      { index: 1, durationSeconds: 3, text: "Daha akıllı bir gün", subtext: topic, accent: "#B8ACFF", effect: "fade" },
      { index: 2, durationSeconds: 3, text: "Sor. Planla. Üret.", subtext: "Arzu yanında.", accent: "#7CDBBE", effect: "zoomIn" },
      { index: 3, durationSeconds: 3, text: "Fikirden sonuca", subtext: "Daha hızlı ve daha kişisel.", accent: "#F3C58C", effect: "slideLeft" },
      { index: 4, durationSeconds: 3, text: "Arzu'yu şimdi dene", subtext: "Kişisel AI asistanın.", accent: "#F1A6C5", effect: "fade" },
    ],
  };
  const normalized = planSchema.parse(raw);
  return { ...normalized, aspectRatio: format.aspectRatio, formatLabel: format.label, width: format.width, height: format.height, fps: 30 };
}

function contentText(content: string | Array<{ type: string; text?: string }>) {
  return typeof content === "string" ? content : content.map((part) => part.text ?? "").join("\n");
}

function parseJson(value: string) {
  const cleaned = value.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "").trim();
  try { return JSON.parse(cleaned); } catch (firstError) {
    const start = cleaned.indexOf("{");
    const end = cleaned.lastIndexOf("}");
    if (start >= 0 && end > start) {
      try { return JSON.parse(cleaned.slice(start, end + 1)); } catch { /* üst katmana ilk hata */ }
    }
    throw firstError;
  }
}

export async function planAnimationRequest(prompt: string, platform: AnimationPlatform = "reels"): Promise<AnimationPlan> {
  const format = formatMap[platform];
  try {
    const response = await invokeLLM({
    model: "gpt-5-mini",
    maxTokens: 3000,
    messages: [
      {
        role: "system",
        content: `Sen Arzu'nun motion graphics yönetmenisin. Türkçe, üretilebilir bir animasyon planı oluştur. JSON dışında hiçbir şey yazma. Hedef ${format.label}, oran ${format.aspectRatio}. Sahneler; okunaklı metin, kısa alt metin, hex vurgu rengi ve tek bir net hareket efekti içersin. Aynı anda çok fazla hareket kullanma.`,
      },
      { role: "user", content: `İstek: ${prompt}\nPlatform: ${format.label}` },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "arzu_animation_plan",
        strict: true,
        schema: {
          type: "object",
          additionalProperties: false,
          required: ["title", "platform", "durationSeconds", "background", "scenes"],
          properties: {
            title: { type: "string" }, platform: { type: "string", enum: animationPlatforms }, durationSeconds: { type: "integer" }, background: { type: "string" },
            scenes: { type: "array", minItems: 1, maxItems: 12, items: { type: "object", additionalProperties: false, required: ["index", "durationSeconds", "text", "subtext", "accent", "effect"], properties: { index: { type: "integer" }, durationSeconds: { type: "number" }, text: { type: "string" }, subtext: { type: "string" }, accent: { type: "string" }, effect: { type: "string", enum: ["fade", "slideLeft", "slideRight", "zoomIn", "zoomOut"] } } } },
          },
        },
      },
    } as any,
    });
  const raw = parseJson(contentText(response.choices[0]?.message.content ?? "{}")) as Record<string, unknown>;
  const rawScenes = Array.isArray(raw.scenes) ? raw.scenes : [];
  const scenes = rawScenes.slice(0, 12).map((value, index) => {
    const scene = (value && typeof value === "object" ? value : {}) as Record<string, unknown>;
    const effect = ["fade", "slideLeft", "slideRight", "zoomIn", "zoomOut"].includes(String(scene.effect)) ? String(scene.effect) : "fade";
    const accent = /^#[0-9a-fA-F]{6}$/.test(String(scene.accent)) ? String(scene.accent) : "#B8ACFF";
    return { index: index + 1, durationSeconds: Math.max(1, Math.min(30, Number(scene.durationSeconds) || 3)), text: String(scene.text || "Arzu"), subtext: String(scene.subtext || ""), accent, effect };
  });
  const normalized = planSchema.parse({ title: String(raw.title || "Arzu animasyonu"), platform: animationPlatforms.includes(raw.platform as AnimationPlatform) ? raw.platform : platform, durationSeconds: Math.max(3, Math.min(180, Math.round(Number(raw.durationSeconds) || scenes.reduce((sum, scene) => sum + scene.durationSeconds, 0)))), background: /^#[0-9a-fA-F]{6}$/.test(String(raw.background)) ? String(raw.background) : "#14121D", scenes: scenes.length ? scenes : [{ index: 1, durationSeconds: 3, text: "Arzu", subtext: "", accent: "#B8ACFF", effect: "fade" }] });
  const selected = formatMap[normalized.platform || platform];
  return { ...normalized, aspectRatio: selected.aspectRatio, formatLabel: selected.label, width: selected.width, height: selected.height, fps: 30 };
  } catch (error) {
    const detail = error instanceof Error ? error.message : String(error);
    if (/usage exhausted|quota|precondition|429|rate limit/i.test(detail)) {
      console.warn("[animation] planlama LLM kullanılamıyor; yerel şablon plan kullanılıyor:", detail.slice(0, 240));
      return offlineAnimationPlan(prompt, platform);
    }
    throw error;
  }
}

function shotstackConfig() {
  const sandbox = process.env.SHOTSTACK_ENV === "sandbox";
  return { key: sandbox ? process.env.SHOTSTACK_SANDBOX_API_KEY : process.env.SHOTSTACK_API_KEY, baseUrl: sandbox ? "https://api.shotstack.io/edit/stage" : "https://api.shotstack.io/edit/v1", sandbox };
}

export function createAnimationSource(plan: AnimationPlan) {
  return `// Arzu motion graphics source — deterministic 30fps plan\nconst animation = ${JSON.stringify({ width: plan.width, height: plan.height, fps: plan.fps, background: plan.background, scenes: plan.scenes }, null, 2)};\n\nexport function frameAt(timeSeconds) {\n  let cursor = 0;\n  for (const scene of animation.scenes) {\n    if (timeSeconds < cursor + scene.durationSeconds) return { scene, localTime: timeSeconds - cursor };\n    cursor += scene.durationSeconds;\n  }\n  return { scene: animation.scenes.at(-1), localTime: 0 };\n}\n`;
}

export async function renderAnimationPlan(plan: AnimationPlan) {
  const config = shotstackConfig();
  const forcedShotstack = (process.env.ARZU_RENDER_ENGINE || "").toLowerCase() === "shotstack" && Boolean(config.key);
  if (localRenderReady() && !forcedShotstack) {
    const { jobId } = startLocalRender({
      title: plan.title,
      width: plan.width,
      height: plan.height,
      fps: plan.fps,
      background: plan.background,
      scenes: plan.scenes.map((scene) => ({ durationSeconds: scene.durationSeconds, text: scene.text, subtext: scene.subtext, accent: scene.accent, effect: scene.effect })),
    });
    return { status: "queued" as const, renderJobId: jobId, message: "Animasyon bu bilgisayarda hazırlanıyor (yerel render)." };
  }
  if (!config.key) return { status: "needs_configuration" as const, message: `Animasyon planı hazır. ${localRenderProblem() || "Gerçek MP4 için sunucu bilgisayarına ffmpeg kur."}` };
  const clips = plan.scenes.map((scene, index) => ({
    asset: { type: "rich-text", text: `${scene.text}${scene.subtext ? `\n${scene.subtext}` : ""}`, font: { family: "Open Sans", size: plan.aspectRatio === "9:16" ? 54 : 46, weight: "700", color: scene.accent }, align: { horizontal: "center", vertical: "middle" } },
    start: plan.scenes.slice(0, index).reduce((sum, item) => sum + item.durationSeconds, 0),
    length: scene.durationSeconds,
    // Shotstack rich-text kliplerinde "fade" effect değeri geçerli değil;
    // fade planını yavaş zoom ile temsil et.
    effect: scene.effect === "fade" ? "zoomInSlow" : (["zoomIn", "zoomOut"].includes(scene.effect) ? scene.effect : "zoomInSlow"),
    position: "center",
    offset: { y: 0 },
  }));
  const response = await fetch(`${config.baseUrl}/render`, { method: "POST", headers: { "content-type": "application/json", accept: "application/json", "x-api-key": config.key }, body: JSON.stringify({ timeline: { background: plan.background, tracks: [{ clips }] }, output: { format: "mp4", resolution: "hd", aspectRatio: plan.aspectRatio } }) });
  if (!response.ok) {
    const detail = (await response.text()).slice(0, 500);
    throw new Error(`Animasyon render isteği başarısız (${response.status}): ${detail}`);
  }
  const data = await response.json() as { response?: { id?: string } };
  if (!data.response?.id) throw new Error("Animasyon render kimliği dönmedi.");
  return { status: "queued" as const, renderJobId: data.response.id, message: `Gerçek motion graphics MP4 render kuyruğa alındı (${data.response.id}).` };
}

export function getAnimationCapabilities() {
  const config = shotstackConfig();
  if (localRenderReady()) return { planner: true, deterministicSource: true, videoRender: true, note: "Bu bilgisayardaki ffmpeg ile yerel animasyon MP4 render etkin (API anahtarı gerekmez)." };
  return { planner: true, deterministicSource: true, videoRender: Boolean(config.key), note: config.key ? `Shotstack ${config.sandbox ? "sandbox" : "üretim"} animasyon renderı etkin.` : "Plan ve kaynak kodu üretilebilir; gerçek MP4 için Shotstack anahtarı gerekli." };
}
