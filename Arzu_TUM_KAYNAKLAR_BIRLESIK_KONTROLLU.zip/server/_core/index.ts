import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import os from "os";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerStorageProxy } from "./storageProxy";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { LOCAL_FILES_ROUTE, localDataDir } from "../storage";
import { detectLocalRender, localRenderProblem, localRenderReady, setServerPort } from "../local-render";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise((resolve) => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);

  // Enable CORS for all routes - reflect the request origin to support credentials
  app.use((req, res, next) => {
    const origin = req.headers.origin;
    // Yalnızca yerel/özel ağ kökenleri yansıtılır (telefon uygulaması Origin göndermez).
    if (origin && /^https?:\/\/(localhost|127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|[^./:]+\.local|\[::1\])/i.test(origin)) {
      res.header("Access-Control-Allow-Origin", origin);
    }
    res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    res.header(
      "Access-Control-Allow-Headers",
      "Origin, X-Requested-With, Content-Type, Accept, Authorization",
    );
    res.header("Access-Control-Allow-Credentials", "true");

    // Handle preflight requests
    if (req.method === "OPTIONS") {
      res.sendStatus(200);
      return;
    }
    next();
  });

  // Base64 veri yaklaşık üçte bir büyüdüğü için büyük telefon dosyalarında
  // 50 MB sınırı ham dosya 35 MB civarında kesiliyordu.
  app.use(express.json({ limit: "120mb" }));
  app.use(express.urlencoded({ limit: "120mb", extended: true }));

  registerStorageProxy(app);
  registerOAuthRoutes(app);

  // Üretilen video/ses/dosyalar (Manus depolaması yapılandırılmamışsa yerel diskten servis edilir).
  app.use(LOCAL_FILES_ROUTE, express.static(localDataDir(), { index: false, maxAge: "1h", fallthrough: true }));

  app.get("/api/health", (req, res) => {
    res.json({ ok: true, app: "arzu", port: req.socket.localPort, render: localRenderReady(), timestamp: Date.now() });
  });

  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    }),
  );

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  // Telefonun aynı Wi‑Fi ağından erişebilmesi için tüm ağ arayüzlerine bağlanır.
  // Uzun LLM/render istekleri ve büyük yüklemelerde Wi‑Fi bağlantısı kopmasın.
  server.keepAliveTimeout = 120_000;
  server.headersTimeout = 125_000;
  server.requestTimeout = 600_000;
  setServerPort(port);

  server.listen(port, "0.0.0.0", () => {
    console.log(`[api] server listening on 0.0.0.0:${port}`);
    const addresses = Object.values(os.networkInterfaces())
      .flatMap((list) => list ?? [])
      .filter((item) => item.family === "IPv4" && !item.internal)
      .map((item) => item.address);
    if (addresses.length) {
      console.log("[api] Telefonda Arzu > Profil > Sunucu adresi bölümüne şunlardan birini yaz:");
      for (const address of addresses) console.log(`        http://${address}:${port}`);
      console.log("[api] Telefon ve bilgisayar aynı Wi‑Fi ağında olmalı; Windows'ta güvenlik duvarında bu portu aç.");
    }
    void detectLocalRender().then(() => {
      console.log(localRenderReady() ? "[render] ffmpeg bulundu: video/animasyon bu bilgisayarda üretilecek." : `[render] ${localRenderProblem()}`);
    });
  });
}

startServer().catch(console.error);
